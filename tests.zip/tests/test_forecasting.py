"""Demand forecasting: windows/leakage, baselines, LSTM, evaluation, and the link to the agents."""
import copy
import json

import numpy as np
import pandas as pd
import pytest
import torch

from src.environment.hospital_env import HospitalEnv
from src.environment.hospital_state import AGENTS
from src.environment.multi_agent_env import HospitalMAEnv
from src.evaluation.evaluate import evaluate_ma_policy
from src.forecasting.demand_forecaster import (
    ForecastProvider, LSTMDemandForecaster, LSTMNet, MovingAverageForecaster, build_features,
    fit_moving_average, load_forecaster, make_forecast_provider, make_windows)
from src.forecasting.train_forecaster import (
    Dataset, ForecastSettings, evaluate_forecasters, generate_episode, run_forecasting_experiment,
    train_lstm)
from src.utils.config import load_config
from tests.helpers import make_config, make_env, patient


# ------------------------------------------------------------------ windows / leakage
def test_make_windows_by_hand():
    counts = np.array([[1, 0], [2, 1], [3, 1], [4, 2]], float)
    h = make_windows(counts, 3)
    assert h.shape == (4, 3, 2)
    assert h[0].tolist() == [[0, 0], [0, 0], [0, 0]]                  # nothing before the start
    assert h[2].tolist() == [[0, 0], [1, 0], [2, 1]]                  # steps -1, 0, 1
    assert h[3].tolist() == [[1, 0], [2, 1], [3, 1]]


def test_windows_never_contain_the_step_being_predicted_or_later():
    rng = np.random.default_rng(0)
    counts = rng.poisson(2.0, size=(60, 2)).astype(float)
    base = make_windows(counts, 8)
    for k in (0, 5, 30, 59):
        changed = counts.copy()
        changed[k:] += 100.0                                           # alter step k and the future
        assert np.array_equal(make_windows(changed, 8)[k], base[k])    # history of k is unaffected


# --------------------------------------------------------------- moving average
def test_moving_average_predictions():
    fc = MovingAverageForecaster(window=2, steps_per_day=96, prior=(7.0, 3.0))
    hist = np.array([[[9.0, 1.0], [1.0, 1.0], [3.0, 5.0]]])           # window of 3 rows given
    assert fc.predict(hist[0], 10).tolist() == [2.0, 3.0]             # mean of the last two rows
    short = np.array([[0.0, 0.0], [0.0, 0.0], [4.0, 2.0]])            # only one real step (k=1)
    assert fc.predict(short, 1).tolist() == [4.0, 2.0]
    assert fc.predict(np.zeros((3, 2)), 0).tolist() == [7.0, 3.0]     # no history -> prior


def test_moving_average_window_is_chosen_on_validation_data():
    rng = np.random.default_rng(0)
    counts = rng.poisson(2.0, size=(4000, 2)).astype(float)            # constant rate: long windows win
    h = make_windows(counts, 16)
    fc, scores = fit_moving_average(h, np.arange(4000), counts, [1, 2, 4, 8, 16], 96)
    assert fc.window == min(scores, key=lambda m: (scores[m], m)) and fc.window >= 8
    assert scores[1] > scores[fc.window]


# ----------------------------------------------------------------------- data
def test_expected_rates_match_the_generated_counts_on_average():
    cfg = load_config()
    counts, expected = [], []
    for seed in range(5):
        c, e, spd = generate_episode(cfg, "high_demand", seed)
        counts.append(c); expected.append(e)
    c, e = np.concatenate(counts), np.concatenate(expected)
    assert spd == 96 and c.shape[1] == 2
    assert c[:, 0].mean() == pytest.approx(e[:, 0].mean(), rel=0.08)
    assert c[:, 1].mean() == pytest.approx(e[:, 1].mean(), rel=0.12)
    assert (c[:, 1] <= c[:, 0]).all()


def test_forecast_seeds_do_not_overlap_rl_or_evaluation_seeds():
    st = ForecastSettings.from_config(load_config())
    assert st.train_seed_start >= 200_000 and st.val_seed_start >= 300_000
    assert st.train_seed_start + st.train_episodes_per_scenario < st.val_seed_start
    assert st.test_seed_start == 1000                                  # same held-out seeds as evaluation


# ------------------------------------------------------------------------ LSTM
def test_features_and_network_shapes():
    hist = np.random.default_rng(0).poisson(1.0, size=(5, 8, 2)).astype(float)
    k = np.array([0, 3, 8, 50, 100])
    x, static = build_features(hist, k, window=8, steps_per_day=96, scale=3.0)
    assert x.shape == (5, 8, 5) and static.shape == (5, 2)
    assert x[0, :, 4].tolist() == [0.0] * 8                            # k=0: all padded
    assert x[1, :, 4].tolist() == [0.0] * 5 + [1.0] * 3                # k=3: last 3 rows are real
    assert x[4, :, 4].tolist() == [1.0] * 8
    out = LSTMNet(16)(torch.as_tensor(x), torch.as_tensor(static))
    assert out.shape == (5, 2) and (out >= 0).all()


def _toy_dataset(n_episodes=100, steps=96, spd=24, window=8, seed=0):
    """Noise-free periodic demand: the time of day alone determines the next count."""
    s = np.arange(steps)
    one = np.stack([2.0 + 1.5 * np.sin(2 * np.pi * s / spd), 0.5 + 0.3 * np.sin(2 * np.pi * s / spd)], axis=1)
    hists = np.stack([make_windows(one, window)] * n_episodes).reshape(-1, window, 2)
    k = np.tile(s, n_episodes)
    tgt = np.tile(one, (n_episodes, 1))
    return Dataset(hists, k, tgt, tgt, np.array(["toy"] * len(k))), spd


def test_lstm_learns_a_periodic_pattern_better_than_the_best_moving_average():
    torch.manual_seed(0)
    train, spd = _toy_dataset(seed=0)
    val, _ = _toy_dataset(n_episodes=10)
    st = ForecastSettings(window=8, hidden_size=16, epochs=25, lr=5e-3, batch_size=128, patience=10)
    lstm = train_lstm(train, val, st, spd, seed=0)
    ma, _ = fit_moving_average(val.histories, val.steps, val.targets, [1, 2, 4, 8], spd)
    mae_lstm = np.abs(lstm.predict_batch(val.histories, val.steps) - val.targets).mean()
    mae_ma = np.abs(ma.predict_batch(val.histories, val.steps) - val.targets).mean()
    assert mae_lstm < 0.5 * mae_ma


def test_lstm_training_is_reproducible():
    train, spd = _toy_dataset(n_episodes=10)
    val, _ = _toy_dataset(n_episodes=2)
    st = ForecastSettings(window=8, hidden_size=8, epochs=2, batch_size=64)
    a = train_lstm(train, val, st, spd, seed=4)
    b = train_lstm(train, val, st, spd, seed=4)
    for pa, pb in zip(a.net.parameters(), b.net.parameters()):
        assert torch.equal(pa, pb)


def test_save_and_load_roundtrip(tmp_path):
    ma = MovingAverageForecaster(4, 96, (1.0, 0.5))
    ma.save(tmp_path / "ma.json")
    assert json.loads((tmp_path / "ma.json").read_text())["window"] == 4
    lstm = LSTMDemandForecaster(LSTMNet(8), 8, 96, 3.0)
    lstm.save(tmp_path / "lstm.pt")
    hist = np.random.default_rng(0).poisson(1.0, size=(3, 8, 2)).astype(float)
    k = np.array([2, 20, 40])
    assert np.allclose(load_forecaster(tmp_path / "ma.json").predict_batch(hist, k), ma.predict_batch(hist, k))
    assert np.allclose(load_forecaster(tmp_path / "lstm.pt").predict_batch(hist, k), lstm.predict_batch(hist, k))
    (tmp_path / "x.txt").write_text("nope")
    with pytest.raises(ValueError):
        load_forecaster(tmp_path / "x.txt")


# ------------------------------------------------------------------ evaluation maths
class _Fixed:
    window, steps_per_day = 2, 96
    def __init__(self, value): self.value = np.asarray(value, float)
    def predict_batch(self, histories, steps): return np.tile(self.value, (len(steps), 1))


def test_mae_and_rmse_by_hand():
    targets = np.array([[1.0, 0.0], [3.0, 2.0], [2.0, 1.0], [0.0, 1.0]])
    ds = Dataset(np.zeros((4, 2, 2)), np.arange(4), targets, targets * 0 + 1.5, np.array(["s"] * 4))
    df = evaluate_forecasters({"two": _Fixed([2.0, 1.0])}, ds)
    row = df[(df.model == "two") & (df.scenario == "all")].iloc[0]
    assert row.mae_total == pytest.approx(np.mean([1, 1, 0, 2]))
    assert row.rmse_total == pytest.approx(np.sqrt(np.mean([1, 1, 0, 4])))
    assert row.mae_emergency == pytest.approx(np.mean([1, 1, 0, 0]))
    orc = df[(df.model == "oracle_true_rate") & (df.scenario == "all")].iloc[0]
    assert orc.mae_total == pytest.approx(np.mean([0.5, 1.5, 0.5, 1.5]))


def test_experiment_smoke_run_saves_everything(tmp_path):
    metrics = run_forecasting_experiment(load_config(), tmp_path, seed=0, verbose=False, overrides={
        "scenarios": ["normal"], "train_episodes_per_scenario": 3, "val_episodes_per_scenario": 1,
        "test_episodes_per_scenario": 2, "epochs": 2, "hidden_size": 8})
    for name in ("lstm.pt", "moving_average.json", "forecast_metrics.csv", "forecaster_training_log.csv"):
        assert (tmp_path / name).exists()
    assert {"lstm", "oracle_true_rate"} <= set(metrics.model) and any(m.startswith("moving_average") for m in metrics.model)
    assert np.isfinite(metrics[["mae_total", "rmse_total", "mae_emergency", "rmse_emergency"]].to_numpy()).all()
    assert (metrics.n_steps[metrics.scenario == "all"] == 2 * 288).all()


# --------------------------------------------------------- link to the environment / agents
def test_provider_history_matches_the_generated_arrival_series():
    cfg = load_config()
    seed, W = 7, 6
    counts, _, _ = generate_episode(cfg, "normal", seed)
    ma = HospitalMAEnv(cfg, "normal", seed=seed)
    provider = ForecastProvider(MovingAverageForecaster(W, 96), step_minutes=ma.env.step_minutes)
    ma.reset()
    expected = make_windows(counts, W)
    defer = {a: ma.agent_objs[a].defer_index for a in AGENTS}
    for k in range(60):
        assert ma.env.state.time == k * 15 and not ma.done
        hist, kk = provider.history(ma.env)
        assert kk == k and np.array_equal(hist, expected[k])
        ma.step(defer)                                               # clock advances by one step


def test_provider_uses_only_the_past():
    def env_with(arrivals):
        return make_env([patient(i, arrival_time=t, arrival_step=t // 15) for i, t in enumerate(arrivals)],
                        make_config())
    provider = ForecastProvider(MovingAverageForecaster(3, 96, (0.0, 0.0)), 15, scale=1.0)
    for arrivals_a, arrivals_b in (([0, 50], [0, 200]), ([0, 30], [0])):
        a, b = env_with(arrivals_a), env_with(arrivals_b)
        for _ in range(2):                                           # clock -> 30
            a.step({}); b.step({})
        assert a.state.time == 30
        assert provider(a) == provider(b)                            # future (and the patient arriving at
        #                                                              exactly t=30) cannot influence it
    assert provider.history(a)[0][:, 0].sum() == 1.0                 # only the patient at minute 0 counts


def test_forecast_reaches_all_agents_and_defaults_to_zero():
    cfg = load_config()
    fixed = MovingAverageForecaster(4, 96, prior=(0.3, 0.1))
    ma = HospitalMAEnv(cfg, "normal", seed=1,
                       forecast_provider=ForecastProvider(fixed, 15, scale=3.0))
    obs, _ = ma.reset()
    for a in AGENTS:
        assert obs[a][2:4].tolist() == pytest.approx([0.3 / 3.0, 0.1 / 3.0], abs=1e-6)
    obs0, _ = HospitalMAEnv(cfg, "normal", seed=1).reset()
    for a in AGENTS:
        assert obs0[a][2:4].tolist() == [0.0, 0.0]


def test_forecasts_do_not_change_the_hospital_dynamics():
    """The forecaster only adds observation features; a policy that ignores observations behaves identically."""
    cfg = load_config()

    def run(provider):
        ma = HospitalMAEnv(cfg, "normal", seed=2, forecast_provider=provider)
        obs, info = ma.reset()
        while not ma.done:
            acts = {a: int(np.flatnonzero(info["masks"][a][:-1])[0]) if info["masks"][a][:-1].any()
                    else ma.agent_objs[a].defer_index for a in AGENTS}
            obs, _, _, info = ma.step(acts)
        return ma.episode_summary()
    fc = ForecastProvider(MovingAverageForecaster(8, 96, (0.6, 0.2)), 15)
    assert run(None) == run(fc)


def test_make_forecast_provider(tmp_path):
    assert make_forecast_provider(None) is None
    MovingAverageForecaster(4, 96, (1.0, 1.0)).save(tmp_path / "m.json")
    provider = make_forecast_provider({"path": str(tmp_path / "m.json")})
    assert isinstance(provider, ForecastProvider) and provider.forecaster.window == 4


def test_policies_remember_their_forecaster_and_evaluation_uses_it(tmp_path):
    from src.training.train_ppo import load_policy_set, train_ppo
    MovingAverageForecaster(4, 96, (1.2, 0.6)).save(tmp_path / "m.json")
    spec = {"path": str(tmp_path / "m.json")}
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.25
    policies = train_ppo(cfg, "normal", tmp_path / "run", iterations=1, seed=0, forecast_spec=spec,
                         ppo_overrides={"rollout_steps": 64, "minibatch_size": 32, "hidden_sizes": [8]},
                         verbose=False)
    assert policies.forecast_spec == spec
    assert load_policy_set(tmp_path / "run" / "checkpoints" / "final.pt").forecast_spec == spec

    seen = []

    class Recorder:
        forecast_spec = spec
        def act(self, obs, masks):
            seen.append(obs["bed"][2:4].copy())
            return {a: len(masks[a]) - 1 for a in AGENTS}            # always defer
    evaluate_ma_policy(cfg, "normal", Recorder(), [1000], "rec")
    assert any(v.max() > 0 for v in seen)                           # the forecast reached the agents
    seen.clear()

    class NoForecast(Recorder):
        forecast_spec = None
    evaluate_ma_policy(cfg, "normal", NoForecast(), [1000], "rec")
    assert all(v.max() == 0 for v in seen)
