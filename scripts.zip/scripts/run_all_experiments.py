"""Run the complete experiment suite and write tables + figures.

    python scripts/run_all_experiments.py --profile smoke      # pipeline check, a few minutes
    python scripts/run_all_experiments.py --profile default    # 3 training seeds x 40 iterations
    python scripts/run_all_experiments.py --profile full       # 5 training seeds x 100 iterations

Output (results/experiments/<profile>/): per_episode.csv, summary_by_scenario.csv,
summary_overall.csv, results_summary.md, figures/*.png, runs/<method>_seed<k>/ (logs, checkpoints).

The suite is RESUMABLE: re-running the same command skips finished runs. Use --aggregate-only to
rebuild tables/figures from what exists. Learned methods are trained on a mixture of scenarios
(default: all scenarios) and evaluated on every scenario with evaluation seeds 1000+.
The method 'comm_attention_forecast' needs results/forecaster/lstm.pt (trained automatically if missing).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

from src.evaluation.experiments import METHODS, PROFILES, run_experiments  # noqa: E402
from src.utils.config import load_config  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default=None)
    parser.add_argument("--profile", choices=sorted(PROFILES), default="default")
    parser.add_argument("--methods", nargs="+", default=None, help=f"subset of {list(METHODS)}")
    parser.add_argument("--seeds", type=int, default=None, help="number of training seeds per method")
    parser.add_argument("--iterations", type=int, default=None)
    parser.add_argument("--rollout-steps", type=int, default=None)
    parser.add_argument("--eval-seeds", type=int, default=None, help="number of evaluation seeds")
    parser.add_argument("--eval-seed-start", type=int, default=1000)
    parser.add_argument("--scenarios", nargs="+", default=None, help="evaluation scenarios (default: all)")
    parser.add_argument("--train-scenarios", nargs="+", default=None, help="training mixture (default: = scenarios)")
    parser.add_argument("--forecast-model", default="results/forecaster/lstm.pt")
    parser.add_argument("--out-dir", default=None)
    parser.add_argument("--aggregate-only", action="store_true")
    args = parser.parse_args()

    config = load_config(args.config)
    p = PROFILES[args.profile]
    scenarios = args.scenarios or p["scenarios"] or list(config["scenarios"])
    num_seeds = args.seeds or p["seeds"]
    n_eval = args.eval_seeds or p["eval_seeds"]
    eval_seeds = list(range(args.eval_seed_start, args.eval_seed_start + n_eval))
    out_dir = args.out_dir or f"results/experiments/{args.profile}"

    run_experiments(config, out_dir, args.methods or list(METHODS), num_seeds,
                    args.iterations or p["iterations"], eval_seeds, scenarios,
                    train_scenarios=args.train_scenarios, rollout_steps=args.rollout_steps or p["rollout_steps"],
                    forecast_model=args.forecast_model, aggregate_only=args.aggregate_only)
    print(f"\nOpen {out_dir}/results_summary.md for the tables and {out_dir}/figures/ for the plots.")


if __name__ == "__main__":
    main()
