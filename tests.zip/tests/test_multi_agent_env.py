"""Multi-agent wrapper: decision rounds, clock advancement, shared reward, reproducibility."""
import numpy as np
import pytest

from src.environment.hospital_state import AGENTS
from src.environment.multi_agent_env import HospitalMAEnv
from src.utils.config import load_config
from tests.helpers import make_config, make_env, patient


def _wrap(patients, cfg=None):
    ma = HospitalMAEnv(cfg or make_config(), "normal", seed=0)
    base = make_env(patients, cfg or make_config())
    ma.env = base                       # reuse a hand-built hospital
    obs, info = ma.reset()
    return ma, obs, info


def _acts(ma, **choice):
    return {a: choice.get(a, ma.agent_objs[a].defer_index) for a in AGENTS}


def test_reset_returns_observations_and_masks():
    ma = HospitalMAEnv(load_config(), "normal", seed=1)
    obs, info = ma.reset()
    assert set(obs) == set(AGENTS) == set(info["masks"])
    for a in AGENTS:
        assert obs[a].shape == (ma.obs_dims[a],)
        assert info["masks"][a].shape == (ma.n_actions[a],) and info["masks"][a][-1]


def test_all_defer_advances_the_clock_one_step():
    ma, _, _ = _wrap([patient(0)])
    obs, rew, term, info = ma.step(_acts(ma))                  # everyone defers
    assert info["clock_advanced"] and info["time"] == ma.env.step_minutes and not term
    assert ma.env.state.patients[0].stage.value == "waiting_bed"


def test_clock_waits_for_a_newly_enabled_agent():
    ma, _, _ = _wrap([patient(0)])
    _, _, _, info = ma.step(_acts(ma, bed=0))                  # admit the patient
    assert not info["clock_advanced"] and info["time"] == 0     # doctor can act in this same step
    assert info["masks"]["doctor"][0]
    _, _, _, info = ma.step(_acts(ma, doctor=0))               # treat the patient
    assert info["clock_advanced"] and info["time"] == 15
    assert ma.env.state.patients[0].stage.value == "in_treatment"


def test_voluntary_defer_ends_the_agents_turn():
    ma, _, _ = _wrap([patient(0), patient(1)])
    _, _, _, info = ma.step(_acts(ma))                         # bed agent had options but deferred
    assert info["clock_advanced"]                               # nobody else could act -> advance
    assert ma.env.state.patients[0].stage.value == "waiting_bed"


def test_shared_reward_is_identical_for_all_agents():
    ma, _, _ = _wrap([patient(0)])
    _, rew, _, info = ma.step(_acts(ma))
    assert len(set(rew.values())) == 1
    assert rew["bed"] == pytest.approx(info["reward_components"]["total"])


def test_invalid_attempt_is_penalised_and_counted():
    ma, _, _ = _wrap([patient(0)])
    _, rew, _, info = ma.step(_acts(ma, doctor=0))             # doctor picks an empty slot
    assert info["agent_metrics"]["doctor"]["invalid"] == 1
    assert info["reward_components"]["conflict"] == 1.0 and rew["doctor"] < 0
    assert ma.env.get_episode_summary()["invalid_actions"]["doctor"] == 1


def test_joint_conflict_between_two_agents_is_resolved_and_counted():
    # Single cardiologist: treatment of B and surgery of A compete in the same round.
    pats = [patient(0, required_specialization="cardiology", requires_surgery=True,
                    surgery_type="cardiac", surgery_duration=60, est_surgery_duration=60,
                    urgency_level=4, length_of_stay=300, expected_length_of_stay=300),
            patient(1, required_specialization="cardiology", arrival_time=15, arrival_step=1,
                    urgency_level=3, length_of_stay=300, expected_length_of_stay=300)]
    ma, _, _ = _wrap(pats, make_config(general_beds=2))
    ma.step(_acts(ma, bed=0))                                  # admit 0 (round, same step)
    ma.step(_acts(ma, doctor=0))                               # treat 0 -> clock advances to 15
    ma.step(_acts(ma, bed=0))                                  # admit 1 at t=15
    while ma.env.state.time < 30:                              # let treatment of 0 finish
        ma.step(_acts(ma))
    _, _, _, info = ma.step(_acts(ma, doctor=0, **{"or": 0}))  # both want the only cardiologist
    statuses = sorted(r.status for r in info["round_results"] if r.status != "deferred")
    assert statuses == ["executed", "invalid"]
    assert ma.env.state.patients[0].stage.value == "in_surgery"   # more urgent patient wins


def test_full_episode_with_mask_greedy_policy():
    ma = HospitalMAEnv(load_config(), "mixed_demand", seed=3)
    obs, info = ma.reset()
    total, rounds = 0.0, 0
    while not ma.done:
        acts = {}
        for a in AGENTS:
            allowed = np.flatnonzero(info["masks"][a][:-1])
            acts[a] = int(allowed[0]) if len(allowed) else ma.agent_objs[a].defer_index
        obs, rew, term, info = ma.step(acts)
        total += rew["bed"]
        rounds += 1
        assert np.isfinite(rew["bed"]) and all(np.isfinite(o).all() for o in obs.values())
        assert ma.env.state.validate_consistency() == []
    assert term and ma.env.steps_taken == ma.env.horizon // ma.env.step_minutes
    assert rounds >= ma.env.steps_taken
    s = ma.episode_summary()
    assert s["throughput"] > 0 and np.isfinite(total)


def test_wrapper_is_reproducible():
    def run():
        ma = HospitalMAEnv(load_config(), "normal", seed=5)
        obs, info = ma.reset()
        total = 0.0
        while not ma.done:
            acts = {}
            for a in AGENTS:
                allowed = np.flatnonzero(info["masks"][a][:-1])
                acts[a] = int(allowed[0]) if len(allowed) else ma.agent_objs[a].defer_index
            obs, rew, _, info = ma.step(acts)
            total += rew["bed"]
        return total, ma.episode_summary()
    assert run() == run()


def test_step_requires_all_agents_and_a_running_episode():
    ma, _, _ = _wrap([patient(0)])
    with pytest.raises(ValueError):
        ma.step({"bed": 0})
    while not ma.done:
        ma.step(_acts(ma))
    with pytest.raises(RuntimeError):
        ma.step(_acts(ma))
