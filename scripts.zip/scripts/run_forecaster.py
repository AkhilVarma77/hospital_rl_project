"""Train and evaluate the demand forecasters (moving average + LSTM) on simulated arrival data.

    python scripts/run_forecaster.py

Writes to results/forecaster/ : lstm.pt  moving_average.json  forecast_metrics.csv
forecaster_training_log.csv. Metrics are computed on HELD-OUT simulated episodes (test seeds
1000+) that are never used for training or model selection.
The agents can then use a forecaster with:
    python scripts/run_training.py --algo comm_ppo --forecast-model results/forecaster/lstm.pt
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

import pandas as pd  # noqa: E402

from src.forecasting.train_forecaster import run_forecasting_experiment  # noqa: E402
from src.utils.config import load_config  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default=None)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--out-dir", default="results/forecaster")
    parser.add_argument("--epochs", type=int, default=None)
    args = parser.parse_args()

    overrides = {"epochs": args.epochs} if args.epochs else None
    metrics = run_forecasting_experiment(load_config(args.config), args.out_dir, seed=args.seed,
                                         overrides=overrides)
    pd.set_option("display.width", 250)
    cols = ["model", "scenario", "mae_total", "rmse_total", "mae_emergency", "rmse_emergency",
            "mean_actual_total"]
    print("\nHeld-out test metrics (counts per 15-minute step):\n")
    print(metrics[cols].round(3).to_string(index=False))
    print("\n'oracle_true_rate' predicts the generator's true rate: it is the error floor caused by "
          "random arrivals, not a model you could use.")
    print(f"\nSaved to {args.out_dir}")


if __name__ == "__main__":
    main()
