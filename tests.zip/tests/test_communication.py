"""Communication: attention maths, ablation modes, learning signal, joint PPO, training loop."""
import copy
import math

import numpy as np
import pandas as pd
import pytest
import torch

from src.algorithms.comm_ppo import CommActorCritic, CommConfig, CommPPOLearner
from src.algorithms.ppo import PPOConfig
from src.algorithms.rollout_buffer import RolloutBuffer
from src.communication.attention_module import CommunicationModule
from src.communication.message_encoder import MessageEncoder
from src.environment.hospital_state import AGENTS
from src.evaluation.evaluate import evaluate_ma_policy
from src.training.train_comm_ppo import (
    CommPolicySet, load_comm_policy_set, save_comm_checkpoint, train_comm_ppo)
from src.utils.config import load_config

N = len(AGENTS)


# --------------------------------------------------------------------- attention maths
def test_attention_weights_are_normalised_and_never_self_attending():
    torch.manual_seed(0)
    comm = CommunicationModule(N, d_model=8, d_k=4, d_v=5, mode="attention")
    context, w = comm(torch.randn(6, N, 8))
    assert context.shape == (6, N, 5) and w.shape == (6, N, N)
    assert torch.allclose(w.sum(dim=-1), torch.ones(6, N), atol=1e-6)     # softmax: rows sum to 1
    assert (w >= 0).all() and (w <= 1).all()
    assert torch.diagonal(w, dim1=1, dim2=2).abs().max() == 0.0            # nothing from itself


def test_scaled_dot_product_matches_a_hand_calculation():
    comm = CommunicationModule(N, d_model=2, d_k=2, d_v=2, mode="attention")
    with torch.no_grad():
        for lin in list(comm.q_proj) + [comm.k_proj, comm.v_proj]:
            lin.weight.copy_(torch.eye(2)); lin.bias.zero_()
    h = torch.tensor([[[1.0, 0.0], [0.0, 2.0], [2.0, 2.0]]])               # agents bed, doctor, or
    context, w = comm(h)
    # receiver 0 (bed): scores with keys of agents 1 and 2 = q.k/sqrt(2)
    s = torch.tensor([1.0 * 0 + 0.0 * 2, 1.0 * 2 + 0.0 * 2]) / math.sqrt(2)  # [0, 2]/sqrt2
    expected = torch.softmax(s, dim=0)
    assert w[0, 0, 1:].tolist() == pytest.approx(expected.tolist(), abs=1e-6)
    assert context[0, 0].tolist() == pytest.approx(
        (expected[0] * h[0, 1] + expected[1] * h[0, 2]).tolist(), abs=1e-6)


def test_weights_are_learned_not_hardcoded():
    torch.manual_seed(0)
    comm = CommunicationModule(N, 8, 4, 4, "attention")
    h = torch.randn(16, N, 8)
    w_before = comm(h)[1].detach().clone()
    context, _ = comm(h)
    context[:, 0].sum().backward()                                         # a loss on receiver 0
    assert comm.k_proj.weight.grad.abs().sum() > 0 and comm.q_proj[0].weight.grad.abs().sum() > 0
    opt = torch.optim.SGD(comm.parameters(), lr=0.5)
    opt.step()
    assert not torch.allclose(comm(h)[1], w_before)                        # weights moved


def test_ablation_modes():
    h = torch.randn(3, N, 8)
    none = CommunicationModule(N, 8, 4, 4, "none")
    assert none(h) == (None, None) and sum(p.numel() for p in none.parameters()) == 0
    mean = CommunicationModule(N, 8, 4, 4, "mean")
    _, w = mean(h)
    off = ~torch.eye(N, dtype=torch.bool)
    assert torch.allclose(w[:, off], torch.full((3, N * (N - 1)), 1.0 / (N - 1)))   # uniform
    assert not hasattr(mean, "q_proj")                                    # no learned weighting
    with pytest.raises(ValueError):
        CommunicationModule(N, 8, 4, 4, "gossip")


def test_message_encoder_shape():
    assert MessageEncoder(75, 32, 16)(torch.randn(5, 75)).shape == (5, 16)


# ------------------------------------------------------------------ joint actor-critic
DIMS = {"bed": 6, "doctor": 9, "or": 7}
ACTIONS = {"bed": 4, "doctor": 5, "or": 3}


def _model(mode, seed=0):
    torch.manual_seed(seed)
    return CommActorCritic(DIMS, ACTIONS, CommConfig(mode=mode, d_model=16, d_k=8, d_v=8,
                                                      encoder_hidden=16, head_hidden=16))


def _batch(B=4):
    obs = {a: torch.randn(B, DIMS[a]) for a in AGENTS}
    masks = {a: torch.ones(B, ACTIONS[a], dtype=torch.bool) for a in AGENTS}
    return obs, masks


@pytest.mark.parametrize("mode", ["none", "mean", "attention"])
def test_output_shapes(mode):
    obs, masks = _batch()
    logits, values, w = _model(mode).forward_all(obs, masks)
    for a in AGENTS:
        assert logits[a].shape == (4, ACTIONS[a]) and values[a].shape == (4,)
    assert (w is None) == (mode == "none")


def test_other_agents_observations_influence_a_receiver_only_when_communicating():
    obs, masks = _batch(2)
    changed = {**obs, "doctor": obs["doctor"] + 5.0}
    for mode, should_change in (("none", False), ("mean", True), ("attention", True)):
        model = _model(mode)
        a, _, _ = model.forward_all(obs, masks)
        b, _, _ = model.forward_all(changed, masks)
        assert torch.allclose(a["bed"], b["bed"]) != should_change       # bed agent's logits
        assert not torch.allclose(a["doctor"], b["doctor"])               # its own obs always matters


def test_masked_actions_are_never_chosen():
    learner = CommPPOLearner(DIMS, ACTIONS, PPOConfig(), CommConfig(mode="attention", d_model=16,
                             d_k=8, d_v=8, encoder_hidden=16, head_hidden=16))
    rng = np.random.default_rng(0)
    for _ in range(100):
        obs = {a: rng.normal(size=DIMS[a]).astype(np.float32) for a in AGENTS}
        masks = {a: rng.random(ACTIONS[a]) < 0.5 for a in AGENTS}
        for a in AGENTS:
            masks[a][-1] = True
        for det in (False, True):
            out, w = learner.act(obs, masks, det)
            assert all(masks[a][out[a][0]] for a in AGENTS)
            assert w.shape == (N, N)


# ------------------------------------------------- does communication help? (toy task)
def _run_toy(mode, iterations=40):
    """Only the doctor agent SEES the context c; the bed agent is rewarded for choosing action c.
    Without communication the bed agent cannot know c, so it cannot beat chance."""
    torch.manual_seed(0)
    dims = {a: 4 for a in AGENTS}
    acts = {a: 4 for a in AGENTS}
    hp = PPOConfig(lr=3e-3, rollout_steps=256, minibatch_size=64, update_epochs=4, ent_coef=0.0,
                   gamma=0.0, gae_lambda=0.0)
    learner = CommPPOLearner(dims, acts, hp, CommConfig(mode=mode, d_model=16, d_k=8, d_v=8,
                             encoder_hidden=32, head_hidden=32), seed=0)
    rng = np.random.default_rng(0)
    mask = np.ones(4, bool)
    masks = {a: mask for a in AGENTS}

    def observe(ctx):
        return {"bed": np.zeros(4, np.float32), "doctor": np.eye(4, dtype=np.float32)[ctx],
                "or": np.zeros(4, np.float32)}
    for _ in range(iterations):
        bufs = {a: RolloutBuffer(256, 4, 4) for a in AGENTS}
        for _ in range(256):
            ctx = int(rng.integers(3))
            obs = observe(ctx)
            out, _ = learner.act(obs, masks)
            reward = 1.0 if out["bed"][0] == ctx else 0.0
            for a in AGENTS:
                bufs[a].add(obs[a], mask, out[a][0], out[a][1], out[a][2], reward, True)
        learner.update(bufs, {a: 0.0 for a in AGENTS})
    hits = sum(learner.act(observe(c), masks, True)[0]["bed"][0] == c for c in range(3))
    return hits / 3


def test_communication_solves_a_task_that_independent_agents_cannot():
    assert _run_toy("attention") == 1.0
    assert _run_toy("mean") == 1.0
    assert _run_toy("none") <= 1 / 3 + 1e-9        # constant observation -> one fixed answer


# ------------------------------------------------------------------ joint update / io
def test_update_changes_all_parts_and_acting_does_not():
    learner = CommPPOLearner(DIMS, ACTIONS, PPOConfig(rollout_steps=32, minibatch_size=16),
                             CommConfig(d_model=8, d_k=4, d_v=4, encoder_hidden=8, head_hidden=8))
    before = {n: p.clone() for n, p in learner.model.named_parameters()}
    rng = np.random.default_rng(0)
    masks = {a: np.ones(ACTIONS[a], bool) for a in AGENTS}
    bufs = {a: RolloutBuffer(32, DIMS[a], ACTIONS[a]) for a in AGENTS}
    for _ in range(32):
        obs = {a: rng.normal(size=DIMS[a]).astype(np.float32) for a in AGENTS}
        out, _ = learner.act(obs, masks)                                  # acting only
        for a in AGENTS:
            bufs[a].add(obs[a], masks[a], out[a][0], out[a][1], out[a][2], float(rng.normal()), False)
    assert all(torch.equal(before[n], p) for n, p in learner.model.named_parameters())
    learner.update(bufs, {a: 0.0 for a in AGENTS})
    changed = {n for n, p in learner.model.named_parameters() if not torch.equal(before[n], p)}
    assert any(n.startswith("comm.q_proj") for n in changed) and any(n.startswith("encoders.bed") for n in changed)
    assert any(n.startswith("actors.or") for n in changed)


def test_checkpoint_roundtrip(tmp_path):
    cc = CommConfig(mode="attention", d_model=8, d_k=4, d_v=4, encoder_hidden=8, head_hidden=8)
    learner = CommPPOLearner(DIMS, ACTIONS, PPOConfig(), cc, seed=0)
    save_comm_checkpoint(tmp_path / "c.pt", learner, {"mode": "attention"})
    loaded = load_comm_policy_set(tmp_path / "c.pt")
    rng = np.random.default_rng(0)
    obs = {a: rng.normal(size=DIMS[a]).astype(np.float32) for a in AGENTS}
    masks = {a: np.ones(ACTIONS[a], bool) for a in AGENTS}
    assert np.allclose(learner.act(obs, masks, True)[1], loaded.learner.act(obs, masks, True)[1])
    assert CommPolicySet(learner).act(obs, masks) == loaded.act(obs, masks)


# ------------------------------------------------------------------ training loop
def _short_config():
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.25
    return cfg


_FAST_PPO = {"rollout_steps": 96, "minibatch_size": 32}
_FAST_COMM = {"d_model": 8, "d_k": 4, "d_v": 4, "encoder_hidden": 16, "head_hidden": 16}


@pytest.mark.parametrize("mode", ["none", "mean", "attention"])
def test_training_smoke_run(tmp_path, mode):
    policies = train_comm_ppo(_short_config(), "normal", tmp_path, iterations=2, seed=0, mode=mode,
                              ppo_overrides=_FAST_PPO, comm_overrides=_FAST_COMM, checkpoint_every=1,
                              verbose=False)
    log = pd.read_csv(tmp_path / "train_log.csv")
    assert len(log) == 2 and np.isfinite(log.filter(like="_value_loss").to_numpy()).all()
    attn_cols = [c for c in log.columns if c.startswith("attn_")]
    assert (len(attn_cols) == 0) if mode == "none" else (len(attn_cols) == 6)
    if mode != "none":
        for r in AGENTS:                      # each receiver's weights over its two senders sum to 1
            total = sum(log[f"attn_{r}_from_{s}"].iloc[0] for s in AGENTS if s != r)
            assert total == pytest.approx(1.0, abs=1e-5)
    assert (tmp_path / "checkpoints" / "final.pt").exists()
    episodes = pd.read_csv(tmp_path / "episodes.csv")
    assert len(episodes) >= 1 and (episodes["env_seed"] >= 100_000).all()
    assert isinstance(policies, CommPolicySet)


def test_training_is_reproducible(tmp_path):
    kw = dict(iterations=1, seed=3, mode="attention", ppo_overrides=_FAST_PPO,
              comm_overrides=_FAST_COMM, verbose=False)
    a = train_comm_ppo(_short_config(), "normal", tmp_path / "a", **kw)
    b = train_comm_ppo(_short_config(), "normal", tmp_path / "b", **kw)
    for pa, pb in zip(a.learner.model.parameters(), b.learner.model.parameters()):
        assert torch.equal(pa, pb)


def test_evaluation_is_greedy_and_does_not_update_the_policy():
    from src.environment.multi_agent_env import HospitalMAEnv
    cfg = _short_config()
    ma = HospitalMAEnv(cfg, "normal", seed=1)
    learner = CommPPOLearner(ma.obs_dims, ma.n_actions, PPOConfig(), CommConfig(**{"mode": "attention", **_FAST_COMM}))
    before = [p.clone() for p in learner.model.parameters()]
    df = evaluate_ma_policy(cfg, "normal", CommPolicySet(learner), [1000, 1001], "comm_test")
    assert len(df) == 2 and {"episode_return", "invalid_actions_total"} <= set(df.columns)
    assert all(torch.equal(b, p) for b, p in zip(before, learner.model.parameters()))
    again = evaluate_ma_policy(cfg, "normal", CommPolicySet(learner), [1000, 1001], "comm_test")
    assert df.drop(columns="eval_seconds").equals(again.drop(columns="eval_seconds"))
