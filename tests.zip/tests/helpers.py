"""Shared helpers for building tiny, fully controlled hospitals in tests."""
from __future__ import annotations

import copy
from typing import Any, Optional

import pandas as pd

from src.data.synthetic_data_generator import SyntheticDataGenerator
from src.environment.hospital_env import HospitalEnv
from src.environment.hospital_state import AGENTS, Action
from src.utils.config import load_config

EVENT_COLUMNS = ["event_id", "event_type", "start_minute", "end_minute", "magnitude", "target"]


def make_config(general_beds: int = 2, icu_beds: int = 1, doctors: Optional[dict] = None,
                ors: int = 1, reserve: int = 1, priority: bool = True,
                max_actions: int = 3) -> dict[str, Any]:
    cfg = copy.deepcopy(load_config())
    cfg["resources"].update(
        num_general_beds=general_beds, num_icu_beds=icu_beds, num_operating_rooms=ors,
        doctors_per_specialization=doctors or {"general_medicine": 1, "cardiology": 1})
    cfg["clinical_rules"] = {"emergency_priority": priority, "icu_reserve_for_emergency": reserve}
    cfg["environment"]["max_actions_per_agent_per_step"] = max_actions
    return cfg


def patient(pid: int, **kw: Any) -> dict[str, Any]:
    row = dict(
        patient_id=pid, arrival_time=0, arrival_step=0, severity=3, urgency_level=3,
        is_emergency=True, required_bed_type="general",
        required_specialization="general_medicine",
        treatment_duration=30, est_treatment_duration=30,
        requires_surgery=False, surgery_type="none", surgery_duration=0, est_surgery_duration=0,
        length_of_stay=120, expected_length_of_stay=120,
        treatment_status="waiting", discharge_status="not_discharged")
    row.update(kw)
    return row


def make_env(patients: list[dict[str, Any]], cfg: Optional[dict] = None,
             events: Optional[list[dict]] = None) -> HospitalEnv:
    cfg = cfg or make_config()
    data = SyntheticDataGenerator(cfg, "normal", 0).generate_all()
    data["patients"] = pd.DataFrame(patients)
    data["events"] = pd.DataFrame(events or [], columns=EVENT_COLUMNS)
    return HospitalEnv(cfg, "normal", data=data)


def greedy_policy(env: HospitalEnv) -> dict[str, list[Action]]:
    """One action per agent: the first individually feasible one, else defer."""
    out = {}
    for agent in AGENTS:
        feasible = env.get_feasible_actions(agent)
        out[agent] = [feasible[0]] if feasible else [Action.defer(agent)]
    return out


def run_episode(env: HospitalEnv, check: bool = True) -> None:
    while not env.done:
        env.step(greedy_policy(env))
        if check:
            problems = env.state.validate_consistency()
            assert problems == [], problems
