# Experiment results (simulated data)

Training: 2 iterations per run on scenarios ['normal', 'bed_shortage']; evaluation: scenarios ['normal', 'bed_shortage'], 1 evaluation seeds (1000..1000). Methods: ['fcfs', 'severity', 'ppo_independent', 'comm_none', 'comm_mean', 'comm_attention', 'comm_attention_forecast', 'dqn'].

Values are mean ± standard deviation. Learned methods: across independent training runs (each run first averaged over evaluation seeds). Baselines: across evaluation seeds. No significance tests were run; differences smaller than the spread should not be interpreted.


## Overall (average over all evaluated scenarios)

| metric | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| Mean wait to treatment (min) | 333.84 | 285.68 | 296.40 | 214.71 | 234.84 | n/a | 213.34 | 256.01 |
| Emergency response delay (min) | 183.01 | 180.38 | 293.07 | 133.17 | 227.83 | n/a | 175.05 | 191.19 |
| Emergency surgery wait (min) | 0.00 | 20.18 | 521.56 | 36.94 | 166.00 | n/a | 42.98 | 34.29 |
| Patients never treated | 18.00 | 17.50 | 118.00 | 38.00 | 52.00 | 179.00 | 39.50 | 47.00 |
| Throughput (discharged) | 146.50 | 147.00 | 50.50 | 131.50 | 113.50 | 0.00 | 128.50 | 121.00 |
| Treatments completed | 159.50 | 159.00 | 60.50 | 140.50 | 127.00 | 0.00 | 139.00 | 132.00 |
| Surgeries completed | 37.00 | 35.50 | 11.00 | 35.50 | 29.00 | 0.00 | 34.50 | 34.50 |
| Bed utilization | 0.77 | 0.78 | 0.49 | 0.69 | 0.69 | 0.87 | 0.67 | 0.64 |
| Doctor utilization | 0.40 | 0.41 | 0.17 | 0.38 | 0.34 | 0.00 | 0.37 | 0.36 |
| OR utilization | 0.31 | 0.30 | 0.09 | 0.29 | 0.24 | 0.00 | 0.29 | 0.29 |
| Invalid actions (conflicts) per episode | 0.00 | 0.00 | 1.50 | 13.50 | 4.50 | 0.00 | 12.00 | 11.00 |
| Shared episode reward | n/a | n/a | -3071.03 | -566.90 | -1278.76 | -6635.82 | -662.37 | -919.22 |


## Mean wait to treatment (min) (lower is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 526.07 | 423.21 | 405.17 | 293.17 | 273.10 | n/a | 289.26 | 315.62 |
| normal | 141.61 | 148.15 | 187.63 | 136.25 | 196.58 | n/a | 137.42 | 196.41 |


## Emergency response delay (min) (lower is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 282.04 | 266.58 | 458.03 | 181.17 | 194.93 | n/a | 262.51 | 270.11 |
| normal | 83.98 | 94.18 | 128.11 | 85.18 | 260.73 | n/a | 87.58 | 112.27 |


## Emergency surgery wait (min) (lower is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 0.00 | 17.50 | 733.12 | 33.16 | 95.00 | n/a | 20.25 | 24.29 |
| normal | 0.00 | 22.86 | 310.00 | 40.71 | 237.00 | n/a | 65.71 | 44.29 |


## Patients never treated (lower is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 36.00 | 35.00 | 143.00 | 76.00 | 86.00 | 179.00 | 79.00 | 93.00 |
| normal | 0.00 | 0.00 | 93.00 | 0.00 | 18.00 | 179.00 | 0.00 | 1.00 |


## Throughput (discharged) (higher is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 127.00 | 128.00 | 29.00 | 97.00 | 85.00 | 0.00 | 92.00 | 80.00 |
| normal | 166.00 | 166.00 | 72.00 | 166.00 | 142.00 | 0.00 | 165.00 | 162.00 |


## Treatments completed (higher is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 140.00 | 139.00 | 35.00 | 102.00 | 93.00 | 0.00 | 99.00 | 86.00 |
| normal | 179.00 | 179.00 | 86.00 | 179.00 | 161.00 | 0.00 | 179.00 | 178.00 |


## Surgeries completed (higher is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 33.00 | 30.00 | 8.00 | 30.00 | 26.00 | 0.00 | 28.00 | 28.00 |
| normal | 41.00 | 41.00 | 14.00 | 41.00 | 32.00 | 0.00 | 41.00 | 41.00 |


## Bed utilization (higher is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 0.87 | 0.87 | 0.39 | 0.71 | 0.67 | 0.88 | 0.66 | 0.60 |
| normal | 0.66 | 0.68 | 0.59 | 0.66 | 0.70 | 0.85 | 0.68 | 0.69 |


## Doctor utilization (higher is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 0.35 | 0.37 | 0.11 | 0.30 | 0.27 | 0.00 | 0.29 | 0.28 |
| normal | 0.45 | 0.45 | 0.22 | 0.45 | 0.40 | 0.00 | 0.45 | 0.45 |


## OR utilization (higher is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 0.27 | 0.26 | 0.06 | 0.25 | 0.21 | 0.00 | 0.23 | 0.24 |
| normal | 0.34 | 0.34 | 0.12 | 0.34 | 0.26 | 0.00 | 0.34 | 0.34 |


## Invalid actions (conflicts) per episode (lower is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 0.00 | 0.00 | 0.00 | 10.00 | 2.00 | 0.00 | 5.00 | 5.00 |
| normal | 0.00 | 0.00 | 3.00 | 17.00 | 7.00 | 0.00 | 19.00 | 17.00 |


## Shared episode reward (higher is better)

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | n/a | n/a | -3832.77 | -998.14 | -1575.31 | -6635.13 | -1145.79 | -1427.00 |
| normal | n/a | n/a | -2309.29 | -135.66 | -982.21 | -6636.51 | -178.94 | -411.45 |


## Mean wait to treatment (min): percent difference to FCFS (negative = lower than FCFS)

| scenario | comm_attention | comm_attention_forecast | comm_mean | comm_none | dqn | fcfs | ppo_independent | severity |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | nan | -45.0 | -48.1 | -44.3 | -40.0 | 0.0 | -23.0 | -19.6 |
| normal | nan | -3.0 | 38.8 | -3.8 | 38.7 | 0.0 | 32.5 | 4.6 |


## Emergency response delay (min): percent difference to FCFS (negative = lower than FCFS)

| scenario | comm_attention | comm_attention_forecast | comm_mean | comm_none | dqn | fcfs | ppo_independent | severity |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | nan | -6.9 | -30.9 | -35.8 | -4.2 | 0.0 | 62.4 | -5.5 |
| normal | nan | 4.3 | 210.5 | 1.4 | 33.7 | 0.0 | 52.6 | 12.1 |


## Training time per run (seconds, wall clock on the machine that ran it)

| method | mean_seconds | std_seconds | runs |
|---|---|---|---|
| comm_attention | 0.7 | nan | 1 |
| comm_attention_forecast | 0.9 | nan | 1 |
| comm_mean | 0.7 | nan | 1 |
| comm_none | 0.6 | nan | 1 |
| dqn | 0.2 | nan | 1 |
| ppo_independent | 0.6 | nan | 1 |
