"""Training figures: learning curves per method and the attention weights over training."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402
import numpy as np                # noqa: E402
import pandas as pd               # noqa: E402


def _smooth(y: np.ndarray, k: int = 5) -> np.ndarray:
    if len(y) < k:
        return y
    return np.convolve(y, np.ones(k) / k, mode="valid")


def plot_learning_curves(runs_dir: str | Path, path: str | Path, smooth: int = 5) -> None:
    """Mean training episode return per iteration, mean +- std across training seeds per method.

    The training return is measured with exploration on mixed scenarios, so it is NOT comparable
    to the evaluation table; it only shows whether and how fast learning progresses."""
    curves: dict[str, list[np.ndarray]] = {}
    for log in sorted(Path(runs_dir).glob("*/train_log.csv")):
        method = log.parent.name.rsplit("_seed", 1)[0]
        y = pd.read_csv(log)["mean_episode_return"].interpolate().bfill().to_numpy()
        curves.setdefault(method, []).append(_smooth(y, smooth))
    fig, ax = plt.subplots(figsize=(8, 4.8))
    for method, ys in curves.items():
        n = min(len(y) for y in ys)
        arr = np.stack([y[:n] for y in ys])
        mu, sd = arr.mean(0), arr.std(0)
        xs = np.arange(n) + smooth
        ax.plot(xs, mu, label=f"{method} (n={len(ys)})")
        if len(ys) > 1:
            ax.fill_between(xs, mu - sd, mu + sd, alpha=0.15)
    ax.set_xlabel("training iteration")
    ax.set_ylabel(f"training episode return (moving average of {smooth})")
    ax.set_title("Learning curves (exploration on, mixed scenarios)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=130)
    plt.close(fig)


def plot_attention_weights(runs_dir: str | Path, path: str | Path, method: str = "comm_attention") -> Optional[Path]:
    """Average attention each receiver gives each sender, over training (mean across seeds)."""
    logs = [pd.read_csv(p) for p in sorted(Path(runs_dir).glob(f"{method}_seed*/train_log.csv"))]
    if not logs:
        return None
    cols = [c for c in logs[0].columns if c.startswith("attn_")]
    n = min(len(d) for d in logs)
    fig, ax = plt.subplots(figsize=(8, 4.8))
    for c in cols:
        ax.plot(np.arange(1, n + 1), np.mean([d[c].to_numpy()[:n] for d in logs], axis=0),
                label=c.replace("attn_", "").replace("_from_", " <- "))
    ax.axhline(0.5, color="grey", ls=":", lw=1)
    ax.set_xlabel("training iteration")
    ax.set_ylabel("mean attention weight (rollout average)")
    ax.set_title(f"Learned attention over training ({method}); dotted = uniform (0.5)")
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return Path(path)
