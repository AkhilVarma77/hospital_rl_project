"""DQN: replay buffer, masked epsilon-greedy, Bellman targets, learning, checkpoints, training loop."""
import copy

import numpy as np
import pandas as pd
import pytest
import torch
import torch.nn as nn

from src.algorithms.dqn import DQNConfig, DQNLearner, bellman_targets, epsilon_at
from src.algorithms.replay_buffer import ReplayBuffer
from src.environment.hospital_state import AGENTS
from src.environment.multi_agent_env import HospitalMAEnv
from src.evaluation.evaluate import evaluate_ma_policy
from src.training.train_dqn import (
    DQNPolicySet, load_dqn_policy_set, save_dqn_checkpoint, train_dqn)
from src.utils.config import load_config


# ------------------------------------------------------------------ replay buffer
def test_replay_buffer_add_sample_and_wraparound():
    buf = ReplayBuffer(capacity=3, obs_dim=2, n_actions=4)
    for i in range(5):                                           # 5 adds into capacity 3
        buf.add(np.full(2, i, np.float32), np.ones(4, bool), i % 4, float(i),
                np.full(2, i + 1, np.float32), np.ones(4, bool), i == 4)
    assert len(buf) == 3
    batch = buf.sample(64, np.random.default_rng(0))
    assert batch["obs"].shape == (64, 2) and batch["next_masks"].shape == (64, 4)
    assert set(batch["rewards"].tolist()) <= {2.0, 3.0, 4.0}      # 0 and 1 were overwritten
    assert (batch["next_obs"][:, 0] == batch["obs"][:, 0] + 1).all()
    assert (batch["dones"][batch["rewards"] == 4.0] == 1.0).all()


# ------------------------------------------------------------------ acting
def test_epsilon_schedule_is_linear_and_clamped():
    hp = DQNConfig(epsilon_start=1.0, epsilon_end=0.1, epsilon_decay_rounds=100)
    assert epsilon_at(hp, 0) == 1.0
    assert epsilon_at(hp, 50) == pytest.approx(0.55)
    assert epsilon_at(hp, 100) == pytest.approx(0.1) and epsilon_at(hp, 10_000) == pytest.approx(0.1)


def test_actions_are_always_feasible_greedy_and_exploring():
    torch.manual_seed(0)
    learner = DQNLearner(6, 5, DQNConfig(hidden_sizes=(16,)), seed=0)
    rng = np.random.default_rng(0)
    for _ in range(300):
        obs = rng.normal(size=6).astype(np.float32)
        mask = rng.random(5) < 0.5
        mask[-1] = True
        assert mask[learner.act(obs, mask, epsilon=0.0)]
        assert mask[learner.act(obs, mask, epsilon=1.0)]
        greedy = learner.act(obs, mask)
        assert greedy == int(np.argmax(np.where(mask, learner.q_values(obs, mask), -np.inf)))


def test_full_exploration_covers_all_allowed_actions_roughly_uniformly():
    learner = DQNLearner(2, 4, DQNConfig(hidden_sizes=(8,)), seed=1)
    mask = np.array([True, False, True, True])
    counts = np.bincount([learner.act(np.zeros(2, np.float32), mask, 1.0) for _ in range(3000)], minlength=4)
    assert counts[1] == 0 and (counts[[0, 2, 3]] > 800).all()


# ------------------------------------------------------------------ Bellman target
class _FixedQ(nn.Module):
    """Stand-in target network returning a fixed table, so targets can be checked by hand."""
    def __init__(self, table):
        super().__init__()
        self.table = torch.tensor(table, dtype=torch.float32)
    def forward(self, obs):
        return self.table[obs[:, 0].long()]


def test_bellman_target_by_hand_with_masks_and_terminals():
    net = _FixedQ([[1.0, 5.0, 3.0],      # next state 0: action 1 has the highest Q (5) ...
                   [2.0, 9.0, 4.0]])     # next state 1
    next_obs = torch.tensor([[0.0], [0.0], [1.0]])
    next_masks = torch.tensor([[True, False, True],     # ... but is infeasible -> best allowed is 3
                               [True, True, True],      # all allowed -> 5
                               [True, True, True]])     # terminal below
    rewards, dones = torch.tensor([1.0, 1.0, 1.0]), torch.tensor([0.0, 0.0, 1.0])
    y = bellman_targets(net, rewards, next_obs, next_masks, dones, gamma=0.9)
    assert y.tolist() == pytest.approx([1.0 + 0.9 * 3.0, 1.0 + 0.9 * 5.0, 1.0])


# ------------------------------------------------------------------ learning
def _batch(obs, actions, rewards, next_obs, dones, n_actions):
    n = len(actions)
    return {"obs": np.asarray(obs, np.float32), "actions": np.asarray(actions, np.int64),
            "rewards": np.asarray(rewards, np.float32), "next_obs": np.asarray(next_obs, np.float32),
            "masks": np.ones((n, n_actions), bool), "next_masks": np.ones((n, n_actions), bool),
            "dones": np.asarray(dones, np.float32)}


def test_update_fits_a_fixed_batch_and_target_only_changes_on_sync():
    torch.manual_seed(0)
    learner = DQNLearner(2, 3, DQNConfig(hidden_sizes=(16,), lr=1e-2, gamma=0.0), seed=0)
    batch = _batch([[1, 0], [0, 1]], [0, 2], [1.0, -1.0], [[0, 0], [0, 0]], [1, 1], 3)
    target_before = [p.clone() for p in learner.target.parameters()]
    losses = [learner.update(batch)[0] for _ in range(300)]
    assert losses[-1] < 0.05 * losses[0]
    assert all(torch.equal(a, b) for a, b in zip(target_before, learner.target.parameters()))
    learner.sync_target()
    assert all(torch.equal(a, b) for a, b in zip(learner.online.parameters(), learner.target.parameters()))


def test_dqn_learns_a_contextual_bandit():
    torch.manual_seed(0)
    hp = DQNConfig(hidden_sizes=(32,), lr=3e-3, gamma=0.0, batch_size=64)
    learner, buf, rng = DQNLearner(3, 4, hp, seed=0), ReplayBuffer(5000, 3, 4), np.random.default_rng(0)
    mask = np.ones(4, bool)
    for _ in range(3000):
        ctx = int(rng.integers(3))
        obs = np.eye(3, dtype=np.float32)[ctx]
        a = learner.act(obs, mask, epsilon=1.0)
        buf.add(obs, mask, a, 1.0 if a == ctx else 0.0, obs, mask, True)
    for _ in range(600):
        learner.update(buf.sample(64, rng))
    assert all(learner.act(np.eye(3, dtype=np.float32)[c], mask) == c for c in range(3))


def test_dqn_uses_bootstrapping_to_prefer_a_delayed_larger_reward():
    """State A: action 0 -> reward 0, go to B ; action 1 -> reward 0.5, end.  State B: reward 1, end.
    With gamma 0.9, Q(A,0)=0.9 > Q(A,1)=0.5, which is only learnable through the target network."""
    torch.manual_seed(0)
    hp = DQNConfig(hidden_sizes=(16,), lr=5e-3, gamma=0.9, batch_size=64)
    learner, buf, rng = DQNLearner(2, 2, hp, seed=0), ReplayBuffer(4000, 2, 2), np.random.default_rng(0)
    A, B = np.array([1, 0], np.float32), np.array([0, 1], np.float32)
    mask = np.ones(2, bool)
    for _ in range(2000):
        a = int(rng.integers(2))
        if a == 0:
            buf.add(A, mask, 0, 0.0, B, mask, False)
            buf.add(B, mask, int(rng.integers(2)), 1.0, B, mask, True)
        else:
            buf.add(A, mask, 1, 0.5, A, mask, True)
    for step in range(1500):
        learner.update(buf.sample(64, rng))
        if step % 50 == 0:
            learner.sync_target()
    q = learner.q_values(A, mask)
    assert np.argmax(q) == 0 and q[0] == pytest.approx(0.9, abs=0.15) and q[1] == pytest.approx(0.5, abs=0.15)


# ------------------------------------------------------------------ checkpoints
def test_checkpoint_roundtrip_gives_identical_q_values(tmp_path):
    hp = DQNConfig(hidden_sizes=(16,))
    learners = {a: DQNLearner(7, 4, hp, seed=i) for i, a in enumerate(AGENTS)}
    save_dqn_checkpoint(tmp_path / "c.pt", learners, {"note": "test"})
    loaded = load_dqn_policy_set(tmp_path / "c.pt")
    obs, mask = np.random.default_rng(0).normal(size=7).astype(np.float32), np.array([True, False, True, True])
    for a in AGENTS:
        assert np.allclose(learners[a].q_values(obs, mask), loaded.learners[a].q_values(obs, mask))


# ------------------------------------------------------------------ training loop
def _short_config():
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.25
    return cfg


_FAST = {"steps_per_iteration": 100, "learning_starts": 50, "train_every": 2, "batch_size": 32,
         "target_update_every": 50, "hidden_sizes": [8], "epsilon_decay_rounds": 150}


def test_training_smoke_run_writes_logs_and_checkpoints(tmp_path):
    policies = train_dqn(_short_config(), "normal", tmp_path, iterations=2, seed=0,
                         dqn_overrides=_FAST, checkpoint_every=1, verbose=False)
    log = pd.read_csv(tmp_path / "train_log.csv")
    assert len(log) == 2 and np.isfinite(log.filter(like="_loss").iloc[-1].to_numpy()).all()
    assert log["epsilon"].iloc[0] > log["epsilon"].iloc[1] >= 0.05
    assert (tmp_path / "checkpoints" / "final.pt").exists()
    episodes = pd.read_csv(tmp_path / "episodes.csv")
    assert len(episodes) >= 1 and (episodes["env_seed"] >= 100_000).all()
    assert isinstance(policies, DQNPolicySet) and policies.epsilon == 0.0


def test_training_is_reproducible(tmp_path):
    kw = dict(iterations=1, seed=3, dqn_overrides=_FAST, verbose=False)
    a = train_dqn(_short_config(), "normal", tmp_path / "a", **kw)
    b = train_dqn(_short_config(), "normal", tmp_path / "b", **kw)
    for agent in AGENTS:
        for pa, pb in zip(a.learners[agent].online.parameters(), b.learners[agent].online.parameters()):
            assert torch.equal(pa, pb)


def test_evaluation_is_greedy_and_does_not_update_the_policy():
    cfg = _short_config()
    ma = HospitalMAEnv(cfg, "normal", seed=1)
    hp = DQNConfig(hidden_sizes=(8,))
    learners = {a: DQNLearner(ma.obs_dims[a], ma.n_actions[a], hp, seed=i) for i, a in enumerate(AGENTS)}
    before = {a: [p.clone() for p in l.online.parameters()] for a, l in learners.items()}
    df = evaluate_ma_policy(cfg, "normal", DQNPolicySet(learners), [1000, 1001], "dqn_test")
    assert len(df) == 2 and {"episode_return", "throughput"} <= set(df.columns)
    for a in AGENTS:
        assert all(torch.equal(b, p) for b, p in zip(before[a], learners[a].online.parameters()))
    again = evaluate_ma_policy(cfg, "normal", DQNPolicySet(learners), [1000, 1001], "dqn_test")
    assert df.drop(columns="eval_seconds").equals(again.drop(columns="eval_seconds"))
