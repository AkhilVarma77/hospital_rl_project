"""Environment behaviour: clock, patient pathway, resource release, metrics, reproducibility."""
import pytest

from src.environment.hospital_env import HospitalEnv
from src.environment.hospital_state import AGENTS, Action, Stage
from src.utils.config import load_config
from tests.helpers import greedy_policy, make_config, make_env, patient, run_episode


def test_reset_and_arrivals_follow_the_clock():
    env = make_env([patient(0, arrival_time=0), patient(1, arrival_time=20, arrival_step=1)])
    assert env.state.time == 0 and set(env.state.patients) == {0}
    env.step({})                                   # t=15
    assert set(env.state.patients) == {0}          # arrival at 20 not visible yet
    res = env.step({})                             # t=30
    assert set(env.state.patients) == {0, 1} and res.stats["new_arrivals"] == 1


def test_full_pathway_without_surgery():
    env = make_env([patient(0, expected_length_of_stay=100)])
    env.step({"bed": [Action("bed", 0, 1)], "doctor": [Action("doctor", 0, 0)]})   # same step
    p = env.state.patients[0]
    assert p.stage == Stage.IN_TREATMENT and p.admit_time == 0 and p.treatment_start == 0
    assert env.state.beds[1].expected_release == 100        # uses the ESTIMATE, not the truth
    assert not env.state.doctors[0].is_free
    env.step({})                                            # t=30 -> treatment released
    assert p.stage == Stage.RECOVERY and p.care_done_time == 30 and env.state.doctors[0].is_free
    while p.stage != Stage.DISCHARGED:
        env.step({})
    assert p.discharge_time == 120                          # admit(0) + true LOS(120)
    assert env.state.beds[1].is_free
    assert env.state.validate_consistency() == []

    s = env.get_episode_summary()
    assert s["patients_arrived"] == 1 and s["throughput"] == 1
    assert s["treatments_completed"] == 1 and s["surgeries_completed"] == 0
    assert s["mean_bed_wait"] == 0 and s["emergency_response_delay"] == 0
    assert s["general_bed_utilization"] == pytest.approx(120 / (2 * 120))
    assert s["icu_bed_utilization"] == 0
    assert s["doctor_utilization"] == pytest.approx(30 / (2 * 120))
    assert s["or_utilization"] == 0 and s["invalid_actions_total"] == 0


def test_full_pathway_with_surgery():
    env = make_env([patient(0, required_specialization="cardiology", requires_surgery=True,
                            surgery_type="cardiac", surgery_duration=60, est_surgery_duration=60,
                            length_of_stay=200, expected_length_of_stay=200)])
    env.step({"bed": [Action("bed", 0, 1)], "doctor": [Action("doctor", 0, 1)]})
    env.step({})                                            # t=30 treatment done
    p = env.state.patients[0]
    assert p.stage == Stage.WAITING_SURGERY and env.state.doctors[1].is_free
    env.step({"or": [Action("or", 0, 0)]})                  # surgery 30 -> 90
    assert p.stage == Stage.IN_SURGERY and p.surgeon_id == 1 and p.or_id == 0
    assert not env.state.ors[0].is_free and env.state.doctors[1].activity == "surgery"
    assert env.validate(Action("or", 0, 0)) == "wrong_stage"
    while p.stage == Stage.IN_SURGERY:
        env.step({})
    assert p.surgery_released == 90 and p.care_done_time == 90
    assert env.state.ors[0].is_free and env.state.doctors[1].is_free
    while p.stage != Stage.DISCHARGED:
        env.step({})
    assert p.discharge_time == 210                          # first boundary >= admit+200
    s = env.get_episode_summary()
    assert s["surgeries_completed"] == 1 and s["mean_or_wait"] == 0
    assert s["or_utilization"] == pytest.approx(60 / (1 * 210))


def test_waiting_times_are_measured():
    env = make_env([patient(0, arrival_time=10, arrival_step=0)])
    env.step({}); env.step({})                              # t=30, patient arrived at 10
    env.step({"bed": [Action("bed", 0, 1)], "doctor": [Action("doctor", 0, 0)]})
    s = env.get_episode_summary()
    assert s["mean_bed_wait"] == 20 and s["emergency_response_delay"] == 20
    assert s["mean_doctor_wait"] == 0


def test_unserved_patients_are_reported_not_ignored():
    env = make_env([patient(0)])
    env.step({}); env.step({})
    s = env.get_episode_summary()
    assert s["unserved_patients"] == 1 and s["mean_wait_to_treatment"] is None
    assert s["unserved_mean_censored_wait"] == 30


def test_episode_terminates_at_horizon():
    env = make_env([patient(0)])
    n = 0
    while not env.done:
        res = env.step({})
        n += 1
    assert n == env.horizon // env.step_minutes and res.done
    with pytest.raises(RuntimeError):
        env.step({})


def test_reset_restores_initial_state():
    env = make_env([patient(0)])
    env.step({"bed": [Action("bed", 0, 1)]})
    env.reset()
    assert env.state.time == 0 and env.state.patients[0].stage == Stage.WAITING_BED
    assert env.state.beds[1].is_free and env.action_counts["bed"]["executed"] == 0


@pytest.mark.parametrize("scenario", ["normal", "high_demand", "emergency_surge",
                                      "bed_shortage", "doctor_shortage", "or_shortage"])
def test_full_episode_keeps_state_consistent(scenario):
    env = HospitalEnv(load_config(), scenario, seed=3)
    run_episode(env, check=True)
    s = env.get_episode_summary()
    assert env.steps_taken == env.horizon // env.step_minutes
    assert s["patients_arrived"] > 0 and s["throughput"] <= s["patients_arrived"]
    assert s["treatments_completed"] >= s["throughput"] > 0
    for key in ("bed_utilization", "doctor_utilization", "or_utilization"):
        assert 0.0 <= s[key] <= 1.0, key
    assert s["invalid_actions_total"] == sum(s["invalid_actions"].values())
    # nobody is in two places at once
    busy = [d.patient_id for d in env.state.doctors if d.patient_id != -1]
    assert len(busy) == len(set(busy))
    occupants = [b.occupant_id for b in env.state.beds if b.occupant_id != -1]
    assert len(occupants) == len(set(occupants))


def test_same_seed_same_policy_gives_identical_results():
    def run():
        env = HospitalEnv(load_config(), "mixed_demand", seed=11)
        while not env.done:
            env.step(greedy_policy(env))
        return env.get_episode_summary()
    assert run() == run()


def test_different_seeds_give_different_results():
    def run(seed):
        env = HospitalEnv(load_config(), "normal", seed=seed)
        while not env.done:
            env.step(greedy_policy(env))
        return env.get_episode_summary()["patients_arrived"]
    assert run(1) != run(2)


def test_joint_execution_order_is_deterministic():
    env = make_env([patient(0)])
    res = env.step({"doctor": [Action("doctor", 0, 0)], "bed": [Action("bed", 0, 1)]})
    assert [r.action.agent for r in res.action_results] == ["bed", "doctor"]
    assert all(r.status == "executed" for r in res.action_results)
