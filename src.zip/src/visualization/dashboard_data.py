"""Data preparation for the HTML dashboard (docs/dashboard.html).

Everything the dashboard shows comes from one of three sources, and the page labels each:
  * RECORDED REPLAY   - an episode actually played by the Python simulator (this module records it),
  * MEASURED RESULTS  - the experiment tables written by scripts/run_all_experiments.py,
  * PREDICTION        - output of the demand forecaster during the replay.
The page never re-implements the simulation; it only replays recorded data.
"""
from __future__ import annotations

import base64
import json
import re
from pathlib import Path
from typing import Any, Optional, Sequence

import numpy as np
import pandas as pd

from src.baselines.registry import make_baseline
from src.environment.hospital_env import EXECUTED, INVALID, HospitalEnv
from src.environment.hospital_state import AGENTS, Stage
from src.environment.multi_agent_env import HospitalMAEnv
from src.evaluation.compare_algorithms import METRICS
from src.evaluation.evaluate import flatten_summary
from src.forecasting.demand_forecaster import DemandForecaster, ForecastProvider, make_forecast_provider
from src.rewards.reward_calculator import RewardCalculator

AGENT_INDEX = {name: i for i, name in enumerate(AGENTS)}           # bed 0, doctor 1, or 2
SUMMARY_KEYS = ["patients_arrived", "throughput", "mean_wait_to_treatment", "emergency_response_delay",
                "emergency_surgery_wait", "unserved_patients", "bed_utilization", "doctor_utilization",
                "or_utilization", "invalid_actions_total"]


# ------------------------------------------------------------------------- replay
def _meta(env: HospitalEnv, kind: str, policy: str, scenario: str, seed: int,
          forecast: Optional[str]) -> dict[str, Any]:
    s = env.state
    return {"scenario": scenario, "seed": seed, "policy": policy, "kind": kind,
            "step_minutes": env.step_minutes, "horizon": env.horizon,
            "beds": [b.bed_type for b in s.beds],
            "doctors": [d.specialization for d in s.doctors],
            "n_ors": len(s.ors), "forecast": forecast,
            "reward_weights": RewardCalculator(env.cfg).w}


def _snapshot(env: HospitalEnv, results, stats: dict[str, Any], reward: float, comps: Sequence[float],
              k: int, forecast: Optional[Sequence[float]]) -> dict[str, Any]:
    s = env.state
    step = env.step_minutes
    arrivals = [p for p in s.patients.values() if p.arrival_time // step == k]
    treated = [p.treatment_start - p.arrival_time for p in s.patients.values() if p.treatment_start >= 0]
    n_busy_beds = sum(1 for b in s.beds if not b.is_free)
    acts = []
    for r in results:
        if r.status == EXECUTED and not r.action.is_defer:
            p = s.patients[r.action.patient_id]
            acts.append([AGENT_INDEX[r.action.agent], p.patient_id, r.action.resource_id,
                         p.urgency_level, int(p.is_emergency)])
    return {
        "t": s.time,
        "wq": [len(s.stage_sets[Stage.WAITING_BED]), len(s.stage_sets[Stage.WAITING_DOCTOR]),
               len(s.stage_sets[Stage.WAITING_SURGERY])],
        "we": [stats["waiting_emergency"]["bed"], stats["waiting_emergency"]["doctor"],
               stats["waiting_emergency"]["surgery"]],
        "beds": [0 if b.is_free else (2 if s.patients[b.occupant_id].is_emergency else 1) for b in s.beds],
        "docs": [0 if d.is_free else (1 if d.activity == "treatment" else 2) for d in s.doctors],
        "ors": [0 if o.is_free else 1 for o in s.ors],
        "arr": [len(arrivals), sum(p.is_emergency for p in arrivals)],
        "fc": None if forecast is None else [round(float(forecast[0]), 3), round(float(forecast[1]), 3)],
        "acts": acts,
        "inv": sum(1 for r in results if r.status == INVALID),
        "dis": stats["discharges"],
        "util": [round(n_busy_beds / max(len(s.beds), 1), 3),
                 round(sum(1 for d in s.doctors if not d.is_free) / max(len(s.doctors), 1), 3),
                 round(sum(1 for o in s.ors if not o.is_free) / max(len(s.ors), 1), 3)],
        "rew": round(float(reward), 4),
        "rc": [round(float(c), 4) for c in comps],
        "mw": round(float(np.mean(treated)), 2) if treated else None,
    }


def _forecast_at(provider: Optional[ForecastProvider], env: HospitalEnv) -> Optional[np.ndarray]:
    if provider is None:
        return None
    hist, k = provider.history(env)
    return provider.forecaster.predict(hist, k)


def _finish(meta, steps, env: HospitalEnv) -> dict[str, Any]:
    flat = flatten_summary(env.get_episode_summary())
    meta = {**meta, "n_steps": len(steps)}
    return {"meta": meta, "steps": steps,
            "summary": {k: (None if flat.get(k) is None else round(float(flat[k]), 3)) for k in SUMMARY_KEYS}}


def record_baseline_replay(config: dict[str, Any], scenario: str, seed: int, policy_name: str,
                           forecaster: Optional[DemandForecaster] = None) -> dict[str, Any]:
    """Play one episode with a rule-based baseline and record every clock step."""
    env = HospitalEnv(config, scenario, seed=seed)
    policy = make_baseline(policy_name)
    calc = RewardCalculator(env.cfg)
    provider = ForecastProvider(forecaster, env.step_minutes) if forecaster else None
    meta = _meta(env, "baseline", policy_name, scenario, seed, forecaster.name if forecaster else None)
    steps = []
    while not env.done:
        k = env.state.time // env.step_minutes
        fc = _forecast_at(provider, env)
        policy.dispatch(env)
        result = env.advance()
        b = calc.compute(env.state, result.action_results, result.stats)
        steps.append(_snapshot(env, result.action_results, result.stats, b.total,
                               [b.waiting, b.emergency, b.utilization, b.throughput, b.conflict], k, fc))
    return _finish(meta, steps, env)


def record_learned_replay(config: dict[str, Any], scenario: str, seed: int, name: str, policies: Any,
                          forecaster: Optional[DemandForecaster] = None) -> dict[str, Any]:
    """Play one episode with a trained policy set (greedy) and record every clock step.
    Several decision rounds can happen inside one clock step; their actions are merged."""
    ma = HospitalMAEnv(config, scenario, seed=seed,
                       forecast_provider=make_forecast_provider(getattr(policies, "forecast_spec", None),
                                                                step_minutes=15))
    display = ForecastProvider(forecaster, ma.env.step_minutes) if forecaster else None
    meta = _meta(ma.env, "learned", name, scenario, seed, forecaster.name if forecaster else None)
    obs, info = ma.reset()
    steps, results, reward, fc = [], [], 0.0, _forecast_at(display, ma.env)
    k = 0
    while not ma.done:
        obs, rewards, _, info = ma.step(policies.act(obs, info["masks"]))
        results.extend(info["round_results"])
        reward += rewards[AGENTS[0]]
        if info["clock_advanced"]:
            c = info["reward_components"]
            steps.append(_snapshot(ma.env, results, info["step_stats"], reward,
                                   [c["waiting"], c["emergency"], c["utilization"], c["throughput"], c["conflict"]],
                                   k, fc))
            results, reward, k = [], 0.0, k + 1
            if not ma.done:
                fc = _forecast_at(display, ma.env)
    return _finish(meta, steps, ma.env)


# ----------------------------------------------------------------------- results tables
_LABEL_TO_KEY = {label: key for key, (label, _) in METRICS.items()}


def _parse_cell(cell: str) -> Optional[list[Optional[float]]]:
    cell = cell.strip()
    if cell in ("n/a", "nan", ""):
        return None
    if "±" in cell:
        mean, std = (x.strip() for x in cell.split("±"))
        return [float(mean), float(std)]
    return [float(cell), None]


def _parse_table(lines: list[str]) -> tuple[list[str], list[tuple[str, list[str]]]]:
    rows = [[c.strip() for c in ln.strip().strip("|").split("|")] for ln in lines if ln.strip().startswith("|")]
    header, body = rows[0], [r for r in rows[2:]]
    return header[1:], [(r[0], r[1:]) for r in body]


def parse_results_summary(path: str | Path) -> dict[str, Any]:
    """Read results_summary.md (written by the experiment suite) into a JSON-friendly dict:
    {"methods": [...], "scenarios": [...], "intro": str, "metrics": {key: {"label", "lower_better",
    "overall": {method: [mean, std]}, "scenarios": {scenario: {method: [mean, std]}}}}}"""
    text = Path(path).read_text(encoding="utf-8").replace("\r\n", "\n")
    parts = re.split(r"\n## ", text)
    intro = " ".join(x.strip() for x in parts[0].split("\n") if x.strip() and not x.startswith("#"))
    out: dict[str, Any] = {"methods": [], "scenarios": [], "intro": intro, "metrics": {}}
    for part in parts[1:]:
        title, _, body = part.partition("\n")
        table_lines = [ln for ln in body.split("\n") if ln.strip().startswith("|")]
        if not table_lines:
            continue
        methods, rows = _parse_table(table_lines)
        if title.startswith("Overall"):
            out["methods"] = methods
            for label, cells in rows:
                key = _LABEL_TO_KEY.get(label)
                if key:
                    m = out["metrics"].setdefault(key, {"label": label, "lower_better": METRICS[key][1],
                                                         "overall": {}, "scenarios": {}})
                    m["overall"] = {meth: _parse_cell(c) for meth, c in zip(methods, cells)}
            continue
        label = re.sub(r"\s*\((lower|higher) is better\)\s*$", "", title).strip()
        key = _LABEL_TO_KEY.get(label)
        if key is None or key not in out["metrics"]:
            continue
        for scenario, cells in rows:
            out["metrics"][key]["scenarios"][scenario] = {meth: _parse_cell(c) for meth, c in zip(methods, cells)}
            if scenario not in out["scenarios"]:
                out["scenarios"].append(scenario)
    return out


# ----------------------------------------------------------------------------- helpers
def load_forecast_metrics(path: str | Path) -> list[dict[str, Any]]:
    df = pd.read_csv(path)
    keep = [c for c in ["model", "scenario", "mae_total", "rmse_total", "mae_emergency", "rmse_emergency",
                        "mean_actual_total"] if c in df.columns]
    return json.loads(df[keep].round(4).to_json(orient="records"))


def image_data_uri(path: str | Path) -> str:
    return "data:image/png;base64," + base64.b64encode(Path(path).read_bytes()).decode("ascii")


def to_script_json(obj: Any) -> str:
    """JSON that is safe to embed inside an HTML <script> element."""
    # every "<" becomes the JSON escape \u003c, so no "</script>" or "<!--" can appear in the HTML
    return json.dumps(obj, separators=(",", ":")).replace("<", "\\u003c")
