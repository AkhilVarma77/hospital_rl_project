"""Record ONE episode as a replay file that you can load into the dashboard.

    python scripts/export_dashboard_data.py --scenario high_demand --seed 1002 --policy severity --out replay.json
    python scripts/export_dashboard_data.py --scenario normal --model ppo ppo results/logs/ppo_normal_seed0/checkpoints/final.pt --out ppo_replay.json

In the dashboard's "Simulation replay" tab use "Load another replay" to open the file.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

from src.baselines.registry import BASELINES  # noqa: E402
from src.forecasting.demand_forecaster import load_forecaster  # noqa: E402
from src.training.train_comm_ppo import load_comm_policy_set  # noqa: E402
from src.training.train_dqn import load_dqn_policy_set  # noqa: E402
from src.training.train_ppo import load_policy_set  # noqa: E402
from src.utils.config import load_config  # noqa: E402
from src.visualization.dashboard_data import record_baseline_replay, record_learned_replay  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default=None)
    parser.add_argument("--scenario", default="normal")
    parser.add_argument("--seed", type=int, default=1000)
    parser.add_argument("--policy", choices=sorted(BASELINES), default=None, help="rule-based baseline")
    parser.add_argument("--model", nargs=3, metavar=("NAME", "ALGO", "PATH"), default=None,
                        help="trained policy: NAME, ALGO in {ppo, dqn, comm_ppo}, checkpoint PATH")
    parser.add_argument("--forecast-model", default=None, help="forecaster for the prediction curve")
    parser.add_argument("--out", default="replay.json")
    args = parser.parse_args()
    if (args.policy is None) == (args.model is None):
        parser.error("give exactly one of --policy or --model")

    config = load_config(args.config)
    forecaster = load_forecaster(args.forecast_model) if args.forecast_model else None
    if args.policy:
        replay = record_baseline_replay(config, args.scenario, args.seed, args.policy, forecaster)
    else:
        name, algo, path = args.model
        loaders = {"ppo": load_policy_set, "dqn": load_dqn_policy_set, "comm_ppo": load_comm_policy_set}
        replay = record_learned_replay(config, args.scenario, args.seed, name, loaders[algo](path), forecaster)
    Path(args.out).write_text(json.dumps(replay, separators=(",", ":")), encoding="utf-8")
    print(f"wrote {args.out}: {replay['meta']['n_steps']} steps")


if __name__ == "__main__":
    main()
