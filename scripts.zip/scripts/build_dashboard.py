"""Build the self-contained HTML dashboard: docs/dashboard.html

    python scripts/build_dashboard.py                  # baseline replays + your result tables
    python scripts/build_dashboard.py --models         # also replay your trained policies

Inputs (all optional; missing ones are skipped and the page says so):
  results/experiments/default/results_summary.md   measured results (from run_all_experiments.py)
  results/forecaster/forecast_metrics.csv          forecaster metrics (from run_forecaster.py)
  results/forecaster/lstm.pt                       forecaster used for the prediction curve in replays
  results/experiments/default/runs/<method>_seed0/checkpoints/final.pt   with --models
The page needs no internet connection and no server: open docs/dashboard.html in a browser.
"""
from __future__ import annotations

import argparse
import datetime
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

from src.evaluation.experiments import METHODS, _LOADERS  # noqa: E402
from src.forecasting.demand_forecaster import load_forecaster  # noqa: E402
from src.utils.config import load_config  # noqa: E402
from src.visualization.dashboard_data import (  # noqa: E402
    image_data_uri, load_forecast_metrics, parse_results_summary, record_baseline_replay,
    record_learned_replay, to_script_json)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default=None)
    parser.add_argument("--results", default="results/experiments/default/results_summary.md")
    parser.add_argument("--forecast-metrics", default="results/forecaster/forecast_metrics.csv")
    parser.add_argument("--forecast-model", default="results/forecaster/lstm.pt")
    parser.add_argument("--scenarios", nargs="+", default=["normal", "emergency_surge"])
    parser.add_argument("--seed", type=int, default=1000, help="evaluation seed of the replays")
    parser.add_argument("--baselines", nargs="+", default=["fcfs", "severity"])
    parser.add_argument("--models", action="store_true", help="also replay trained policies from --runs-dir")
    parser.add_argument("--runs-dir", default="results/experiments/default/runs")
    parser.add_argument("--model-methods", nargs="+",
                        default=["ppo_independent", "comm_attention", "comm_attention_forecast", "dqn"])
    parser.add_argument("--train-seed", type=int, default=0, help="which training run to replay")
    parser.add_argument("--template", default="docs/dashboard_template.html")
    parser.add_argument("--figures", default="docs/figures")
    parser.add_argument("--out", default="docs/dashboard.html")
    args = parser.parse_args()

    config = load_config(args.config)
    data: dict = {"build": {"generated": datetime.date.today().isoformat(), "results_source": None}}

    results = Path(args.results)
    if results.exists():
        data["results"] = parse_results_summary(results)
        data["build"]["results_source"] = str(results)
    else:
        print(f"note: {results} not found; the results explorer will be empty")
        data["results"] = None

    fm = Path(args.forecast_metrics)
    if fm.exists():
        data["forecast"] = {"rows": load_forecast_metrics(fm),
                            "source": f"Measured on held-out simulated episodes (test seeds 1000+), file {fm.name}."}
    else:
        print(f"note: {fm} not found; the forecasting tab will be empty")

    forecaster = None
    if Path(args.forecast_model).exists():
        forecaster = load_forecaster(args.forecast_model)
    else:
        print(f"note: {args.forecast_model} not found; replays will have no prediction curve")

    replays = []
    for scenario in args.scenarios:
        for name in args.baselines:
            print(f"recording {name} on {scenario} (seed {args.seed})", flush=True)
            replays.append(record_baseline_replay(config, scenario, args.seed, name, forecaster))
        if args.models:
            for method in args.model_methods:
                ckpt = Path(args.runs_dir) / f"{method}_seed{args.train_seed}" / "checkpoints" / "final.pt"
                if not ckpt.exists():
                    print(f"note: {ckpt} not found; skipping {method}")
                    continue
                print(f"recording {method} (training run {args.train_seed}) on {scenario}", flush=True)
                policies = _LOADERS[METHODS[method]["algo"]](ckpt)
                replays.append(record_learned_replay(config, scenario, args.seed,
                                                     f"{method} (run {args.train_seed})", policies, forecaster))
    data["replays"] = replays

    figures = Path(args.figures)
    data["images"] = {n: image_data_uri(figures / f"{n}.png") for n in ("architecture", "workflow", "patient_pathway")
                      if (figures / f"{n}.png").exists()}

    template = Path(args.template).read_text(encoding="utf-8")
    assert "/*__DATA__*/" in template, "template placeholder missing"
    html = template.replace("/*__DATA__*/", to_script_json(data))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"wrote {out} ({out.stat().st_size // 1024} KB, {len(replays)} replays). Open it in a browser.")


if __name__ == "__main__":
    main()
