"""Draw the architecture, workflow and patient-pathway diagrams used in the report.

    python scripts/make_diagrams.py        # writes docs/figures/*.png
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt                       # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "docs" / "figures"
COLORS = {"data": "#dbe9f6", "env": "#fde9c9", "agent": "#dff0d8", "learn": "#eadcf4",
          "opt": "#f5f5f5", "eval": "#f9dcdc"}


def box(ax, x, y, w, h, text, kind, fontsize=9, dashed=False, bold=False):
    patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12",
                           fc=COLORS[kind], ec="#444444", lw=1.3, ls="--" if dashed else "-")
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fontsize,
            fontweight="bold" if bold else "normal", wrap=True)
    return (x, y, w, h)


def arrow(ax, p1, p2, text=None, rad=0.0, color="#333333", fs=8, off=(0, 0.12)):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=14, lw=1.4, color=color,
                                 connectionstyle=f"arc3,rad={rad}"))
    if text:
        ax.text((p1[0] + p2[0]) / 2 + off[0], (p1[1] + p2[1]) / 2 + off[1], text, fontsize=fs,
                ha="center", color=color)


def new_fig(w, h, title):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.axis("off")
    ax.set_title(title, fontsize=13, fontweight="bold", pad=10)
    return fig, ax


def architecture():
    fig, ax = new_fig(13, 8.4, "System architecture (blue = data, orange = environment, green = agents, "
                              "purple = learning, grey dashed = optional)")
    box(ax, 0.4, 6.9, 3.6, 1.0, "Synthetic data generator\nconfig + seed -> patients, beds,\ndoctors, ORs, events", "data")
    box(ax, 4.7, 6.2, 3.9, 2.0, "HOSPITAL ENVIRONMENT\n(single source of truth)\nclock, queues, beds, doctors, ORs,\nhard clinical constraints,\njoint action execution, outages",
        "env", bold=True)
    box(ax, 9.3, 6.9, 3.3, 1.0, "Reward calculator\nshared reward R = -w1W - w2E\n+ w3U + w4T - w5C", "learn")
    box(ax, 0.4, 4.7, 3.6, 1.1, "Demand forecaster (optional)\nLSTM / moving average\nnext-step arrivals", "opt", dashed=True)
    box(ax, 4.7, 4.5, 3.9, 1.1, "Agent interfaces (Bed | Doctor | OR)\nlocal observation, K=8 queue slots,\naction mask, action decoding", "agent")
    box(ax, 9.3, 4.7, 3.3, 1.1, "Communication (optional)\nmessage encoders +\nscaled dot-product attention", "opt", dashed=True)
    box(ax, 4.7, 2.5, 3.9, 1.3, "Policies (one per agent)\nPPO actor-critic  |  DQN Q-network\nmasked, discrete K+1 actions", "learn")
    box(ax, 0.4, 2.5, 3.6, 1.3, "Rule-based baselines\nFCFS | severity priority\n(sequential, conflict-free)", "agent")
    box(ax, 9.3, 2.5, 3.3, 1.3, "Training loops\nPPO | DQN | comm-PPO\nseeds, logs, checkpoints", "learn")
    box(ax, 0.4, 0.4, 12.2, 1.2, "Evaluation & experiments: episode metrics (wait, emergency delay, utilization, throughput, invalid actions)  ->  "
                                  "multi-seed tables, plots, report\nsame simulator, scenarios and evaluation seeds for every method", "eval", bold=True)
    arrow(ax, (4.0, 7.4), (4.7, 7.4), "patients")
    arrow(ax, (8.6, 7.3), (9.3, 7.4), "state/stats", off=(0, 0.15))
    arrow(ax, (6.65, 6.2), (6.65, 5.6), "state")
    arrow(ax, (4.0, 5.25), (4.7, 5.05), "forecast", off=(0, 0.14))
    arrow(ax, (9.3, 5.2), (8.6, 5.05), "messages", off=(0, 0.14))
    arrow(ax, (6.65, 4.5), (6.65, 3.8), "obs + masks")
    arrow(ax, (8.0, 3.8), (8.0, 4.5), "action idx", off=(0.55, 0.0))
    arrow(ax, (8.6, 3.15), (9.3, 3.15), "experience")
    ax.plot([12.6, 12.85, 12.85], [7.4, 7.4, 3.15], color="#333333", lw=1.4)
    arrow(ax, (12.85, 3.15), (12.6, 3.15), "")
    ax.text(12.9, 5.3, "reward", rotation=90, fontsize=8, va="center", color="#333333")
    arrow(ax, (5.2, 5.6), (5.2, 6.2), "actions", off=(-0.45, 0.0))
    arrow(ax, (2.2, 2.5), (2.2, 1.6), "")
    arrow(ax, (6.65, 2.5), (6.65, 1.6), "")
    arrow(ax, (10.95, 2.5), (10.95, 1.6), "")
    ax.text(0.4, 6.4, "(forecast and communication can be switched off for the ablations)", fontsize=8, style="italic")
    fig.tight_layout()
    fig.savefig(OUT / "architecture.png", dpi=150)
    plt.close(fig)


def workflow():
    fig, ax = new_fig(13, 7.6, "One decision round (a step of the multi-agent environment)")
    steps = [
        (0.4, 5.6, "1. Observe\nhospital state ->\nlocal observation\nper agent", "env"),
        (3.6, 5.6, "2. Forecast\n(optional)\nnext-step arrivals\ninto 2 features", "opt"),
        (6.8, 5.6, "3. Communicate\n(optional)\nmessages ->\nattention context", "opt"),
        (10.0, 5.6, "4. Choose actions\neach agent picks a\nqueue slot or defer\n(infeasible masked)", "agent"),
        (10.0, 3.3, "5. Validate + execute\nurgency order, hard\nconstraints; losers of\nconflicts rejected", "env"),
        (6.8, 3.3, "6. Reward + stats\nshared reward,\nper-agent diagnostics", "learn"),
        (3.6, 3.3, "7. Everyone done?\nvoluntary defer or\nnothing feasible", "opt"),
    ]
    for x, y, t, k in steps:
        box(ax, x, y, 2.9, 1.7, t, k, dashed=(k == "opt"))
    arrow(ax, (3.3, 6.45), (3.6, 6.45))
    arrow(ax, (6.5, 6.45), (6.8, 6.45))
    arrow(ax, (9.7, 6.45), (10.0, 6.45))
    arrow(ax, (11.45, 5.6), (11.45, 5.0))
    arrow(ax, (10.0, 4.15), (9.7, 4.15))
    arrow(ax, (6.8, 4.15), (6.5, 4.15))
    box(ax, 0.4, 3.3, 2.9, 1.7, "8a. NO: stay at this\nclock time, new round\nwith updated state\n(go to step 1)", "agent")
    arrow(ax, (3.6, 4.15), (3.3, 4.15), "no", off=(0, 0.12))
    arrow(ax, (1.85, 5.0), (1.85, 5.6), "")
    box(ax, 3.6, 0.8, 2.9, 1.5, "8b. YES: advance the clock\n15 min: finish treatments,\nsurgeries, discharges,\nnew arrivals", "env")
    arrow(ax, (5.05, 3.3), (5.05, 2.3), "yes", off=(0.3, 0))
    box(ax, 7.2, 0.8, 5.4, 1.5, "9. Store experience (obs, mask, action, reward, next obs)\n10. Update policies: PPO after each 1024-round rollout,\nDQN every 4 rounds from a replay buffer. Evaluation: greedy, no update.", "learn")
    arrow(ax, (6.5, 1.55), (7.2, 1.55))
    ax.text(0.4, 0.3, "Episode ends after 3 simulated days (288 clock steps).", fontsize=9, style="italic")
    fig.tight_layout()
    fig.savefig(OUT / "workflow.png", dpi=150)
    plt.close(fig)


def pathway():
    fig, ax = new_fig(13, 4.2, "Patient pathway in the simulated hospital")
    names = ["Waiting\nfor bed", "Waiting\nfor doctor", "In\ntreatment", "Waiting for\nsurgery\n(if needed)", "In\nsurgery", "Recovery", "Discharged"]
    who = ["Bed agent", "Doctor agent", "", "OR agent", "", "", ""]
    x = 0.3
    xs = []
    for i, n in enumerate(names):
        box(ax, x, 1.6, 1.55, 1.3, n, "agent" if i in (0, 1, 3) else "env", fontsize=9)
        xs.append(x)
        if who[i]:
            ax.text(x + 0.775, 3.1, who[i] + "\ndecides", ha="center", fontsize=8, color="#2d6a2d")
        x += 1.82
    for a, b in zip(xs[:-1], xs[1:]):
        arrow(ax, (a + 1.55, 2.25), (b, 2.25))
    ax.text(6.5, 0.9, "Bed: held from admission to discharge.  Doctor: needed for treatment, and (same specialization) as surgeon.  "
                      "OR: needed during surgery.", ha="center", fontsize=9)
    ax.text(6.5, 0.45, "Discharge when care is finished AND admission time + length of stay has passed.", ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(OUT / "patient_pathway.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    architecture()
    workflow()
    pathway()
    print("wrote", [p.name for p in sorted(OUT.glob("*.png"))])