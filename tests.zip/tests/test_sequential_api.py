"""The sequential interface (apply_action + advance) must agree with the batch step()."""
import pytest

from src.environment import constraints as C
from src.environment.hospital_state import Action, Stage
from tests.helpers import make_config, make_env, patient


def _snapshot(env):
    return {pid: (p.stage, p.bed_id, p.doctor_id, p.admit_time, p.treatment_start)
            for pid, p in env.state.patients.items()}


def test_apply_action_executes_immediately_without_advancing_time():
    env = make_env([patient(0)])
    res = env.apply_action(Action("bed", 0, 1))
    assert res.status == "executed"
    assert env.state.time == 0                                   # clock unchanged
    assert env.state.patients[0].stage == Stage.WAITING_DOCTOR   # state changed at once
    res2 = env.apply_action(Action("doctor", 0, 0))              # same step, live state
    assert res2.status == "executed"
    result = env.advance()
    assert result.time == 15 and len(result.action_results) == 2
    assert result.stats["executed"]["bed"] == 1 and result.stats["executed"]["doctor"] == 1


def test_sequential_matches_batch_step():
    batch, seq = make_env([patient(0), patient(1)]), make_env([patient(0), patient(1)])
    actions = [Action("bed", 0, 1), Action("bed", 1, 2), Action("doctor", 0, 0)]
    batch.step({"bed": actions[:2], "doctor": actions[2:]})
    for a in actions:
        seq.apply_action(a)
    seq.advance()
    assert _snapshot(batch) == _snapshot(seq)
    assert batch.action_counts == seq.action_counts


def test_action_limit_applies_to_sequential_interface():
    env = make_env([patient(0), patient(1)], make_config(max_actions=1))
    assert env.actions_remaining("bed") == 1
    assert env.apply_action(Action("bed", 0, 1)).status == "executed"
    assert env.actions_remaining("bed") == 0
    res = env.apply_action(Action("bed", 1, 2))
    assert (res.status, res.reason) == ("invalid", C.TOO_MANY_ACTIONS)
    assert env.state.patients[1].stage == Stage.WAITING_BED
    env.advance()
    assert env.actions_remaining("bed") == 1                     # limit resets every step


def test_sequential_invalid_action_is_rejected_and_counted():
    env = make_env([patient(0)])
    res = env.apply_action(Action("doctor", 0, 0))               # not admitted yet
    assert (res.status, res.reason) == ("invalid", C.WRONG_STAGE)
    assert env.action_counts["doctor"]["invalid"] == 1


def test_unknown_agent_and_finished_episode():
    env = make_env([patient(0)])
    with pytest.raises(ValueError):
        env.apply_action(Action("nurse", 0, 1))
    while not env.done:
        env.advance()
    with pytest.raises(RuntimeError):
        env.apply_action(Action("bed", 0, 1))
    with pytest.raises(RuntimeError):
        env.advance()
