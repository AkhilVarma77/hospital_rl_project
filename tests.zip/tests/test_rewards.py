"""Reward calculator: formula, sign conventions, configurability, no double counting."""
import pytest

from src.environment.hospital_env import ActionResult
from src.environment.hospital_state import Action
from src.rewards.reward_calculator import RewardCalculator
from tests.helpers import make_config, make_env, patient

STATS = {"waiting": {"bed": 2, "doctor": 1, "surgery": 0},
         "waiting_emergency": {"bed": 1, "doctor": 0, "surgery": 0}, "discharges": 1}


def _calc(**weights):
    cfg = make_config()
    cfg["rewards"]["weights"].update(weights)
    return RewardCalculator(cfg), make_env([patient(0)], cfg)


def test_formula_by_hand():
    calc, env = _calc()
    env.step({"bed": [Action("bed", 0, 1)]})                       # 1 of 3 beds occupied
    bad = ActionResult(Action("bed", 0, 1), "invalid", "resource_busy")
    r = calc.compute(env.state, [bad], STATS)
    W, E, T, C = 3 / 20, 1 / 3, 1.0, 1.0
    util = (min(1 / 3, 0.85) / 0.85 + min(0.0, 0.9) / 0.9 + 0.0) / 3     # beds, doctors, ORs
    assert r.waiting == pytest.approx(W) and r.emergency == pytest.approx(E)
    assert r.throughput == pytest.approx(T) and r.conflict == pytest.approx(C)
    assert r.utilization == pytest.approx(util)
    assert r.total == pytest.approx(-1.0 * W - 2.0 * E + 0.5 * util + 1.0 * T - 1.0 * C)
    assert r.advanced


def test_rounds_without_clock_advance_only_carry_the_conflict_term():
    calc, env = _calc()
    ok = ActionResult(Action("bed", 0, 1), "executed")
    bad = ActionResult(Action("bed", 0, 1), "invalid", "resource_busy")
    assert calc.compute(env.state, [ok], None).total == 0.0
    r = calc.compute(env.state, [ok, bad], None)
    assert r.total == pytest.approx(-1.0) and not r.advanced


def test_sign_conventions():
    calc, env = _calc()
    base = calc.compute(env.state, [], STATS).total
    more_wait = {**STATS, "waiting": {"bed": 5, "doctor": 1, "surgery": 0}}
    more_emerg = {**STATS, "waiting_emergency": {"bed": 3, "doctor": 0, "surgery": 0}}
    more_done = {**STATS, "discharges": 3}
    assert calc.compute(env.state, [], more_wait).total < base
    assert calc.compute(env.state, [], more_emerg).total < base
    assert calc.compute(env.state, [], more_done).total > base
    bad = ActionResult(Action("bed", 0, 1), "invalid", "resource_busy")
    assert calc.compute(env.state, [bad], STATS).total < base


def test_utilization_is_rewarded_only_up_to_the_ceiling():
    calc, env = _calc()
    from tests.helpers import make_env as me
    full = me([patient(i) for i in range(3)], make_config(general_beds=2, icu_beds=0))
    full.step({"bed": [Action("bed", 0, 0), Action("bed", 1, 1)]})   # both beds occupied (100%)
    half = me([patient(i) for i in range(3)], make_config(general_beds=2, icu_beds=0))
    half.step({"bed": [Action("bed", 0, 0)]})                         # 50% occupied
    assert calc.utilization_score(full.state) > calc.utilization_score(half.state)
    # 100% and 90% busy beds are both above the 0.85 ceiling -> same bed term
    assert min(1.0, 0.85) / 0.85 == min(0.9, 0.85) / 0.85 == 1.0


def test_weights_are_configurable():
    calc, env = _calc(waiting=0.0, emergency=0.0, utilization=0.0, throughput=0.0, conflict=0.0)
    bad = ActionResult(Action("bed", 0, 1), "invalid", "resource_busy")
    assert calc.compute(env.state, [bad], STATS).total == 0.0
    calc2, env2 = _calc(waiting=0.0, emergency=0.0, utilization=0.0, conflict=0.0, throughput=2.0)
    assert calc2.compute(env2.state, [], STATS).total == pytest.approx(2.0)


def test_agent_diagnostics_are_separate_from_the_training_reward():
    calc, env = _calc()
    env.step({"bed": [Action("bed", 0, 1)]})
    results = [ActionResult(Action("bed", 0, 1), "executed")]
    diag = calc.agent_diagnostics(env.state, results)
    assert set(diag) == {"bed", "doctor", "or"}
    assert diag["bed"]["executed"] == 1 and diag["doctor"]["waiting"] == 1
    assert calc.compute(env.state, results, None).total == 0.0   # diagnostics add nothing
