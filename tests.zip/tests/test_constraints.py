"""Hard-constraint tests: every invalid action must be rejected and leave the state unchanged."""
import pandas as pd
import pytest

from src.environment import constraints as C
from src.environment.hospital_state import Action, Stage
from tests.helpers import make_config, make_env, patient

# With make_config() defaults: bed 0 = ICU, beds 1-2 = general; doctor 0 = general_medicine,
# doctor 1 = cardiology; OR 0.


def _status(result, i=0):
    return result.action_results[i].status, result.action_results[i].reason


def test_busy_bed_is_rejected_and_state_unchanged():
    env = make_env([patient(0), patient(1)])
    res = env.step({"bed": [Action("bed", 0, 1), Action("bed", 1, 1)]})
    assert [r.status for r in res.action_results] == ["executed", "invalid"]
    assert res.action_results[1].reason == C.RESOURCE_BUSY
    assert env.state.patients[0].stage == Stage.WAITING_DOCTOR
    assert env.state.patients[1].stage == Stage.WAITING_BED       # unchanged
    assert env.state.beds[1].occupant_id == 0
    assert env.state.validate_consistency() == []


def test_bed_type_mismatch():
    env = make_env([patient(0, required_bed_type="icu"), patient(1)])
    assert env.validate(Action("bed", 0, 1)) == C.BED_TYPE_MISMATCH   # icu patient, general bed
    assert env.validate(Action("bed", 1, 0)) == C.BED_TYPE_MISMATCH   # general patient, icu bed


def test_wrong_stage():
    env = make_env([patient(0)])
    assert env.validate(Action("doctor", 0, 0)) == C.WRONG_STAGE      # not admitted yet
    assert env.validate(Action("or", 0, 0)) == C.WRONG_STAGE
    env.step({"bed": [Action("bed", 0, 1)]})
    assert env.validate(Action("bed", 0, 2)) == C.WRONG_STAGE         # already has a bed


def test_specialization_mismatch():
    env = make_env([patient(0, required_specialization="cardiology")])
    env.step({"bed": [Action("bed", 0, 1)]})
    assert env.validate(Action("doctor", 0, 0)) == C.SPECIALIZATION_MISMATCH
    assert env.validate(Action("doctor", 0, 1)) is None


def test_unknown_references():
    env = make_env([patient(0)])
    assert env.validate(Action("bed", 99, 1)) == C.UNKNOWN_PATIENT
    assert env.validate(Action("bed", 0, 99)) == C.UNKNOWN_RESOURCE
    assert env.validate(Action("bed", 0, None)) == C.UNKNOWN_RESOURCE
    assert env.validate(Action("nurse", 0, 1)) == C.UNKNOWN_AGENT


def test_wrong_agent_and_too_many_actions():
    env = make_env([patient(0), patient(1)], make_config(max_actions=1))
    res = env.step({"bed": [Action("bed", 0, 1), Action("bed", 1, 2)],
                    "doctor": [Action("bed", 0, 1)]})
    reasons = sorted(r.reason for r in res.action_results if r.status == "invalid")
    assert reasons == sorted([C.TOO_MANY_ACTIONS, C.WRONG_AGENT])
    assert env.state.patients[1].stage == Stage.WAITING_BED


def test_unknown_agent_key_raises():
    env = make_env([patient(0)])
    with pytest.raises(ValueError):
        env.step({"nurse": []})


def test_defer_is_neutral():
    env = make_env([patient(0)])
    res = env.step({"bed": [Action.defer("bed")]})
    assert _status(res) == ("deferred", "")
    assert env.action_counts["bed"]["deferred"] == 1
    assert env.action_counts["bed"]["invalid"] == 0


# ------------------------------------------------------------ emergency priority
def test_elective_blocked_when_emergency_competes_for_last_bed():
    env = make_env([patient(0), patient(1, is_emergency=False, urgency_level=1)],
                   make_config(general_beds=1))
    res = env.step({"bed": [Action("bed", 1, 1)]})            # only the elective acts
    assert _status(res) == ("invalid", C.EMERGENCY_PRIORITY)
    assert env.state.patients[1].stage == Stage.WAITING_BED


def test_elective_allowed_when_enough_beds_remain():
    env = make_env([patient(0), patient(1, is_emergency=False, urgency_level=1)],
                   make_config(general_beds=2))
    assert env.validate(Action("bed", 1, 1)) is None          # 2 free > 1 waiting emergency


def test_priority_rule_can_be_disabled():
    env = make_env([patient(0), patient(1, is_emergency=False, urgency_level=1)],
                   make_config(general_beds=1, priority=False))
    assert env.validate(Action("bed", 1, 1)) is None


def test_icu_reserve_blocks_elective_but_not_emergency():
    env = make_env([patient(0, is_emergency=False, required_bed_type="icu", urgency_level=2),
                    patient(1, required_bed_type="icu")], make_config(icu_beds=1, reserve=1))
    assert env.validate(Action("bed", 0, 0)) == C.ICU_RESERVE
    assert env.validate(Action("bed", 1, 0)) is None
    env0 = make_env([patient(0, is_emergency=False, required_bed_type="icu", urgency_level=2)],
                    make_config(icu_beds=1, reserve=0))
    assert env0.validate(Action("bed", 0, 0)) is None


def test_more_urgent_patient_wins_conflict_in_same_step():
    # Urgent patient 1 and less urgent patient 0 both want the single free general bed.
    env = make_env([patient(0, urgency_level=2), patient(1, urgency_level=4)],
                   make_config(general_beds=1))
    res = env.step({"bed": [Action("bed", 0, 1), Action("bed", 1, 1)]})
    assert env.state.patients[1].stage == Stage.WAITING_DOCTOR
    assert env.state.patients[0].stage == Stage.WAITING_BED
    assert res.action_results[0].action.patient_id == 1           # executed first


# ----------------------------------------------------------------- doctor / OR
def _surgery_conflict_env(urgency_a, urgency_b):
    """At t=30: patient A needs the only cardiologist as surgeon, patient B needs her for treatment."""
    pats = [
        patient(0, required_specialization="cardiology", requires_surgery=True,
                surgery_type="cardiac", surgery_duration=60, est_surgery_duration=60,
                urgency_level=urgency_a, length_of_stay=300, expected_length_of_stay=300),
        patient(1, required_specialization="cardiology", arrival_time=15, arrival_step=1,
                urgency_level=urgency_b, length_of_stay=300, expected_length_of_stay=300),
    ]
    env = make_env(pats, make_config(general_beds=2))
    env.step({"bed": [Action("bed", 0, 1)], "doctor": [Action("doctor", 0, 1)]})   # t=15
    env.step({"bed": [Action("bed", 1, 2)]})                                        # t=30
    assert env.state.time == 30
    assert env.state.patients[0].stage == Stage.WAITING_SURGERY
    assert env.state.patients[1].stage == Stage.WAITING_DOCTOR
    return env


def test_surgeon_conflict_urgent_surgery_wins():
    env = _surgery_conflict_env(urgency_a=4, urgency_b=3)
    res = env.step({"doctor": [Action("doctor", 1, 1)], "or": [Action("or", 0, 0)]})
    assert env.state.patients[0].stage == Stage.IN_SURGERY
    assert env.state.patients[1].stage == Stage.WAITING_DOCTOR
    loser = [r for r in res.action_results if r.status == "invalid"][0]
    assert loser.reason == C.RESOURCE_BUSY and loser.action.agent == "doctor"
    assert env.state.validate_consistency() == []


def test_surgeon_conflict_urgent_treatment_wins():
    env = _surgery_conflict_env(urgency_a=2, urgency_b=4)
    res = env.step({"doctor": [Action("doctor", 1, 1)], "or": [Action("or", 0, 0)]})
    assert env.state.patients[1].stage == Stage.IN_TREATMENT
    assert env.state.patients[0].stage == Stage.WAITING_SURGERY
    loser = [r for r in res.action_results if r.status == "invalid"][0]
    assert loser.reason == C.NO_SURGEON_FREE and loser.action.agent == "or"


def test_unsupported_surgery_type():
    cfg = make_config()
    cfg["resources"]["supported_surgery_types"] = ["orthopedic"]
    env = make_env([patient(0, required_specialization="cardiology", requires_surgery=True,
                            surgery_type="cardiac", surgery_duration=60, est_surgery_duration=60)], cfg)
    env.step({"bed": [Action("bed", 0, 1)], "doctor": [Action("doctor", 0, 1)]})
    env.step({}); env.step({})                                  # treatment ends at t=30
    assert env.state.patients[0].stage == Stage.WAITING_SURGERY
    assert env.validate(Action("or", 0, 0)) == C.SURGERY_TYPE_UNSUPPORTED


# ------------------------------------------------------------------ outages
def test_outage_blocks_resource_then_recovers():
    events = [dict(event_id=0, event_type="resource_outage", start_minute=0, end_minute=60,
                   magnitude=1, target="general_beds")]
    env = make_env([patient(0)], make_config(general_beds=2), events)
    assert env.state.blocked_beds == {2}                        # highest-id general bed
    assert env.validate(Action("bed", 0, 2)) == C.RESOURCE_UNAVAILABLE
    assert env.validate(Action("bed", 0, 1)) is None
    for _ in range(4):
        env.step({})
    assert env.state.time == 60 and env.state.blocked_beds == set()


def test_feasible_actions_are_individually_valid():
    env = make_env([patient(0), patient(1, required_bed_type="icu"),
                    patient(2, is_emergency=False, urgency_level=1)])
    for agent in ("bed", "doctor", "or"):
        for act in env.get_feasible_actions(agent):
            assert env.validate(act) is None
    assert len(env.get_feasible_actions("bed")) >= 1
    assert env.get_feasible_actions("doctor") == []             # nobody admitted yet
