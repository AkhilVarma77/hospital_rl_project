"""Run the rule-based baselines and save per-seed and summary tables.

Examples (project root, venv active):
    python scripts/run_baseline.py
    python scripts/run_baseline.py --policy fcfs --scenario high_demand --num-seeds 10
    python scripts/run_baseline.py --scenario all

Evaluation seeds start at 1000 by default so they never overlap with the seeds used for
training later. Outputs go to results/tables/.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

import pandas as pd  # noqa: E402
import yaml  # noqa: E402

from src.baselines.registry import BASELINES, make_baseline  # noqa: E402
from src.evaluation.evaluate import KEY_METRICS, evaluate_policy  # noqa: E402
from src.utils.config import load_config  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default=None)
    parser.add_argument("--policy", default="all", help=f"one of {sorted(BASELINES)} or 'all'")
    parser.add_argument("--scenario", default="normal", help="scenario name or 'all'")
    parser.add_argument("--num-seeds", type=int, default=5)
    parser.add_argument("--seed-start", type=int, default=1000)
    parser.add_argument("--out-dir", default="results/tables")
    args = parser.parse_args()

    config = load_config(args.config)
    policies = sorted(BASELINES) if args.policy == "all" else [args.policy]
    scenarios = list(config["scenarios"]) if args.scenario == "all" else [args.scenario]
    seeds = list(range(args.seed_start, args.seed_start + args.num_seeds))

    frames = []
    for scenario in scenarios:
        for name in policies:
            print(f"running {name} on {scenario} (seeds {seeds[0]}..{seeds[-1]}) ...", flush=True)
            frames.append(evaluate_policy(config, scenario, lambda n=name: make_baseline(n),
                                          seeds, name))
    per_seed = pd.concat(frames, ignore_index=True)

    summary = per_seed.groupby(["scenario", "policy"])[KEY_METRICS].agg(["mean", "std"])
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    per_seed.to_csv(out / "baseline_per_seed.csv", index=False)
    summary.to_csv(out / "baseline_summary.csv")
    with open(out / "baseline_run_config.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump({"args": vars(args), "seeds": seeds, "config": config}, f, sort_keys=False)

    pd.set_option("display.width", 250)
    pd.set_option("display.max_columns", 50)
    means = per_seed.groupby(["scenario", "policy"])[KEY_METRICS].mean().round(2)
    print("\nMean over seeds (std is in baseline_summary.csv):\n")
    print(means.to_string())
    print(f"\nSaved to {out}\\ : baseline_per_seed.csv, baseline_summary.csv, baseline_run_config.yaml")


if __name__ == "__main__":
    main()
