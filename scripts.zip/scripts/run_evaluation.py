"""Evaluate saved PPO / DQN / communicating-PPO checkpoints and print them next to the rule-based baselines.

Examples:
    python scripts/run_evaluation.py --model ppo ppo results/logs/ppo_normal_seed0/checkpoints/final.pt
    python scripts/run_evaluation.py --scenario all --num-seeds 5 ^
        --model ppo ppo results/logs/ppo_normal_seed0/checkpoints/final.pt ^
        --model dqn dqn results/logs/dqn_normal_seed0/checkpoints/final.pt

`--model NAME ALGO PATH` can be repeated (ALGO is ppo, dqn or comm_ppo). The older `--checkpoint PATH`
(PPO) still works. Policies act greedily and nothing is updated. Baselines run live on the SAME
seeds, so every method sees identical patient streams.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

import pandas as pd  # noqa: E402

from src.baselines.registry import BASELINES, make_baseline  # noqa: E402
from src.evaluation.evaluate import KEY_METRICS, evaluate_ma_policy, evaluate_policy  # noqa: E402
from src.training.train_comm_ppo import load_comm_policy_set  # noqa: E402
from src.training.train_dqn import load_dqn_policy_set  # noqa: E402
from src.training.train_ppo import load_policy_set  # noqa: E402
from src.utils.config import load_config  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default=None)
    parser.add_argument("--model", nargs=3, action="append", metavar=("NAME", "ALGO", "PATH"),
                        default=[])
    parser.add_argument("--checkpoint", default=None, help="legacy: a single PPO checkpoint")
    parser.add_argument("--scenario", default="normal", help="scenario name or 'all'")
    parser.add_argument("--num-seeds", type=int, default=5)
    parser.add_argument("--seed-start", type=int, default=1000)
    parser.add_argument("--no-baselines", action="store_true")
    parser.add_argument("--out-dir", default="results/tables")
    args = parser.parse_args()

    models = [tuple(m) for m in args.model]
    if args.checkpoint:
        models.append(("ppo_independent", "ppo", args.checkpoint))
    if not models:
        parser.error("give at least one --model NAME ALGO PATH (or --checkpoint PATH)")

    loaded = []
    for name, algo, path in models:
        loaders = {"ppo": load_policy_set, "dqn": load_dqn_policy_set, "comm_ppo": load_comm_policy_set}
        if algo not in loaders:
            parser.error(f"ALGO must be one of {sorted(loaders)}, got '{algo}'")
        loaded.append((name, loaders[algo](path)))

    config = load_config(args.config)
    scenarios = list(config["scenarios"]) if args.scenario == "all" else [args.scenario]
    seeds = list(range(args.seed_start, args.seed_start + args.num_seeds))

    frames = []
    for sc in scenarios:
        for name, policies in loaded:
            print(f"evaluating {name} on {sc} ...", flush=True)
            frames.append(evaluate_ma_policy(config, sc, policies, seeds, name))
        if not args.no_baselines:
            for b in sorted(BASELINES):
                frames.append(evaluate_policy(config, sc, lambda n=b: make_baseline(n), seeds, b))
    per_seed = pd.concat(frames, ignore_index=True)

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    per_seed.to_csv(out / "model_comparison_per_seed.csv", index=False)
    pd.set_option("display.width", 250)
    pd.set_option("display.max_columns", 50)
    print("\nMean over seeds:\n")
    print(per_seed.groupby(["scenario", "policy"])[KEY_METRICS].mean().round(2).to_string())
    print(f"\nSaved to {out}")


if __name__ == "__main__":
    main()