"""Comparison figures: metric by scenario for every method, with spread across seeds."""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Sequence

import matplotlib

matplotlib.use("Agg")                      # no display needed
import matplotlib.pyplot as plt            # noqa: E402
import numpy as np                         # noqa: E402
import pandas as pd                        # noqa: E402

from src.evaluation.compare_algorithms import METRICS  # noqa: E402


def plot_metric_by_scenario(summary: pd.DataFrame, metric: str, path: str | Path,
                            methods: Optional[Sequence[str]] = None) -> None:
    """Grouped bars: x = scenario, one bar per method, error bars = std across seeds/runs."""
    mean = summary.pivot(index="scenario", columns="method", values=f"{metric}_mean")
    std = summary.pivot(index="scenario", columns="method", values=f"{metric}_std").fillna(0.0)
    methods = [m for m in (methods or list(mean.columns)) if m in mean.columns]
    scenarios = list(mean.index)
    x = np.arange(len(scenarios))
    width = 0.8 / max(len(methods), 1)
    fig, ax = plt.subplots(figsize=(max(8, 1.6 * len(scenarios)), 4.8))
    for i, m in enumerate(methods):
        ax.bar(x + (i - (len(methods) - 1) / 2) * width, mean[m].values, width, yerr=std[m].values,
               capsize=2, label=m)
    label, lower_better = METRICS.get(metric, (metric, True))
    ax.set_xticks(x)
    ax.set_xticklabels(scenarios, rotation=20, ha="right")
    ax.set_ylabel(label)
    ax.set_title(f"{label} ({'lower' if lower_better else 'higher'} is better)")
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=130)
    plt.close(fig)
