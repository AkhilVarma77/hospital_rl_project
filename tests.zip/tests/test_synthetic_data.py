"""Tests for config loading and the synthetic data generator."""
import copy

import pandas as pd
import pytest

from src.data.synthetic_data_generator import SyntheticDataGenerator
from src.utils.config import get_scenario_config, load_config, validate_config


@pytest.fixture(scope="module")
def config():
    return load_config()


@pytest.fixture(scope="module")
def tables(config):
    return SyntheticDataGenerator(config, "normal", seed=1).generate_all()


# ------------------------------------------------------------------ config
def test_all_scenarios_load_and_validate(config):
    expected = {"normal", "high_demand", "emergency_surge", "bed_shortage",
                "doctor_shortage", "or_shortage", "mixed_demand"}
    assert expected <= set(config["scenarios"])
    for name in expected:
        get_scenario_config(config, name)  # raises if invalid


def test_unknown_scenario_raises(config):
    with pytest.raises(KeyError):
        get_scenario_config(config, "does_not_exist")


def test_bad_probabilities_rejected(config):
    bad = copy.deepcopy(config)
    bad["patients"]["severity_probs_emergency"] = [0.5, 0.5, 0.5, 0.0, 0.0]
    with pytest.raises(ValueError):
        validate_config({k: v for k, v in bad.items() if k != "scenarios"})


def test_scenario_does_not_mutate_base_config(config):
    before = copy.deepcopy(config)
    get_scenario_config(config, "bed_shortage")
    assert config == before


# ---------------------------------------------------------------- patients
def test_patient_columns_present(tables):
    required = {
        "patient_id", "arrival_time", "arrival_step", "severity", "urgency_level",
        "is_emergency", "required_bed_type", "required_specialization",
        "treatment_duration", "est_treatment_duration", "requires_surgery",
        "surgery_type", "surgery_duration", "est_surgery_duration",
        "length_of_stay", "expected_length_of_stay", "treatment_status", "discharge_status",
    }
    assert required <= set(tables["patients"].columns)


def test_patient_value_ranges(config, tables):
    p = tables["patients"]
    horizon = config["simulation"]["episode_days"] * 1440
    assert len(p) > 0
    assert p["patient_id"].is_unique
    assert p["arrival_time"].is_monotonic_increasing
    assert p["arrival_time"].between(0, horizon - 1).all()
    assert p["severity"].between(1, 5).all()
    assert p["urgency_level"].between(1, 4).all()
    assert set(p["required_bed_type"]) <= {"icu", "general"}
    assert (p["treatment_duration"] > 0).all()
    assert (p["length_of_stay"] >= p["treatment_duration"] + p["surgery_duration"]).all()
    assert (p["treatment_status"] == "waiting").all()
    assert (p["discharge_status"] == "not_discharged").all()


def test_surgery_fields_consistent(tables):
    p = tables["patients"]
    s, ns = p[p["requires_surgery"]], p[~p["requires_surgery"]]
    assert len(s) > 0
    assert (s["surgery_duration"] > 0).all() and (s["surgery_type"] != "none").all()
    assert (ns["surgery_duration"] == 0).all() and (ns["surgery_type"] == "none").all()
    assert (ns["est_surgery_duration"] == 0).all()
    # only surgical specializations may have surgery
    assert not s["required_specialization"].eq("general_medicine").any()


def test_no_elective_arrivals_at_night(tables):
    p = tables["patients"]
    elective = p[~p["is_emergency"]]
    hours = (elective["arrival_time"] // 60) % 24
    assert hours.between(8, 17).all()


def test_icu_probability_increases_with_severity(config):
    p = SyntheticDataGenerator(config, "high_demand", seed=3).generate_patients()
    low = (p[p["severity"] <= 2]["required_bed_type"] == "icu").mean()
    high = (p[p["severity"] >= 4]["required_bed_type"] == "icu").mean()
    assert low == 0.0
    assert high > 0.2


# ----------------------------------------------------------- reproducibility
def test_same_seed_gives_identical_data(config):
    a = SyntheticDataGenerator(config, "mixed_demand", seed=5).generate_all()
    b = SyntheticDataGenerator(config, "mixed_demand", seed=5).generate_all()
    for name in a:
        pd.testing.assert_frame_equal(a[name], b[name])


def test_different_seed_gives_different_data(config):
    a = SyntheticDataGenerator(config, "normal", seed=1).generate_patients()
    b = SyntheticDataGenerator(config, "normal", seed=2).generate_patients()
    assert not a.equals(b)


# --------------------------------------------------------------- scenarios
def test_high_demand_has_more_patients(config):
    normal = sum(len(SyntheticDataGenerator(config, "normal", s).generate_patients()) for s in range(5))
    high = sum(len(SyntheticDataGenerator(config, "high_demand", s).generate_patients()) for s in range(5))
    assert high > 1.3 * normal


def test_emergency_surge_adds_emergencies_in_window(config):
    def window_count(scenario):
        total = 0
        for seed in range(8):
            gen = SyntheticDataGenerator(config, scenario, seed)
            ev = gen.generate_events()
            p = gen.generate_patients(ev)
            if scenario == "emergency_surge":
                lo, hi = int(ev.start_minute[0]), int(ev.end_minute[0])
            else:
                lo, hi = 24 * 60, 30 * 60
            total += int(p[p["is_emergency"] & p["arrival_time"].between(lo, hi - 1)].shape[0])
        return total

    assert window_count("emergency_surge") > window_count("normal")


def test_shortage_scenarios_reduce_resources(config):
    normal = SyntheticDataGenerator(config, "normal")
    assert len(SyntheticDataGenerator(config, "bed_shortage").generate_beds()) < len(normal.generate_beds())
    assert len(SyntheticDataGenerator(config, "doctor_shortage").generate_doctors()) < len(normal.generate_doctors())
    assert len(SyntheticDataGenerator(config, "or_shortage").generate_operating_rooms()) < len(normal.generate_operating_rooms())


def test_events_table(config):
    ev = SyntheticDataGenerator(config, "mixed_demand").generate_events()
    assert set(ev["event_type"]) == {"emergency_surge", "elective_increase"}
    assert (ev["end_minute"] > ev["start_minute"]).all()
    assert SyntheticDataGenerator(config, "normal").generate_events().empty


# ---------------------------------------------------------------- resources
def test_resource_tables(config, tables):
    r = config["resources"]
    beds, docs, ors = tables["beds"], tables["doctors"], tables["operating_rooms"]
    assert (beds["bed_type"] == "icu").sum() == r["num_icu_beds"]
    assert (beds["bed_type"] == "general").sum() == r["num_general_beds"]
    assert beds["available"].all() and (beds["current_occupant_id"] == -1).all()
    assert len(docs) == sum(r["doctors_per_specialization"].values())
    assert docs["available"].all() and (docs["current_workload"] == 0).all()
    assert len(ors) == r["num_operating_rooms"] and ors["available"].all()


# --------------------------------------------------------------- time series
def test_timeseries_matches_patients(config, tables):
    ts, p = tables["arrival_timeseries"], tables["patients"]
    assert len(ts) == config["simulation"]["episode_days"] * 1440 // config["simulation"]["step_minutes"]
    assert ts["total_arrivals"].sum() == len(p)
    assert ts["emergency_arrivals"].sum() == p["is_emergency"].sum()
    assert (ts["total_arrivals"] == ts["emergency_arrivals"] + ts["elective_arrivals"]).all()


# ------------------------------------------------------------------- saving
def test_save_all_writes_files(config, tmp_path):
    folder = SyntheticDataGenerator(config, "normal", seed=9).save_all(tmp_path)
    names = {f.name for f in folder.iterdir()}
    assert {"patients.csv", "beds.csv", "doctors.csv", "operating_rooms.csv",
            "events.csv", "arrival_timeseries.csv", "config_used.yaml"} <= names
    assert len(pd.read_csv(folder / "patients.csv")) > 0
