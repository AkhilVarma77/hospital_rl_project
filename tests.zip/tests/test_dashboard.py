"""Dashboard data and build script: recorded replays must agree with the simulator's own numbers."""
import copy
import json
import re
import runpy
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from src.algorithms.ppo import PPOConfig, PPOLearner
from src.environment.hospital_state import AGENTS
from src.environment.multi_agent_env import HospitalMAEnv
from src.evaluation.compare_algorithms import BASELINE_TRAIN_SEED, summarize, write_report
from src.evaluation.evaluate import run_ma_episode
from src.training.train_ppo import PPOPolicySet
from src.utils.config import load_config
from src.visualization.dashboard_data import (
    parse_results_summary, record_baseline_replay, record_learned_replay, to_script_json)

ROOT = Path(__file__).resolve().parents[1]


def _short_config():
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.5
    return cfg


# ------------------------------------------------------------------------- replay
def test_baseline_replay_matches_the_simulator_summary():
    cfg = _short_config()
    r = record_baseline_replay(cfg, "emergency_surge", 1000, "severity")
    m, steps, s = r["meta"], r["steps"], r["summary"]
    assert len(steps) == 720 // 15 == m["n_steps"]
    for st in steps:
        assert len(st["beds"]) == len(m["beds"]) and len(st["docs"]) == len(m["doctors"]) and len(st["ors"]) == m["n_ors"]
        assert len(st["wq"]) == 3 and len(st["util"]) == 3 and len(st["rc"]) == 5
    assert [st["t"] for st in steps] == list(range(15, 721, 15))
    assert sum(st["arr"][0] for st in steps) == s["patients_arrived"]
    assert sum(st["dis"] for st in steps) == s["throughput"]
    assert sum(len(st["acts"]) for st in steps) > 0 and sum(st["inv"] for st in steps) == 0
    assert steps[-1]["mw"] == pytest.approx(s["mean_wait_to_treatment"], abs=0.01)
    assert json.loads(json.dumps(r)) == r                             # plain JSON types only


def test_replay_is_deterministic_and_forecast_is_optional():
    cfg = _short_config()
    assert record_baseline_replay(cfg, "normal", 1001, "fcfs") == record_baseline_replay(cfg, "normal", 1001, "fcfs")
    r = record_baseline_replay(cfg, "normal", 1001, "fcfs")
    assert r["meta"]["forecast"] is None and all(st["fc"] is None for st in r["steps"])


def test_replay_forecast_uses_only_the_past():
    from src.forecasting.demand_forecaster import MovingAverageForecaster
    cfg = _short_config()
    fc = MovingAverageForecaster(4, 96, prior=(0.7, 0.2))
    r = record_baseline_replay(cfg, "normal", 1000, "fcfs", fc)
    steps = r["steps"]
    assert steps[0]["fc"] == [0.7, 0.2]                                # no history yet -> prior
    actual = [st["arr"][0] for st in steps]
    for k in (5, 20, 40):                                              # mean of the 4 previous actual steps
        assert steps[k]["fc"][0] == pytest.approx(np.mean(actual[k - 4:k]), abs=1e-3)


def test_learned_replay_reproduces_the_policys_episode_return():
    cfg = _short_config()
    ma = HospitalMAEnv(cfg, "normal", seed=1000)
    hp = PPOConfig(hidden_sizes=(8,))
    learners = {a: PPOLearner(ma.obs_dims[a], ma.n_actions[a], hp, seed=i) for i, a in enumerate(AGENTS)}
    policies = PPOPolicySet(learners)
    r = record_learned_replay(cfg, "normal", 1000, "ppo_test", policies)
    summary, ret = run_ma_episode(HospitalMAEnv(cfg, "normal", seed=1000), policies)
    assert len(r["steps"]) == 720 // 15
    assert sum(st["rew"] for st in r["steps"]) == pytest.approx(ret, abs=0.05)
    assert r["summary"]["throughput"] == summary["throughput"]
    assert sum(st["inv"] for st in r["steps"]) == summary["invalid_actions_total"]


# ------------------------------------------------------------------ result tables
def _per_episode():
    rows = []
    for ts, vals in ((0, (10.0, 20.0)), (1, (30.0, 50.0))):
        for ev, v in zip((1000, 1001), vals):
            rows.append(dict(method="ppo", train_seed=ts, scenario="normal", seed=ev, mean_wait_to_treatment=v,
                             throughput=100.0, episode_return=-5.0))
    for ev, v in ((1000, 4.0), (1001, 8.0)):
        rows.append(dict(method="fcfs", train_seed=BASELINE_TRAIN_SEED, scenario="normal", seed=ev,
                         mean_wait_to_treatment=v, throughput=120.0, episode_return=np.nan))
    return pd.DataFrame(rows)


def test_results_parser_round_trips_the_report_written_by_the_suite(tmp_path):
    df = _per_episode()
    write_report(df, pd.DataFrame(columns=["method", "train_seed", "training_seconds"]), tmp_path / "r.md", "hdr")
    parsed = parse_results_summary(tmp_path / "r.md")
    assert parsed["methods"] == ["ppo", "fcfs"] and parsed["scenarios"] == ["normal"]   # order of appearance
    expected = summarize(df).set_index("method")
    wait = parsed["metrics"]["mean_wait_to_treatment"]
    for method in ("fcfs", "ppo"):
        mu, sd = wait["overall"][method]
        assert mu == pytest.approx(expected.loc[method, "mean_wait_to_treatment_mean"], abs=0.006)
        assert sd == pytest.approx(expected.loc[method, "mean_wait_to_treatment_std"], abs=0.006)
        assert wait["scenarios"]["normal"][method][0] == pytest.approx(mu, abs=0.006)
    assert wait["lower_better"] is True and parsed["metrics"]["throughput"]["lower_better"] is False
    assert parsed["metrics"]["episode_return"]["overall"]["fcfs"] is None       # baselines: n/a
    assert "hdr" in parsed["intro"]


def test_script_json_is_safe_inside_html():
    text = to_script_json({"x": "</script><!-- a"})
    assert "<" not in text
    assert json.loads(text) == {"x": "</script><!-- a"}


# --------------------------------------------------------------------- the page
def test_template_has_the_data_slot_and_avoids_a_known_browser_pitfall():
    html = (ROOT / "docs" / "dashboard_template.html").read_text(encoding="utf-8")
    assert html.count("/*__DATA__*/") == 1
    assert "replaceState" not in html and "pushState" not in html        # throws on file:// URLs in Chrome
    for tab in ("overview", "results", "replay", "forecast", "architecture", "limits"):
        assert f'id="tab-{tab}"' in html
    assert "synthetic" in html.lower() and "MEASURED" in html and "REPLAY" in html


def test_build_script_writes_a_complete_page(tmp_path, monkeypatch):
    write_report(_per_episode(), pd.DataFrame(columns=["method", "train_seed", "training_seconds"]),
                 tmp_path / "results_summary.md")
    pd.DataFrame([{"model": "lstm", "scenario": "all", "mae_total": 0.6, "rmse_total": 0.9,
                   "mae_emergency": 0.4, "rmse_emergency": 0.5, "mean_actual_total": 0.8}]).to_csv(tmp_path / "fm.csv", index=False)
    out = tmp_path / "dash.html"
    argv = ["build_dashboard.py", "--results", str(tmp_path / "results_summary.md"),
            "--forecast-metrics", str(tmp_path / "fm.csv"), "--forecast-model", str(tmp_path / "missing.pt"),
            "--scenarios", "normal", "--baselines", "fcfs", "--template", str(ROOT / "docs" / "dashboard_template.html"),
            "--figures", str(ROOT / "docs" / "figures"), "--out", str(out)]
    monkeypatch.setattr(sys, "argv", argv)
    runpy.run_path(str(ROOT / "scripts" / "build_dashboard.py"), run_name="__main__")
    html = out.read_text(encoding="utf-8")
    assert "/*__DATA__*/" not in html
    blob = re.search(r'<script type="application/json" id="data">(.*?)</script>', html, re.S).group(1)
    data = json.loads(blob)
    assert set(data["results"]["methods"]) == {"fcfs", "ppo"} and data["forecast"]["rows"][0]["model"] == "lstm"
    assert len(data["replays"]) == 1 and data["replays"][0]["meta"]["policy"] == "fcfs"
    assert len(data["replays"][0]["steps"]) == 288
    assert {"architecture", "workflow", "patient_pathway"} <= set(data["images"])
