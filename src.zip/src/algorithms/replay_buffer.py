"""Fixed-size experience replay buffer for one agent (circular, uniform sampling).

Each transition stores the NEXT observation and NEXT action mask as well, because the DQN
target must only maximise over actions that are feasible in the next state.
"""
from __future__ import annotations

import numpy as np


class ReplayBuffer:
    def __init__(self, capacity: int, obs_dim: int, n_actions: int) -> None:
        self.capacity, self.size, self.ptr = capacity, 0, 0
        self.obs = np.zeros((capacity, obs_dim), np.float32)
        self.next_obs = np.zeros((capacity, obs_dim), np.float32)
        self.masks = np.zeros((capacity, n_actions), bool)
        self.next_masks = np.zeros((capacity, n_actions), bool)
        self.actions = np.zeros(capacity, np.int64)
        self.rewards = np.zeros(capacity, np.float32)
        self.dones = np.zeros(capacity, np.float32)

    def __len__(self) -> int:
        return self.size

    def add(self, obs, mask, action: int, reward: float, next_obs, next_mask, done: bool) -> None:
        i = self.ptr
        self.obs[i], self.masks[i], self.actions[i] = obs, mask, action
        self.rewards[i], self.next_obs[i], self.next_masks[i] = reward, next_obs, next_mask
        self.dones[i] = float(done)
        self.ptr = (self.ptr + 1) % self.capacity       # overwrite the oldest when full
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int, rng: np.random.Generator) -> dict[str, np.ndarray]:
        idx = rng.integers(0, self.size, size=batch_size)
        return {"obs": self.obs[idx], "masks": self.masks[idx], "actions": self.actions[idx],
                "rewards": self.rewards[idx], "next_obs": self.next_obs[idx],
                "next_masks": self.next_masks[idx], "dones": self.dones[idx]}
