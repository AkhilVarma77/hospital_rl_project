"""Experiment suite: statistics by hand, scenario-mix training env, plots, resumable orchestration."""
import copy
import os

import numpy as np
import pandas as pd
import pytest

from src.environment.hospital_env import HospitalEnv
from src.environment.multi_agent_env import HospitalMAEnv
from src.environment.scenario_mix_env import ScenarioMixEnv, make_training_env
from src.evaluation.compare_algorithms import (
    BASELINE_TRAIN_SEED, format_table, relative_to_baseline, summarize, to_markdown, write_report)
from src.evaluation.experiments import METHODS, PROFILES, aggregate, run_experiments
from src.forecasting.demand_forecaster import MovingAverageForecaster
from src.utils.config import load_config
from src.visualization.plot_comparison import plot_metric_by_scenario


def _per_episode():
    rows = []
    # learned method: 2 training seeds x 2 evaluation seeds, one scenario
    for ts, vals in ((0, (10.0, 20.0)), (1, (30.0, 50.0))):
        for ev, v in zip((1000, 1001), vals):
            rows.append(dict(method="ppo", train_seed=ts, scenario="normal", seed=ev, mean_wait_to_treatment=v,
                             throughput=100.0, episode_return=-5.0))
    # baseline: no training; evaluation seeds are the units
    for ev, v in ((1000, 4.0), (1001, 8.0), (1002, 6.0)):
        rows.append(dict(method="fcfs", train_seed=BASELINE_TRAIN_SEED, scenario="normal", seed=ev,
                         mean_wait_to_treatment=v, throughput=120.0, episode_return=np.nan))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------- statistics
def test_summary_for_learned_methods_averages_eval_seeds_then_uses_training_runs_as_units():
    s = summarize(_per_episode(), ["mean_wait_to_treatment"]).set_index("method")
    run_means = [15.0, 40.0]                                         # per training seed
    assert s.loc["ppo", "mean_wait_to_treatment_mean"] == pytest.approx(np.mean(run_means))
    assert s.loc["ppo", "mean_wait_to_treatment_std"] == pytest.approx(np.std(run_means, ddof=1))
    assert s.loc["ppo", "n_units"] == 2


def test_summary_for_baselines_uses_evaluation_seeds_as_units():
    s = summarize(_per_episode(), ["mean_wait_to_treatment"]).set_index("method")
    assert s.loc["fcfs", "mean_wait_to_treatment_mean"] == pytest.approx(6.0)
    assert s.loc["fcfs", "mean_wait_to_treatment_std"] == pytest.approx(np.std([4, 8, 6], ddof=1))
    assert s.loc["fcfs", "n_units"] == 3


def test_overall_summary_averages_scenarios_first():
    df = pd.concat([_per_episode(), _per_episode().assign(scenario="high_demand",
                                                          mean_wait_to_treatment=lambda d: d.mean_wait_to_treatment * 2)])
    overall = summarize(df, ["mean_wait_to_treatment"], by_scenario=False).set_index("method")
    assert overall.loc["fcfs", "mean_wait_to_treatment_mean"] == pytest.approx(9.0)     # (6 + 12) / 2
    assert overall.loc["ppo", "mean_wait_to_treatment_mean"] == pytest.approx(1.5 * 27.5)


def test_relative_difference_and_table_formatting():
    s = summarize(_per_episode(), ["mean_wait_to_treatment", "throughput"])
    rel = relative_to_baseline(s, "mean_wait_to_treatment")
    assert rel.loc["normal", "ppo"] == pytest.approx((27.5 / 6.0 - 1.0) * 100.0)
    assert rel.loc["normal", "fcfs"] == 0.0
    table = format_table(s, "mean_wait_to_treatment", ["fcfs", "ppo"])
    assert table.loc["normal", "fcfs"].startswith("6.00 ± 2.00")
    md = to_markdown(table)
    assert md.splitlines()[1].startswith("|---") and "fcfs" in md.splitlines()[0]


def test_single_unit_has_no_std_and_report_writes(tmp_path):
    df = _per_episode()
    df = df[~((df.method == "ppo") & (df.train_seed == 1))]
    s = summarize(df, ["mean_wait_to_treatment"]).set_index("method")
    assert np.isnan(s.loc["ppo", "mean_wait_to_treatment_std"])
    text = write_report(df, pd.DataFrame(columns=["method", "train_seed", "training_seconds"]),
                        tmp_path / "r.md", header="hdr")
    assert (tmp_path / "r.md").exists() and "hdr" in text and "No significance tests" in text


def test_plot_is_written(tmp_path):
    s = summarize(_per_episode(), ["mean_wait_to_treatment"])
    plot_metric_by_scenario(s, "mean_wait_to_treatment", tmp_path / "f" / "p.png")
    assert (tmp_path / "f" / "p.png").stat().st_size > 1000


# ---------------------------------------------------------------- scenario mixture
def test_scenario_mix_cycles_scenarios_by_seed_and_keeps_dimensions():
    cfg = load_config()
    mix = ScenarioMixEnv(cfg, ["normal", "bed_shortage", "or_shortage"], seed=0)
    dims = dict(mix.obs_dims)
    seen = []
    for seed in range(6):
        obs, info = mix.reset(seed=seed)
        seen.append(mix.env.scenario)
        assert {a: obs[a].shape[0] for a in obs} == dims == {a: mix.obs_dims[a] for a in dims}
    assert seen == ["normal", "bed_shortage", "or_shortage"] * 2
    mix.reset(seed=1)
    assert len(mix.env.state.beds) < len(HospitalMAEnv(cfg, "normal", seed=0).env.state.beds)


def test_scenario_mix_runs_an_episode_and_make_training_env_dispatches():
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.25
    assert isinstance(make_training_env(cfg, "normal", seed=0), HospitalMAEnv)
    mix = make_training_env(cfg, ["normal", "high_demand"], seed=0)
    assert isinstance(mix, ScenarioMixEnv)
    obs, info = mix.reset(seed=3)
    defer = {a: mix.agent_objs[a].defer_index for a in obs}
    done = False
    while not done:
        obs, rew, done, info = mix.step(defer)
    assert mix.done and mix.episode_summary()["patients_arrived"] >= 0


def test_training_on_a_mixture_logs_the_scenario_of_every_episode(tmp_path):
    from src.training.train_ppo import train_ppo
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.25
    train_ppo(cfg, ["normal", "bed_shortage"], tmp_path, iterations=1, seed=0, verbose=False,
              ppo_overrides={"rollout_steps": 200, "minibatch_size": 64, "hidden_sizes": [8]})
    eps = pd.read_csv(tmp_path / "episodes.csv")
    assert set(eps["scenario"]) == {"normal", "bed_shortage"}


# ------------------------------------------------------------------- orchestration
def test_profiles_and_methods_are_consistent():
    assert set(PROFILES) == {"smoke", "default", "full"}
    assert {"fcfs", "severity", "ppo_independent", "comm_none", "comm_mean", "comm_attention",
            "comm_attention_forecast", "dqn"} == set(METHODS)
    assert PROFILES["default"]["seeds"] >= 3 and PROFILES["full"]["seeds"] > PROFILES["default"]["seeds"]


def _tiny_config():
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.25
    return cfg


def test_experiment_suite_end_to_end_and_resumable(tmp_path):
    cfg = _tiny_config()
    fc = tmp_path / "ma.json"
    MovingAverageForecaster(4, 96, (1.0, 0.4)).save(fc)
    methods = ["fcfs", "ppo_independent", "comm_attention", "comm_attention_forecast", "dqn"]
    kw = dict(num_seeds=2, iterations=1, eval_seeds=[1000, 1001], scenarios=["normal", "bed_shortage"],
              rollout_steps=64, forecast_model=str(fc), verbose=False)
    out = run_experiments(cfg, tmp_path / "exp", methods, **kw)

    root = tmp_path / "exp"
    for name in ("per_episode.csv", "summary_by_scenario.csv", "summary_overall.csv", "results_summary.md",
                 "experiment_signature.yaml"):
        assert (root / name).exists(), name
    assert (root / "figures" / "mean_wait_to_treatment.png").exists()
    assert (root / "figures" / "learning_curves.png").exists()
    pe = out["per_episode"]
    assert set(pe.method) == set(methods) and set(pe.scenario) == {"normal", "bed_shortage"}
    # fcfs: 1 unit set x 2 scenarios x 2 eval seeds; learned: 2 training seeds x 2 scenarios x 2 eval seeds
    assert len(pe[pe.method == "fcfs"]) == 4 and len(pe[pe.method == "dqn"]) == 8
    assert (pe[pe.method == "fcfs"].train_seed == BASELINE_TRAIN_SEED).all()
    assert set(pe[pe.method == "comm_attention"].train_seed) == {0, 1}
    assert len(out["runs"]) == 8 and (out["runs"].training_seconds > 0).all()
    assert "comm_attention_forecast" in (root / "results_summary.md").read_text()

    # the forecast-trained policy remembers its forecaster; the others do not
    run = root / "runs" / "comm_attention_forecast_seed0"
    assert "ma.json" in (run / "config_used.yaml").read_text()

    # resumable: a second call must not retrain (checkpoint untouched) and gives identical results
    ckpt = root / "runs" / "ppo_independent_seed0" / "checkpoints" / "final.pt"
    before = os.path.getmtime(ckpt)
    out2 = run_experiments(cfg, tmp_path / "exp", methods, **kw)
    assert os.path.getmtime(ckpt) == before
    pd.testing.assert_frame_equal(out["per_episode"].drop(columns="eval_seconds"),
                                  out2["per_episode"].drop(columns="eval_seconds"))

    # different evaluation settings in the same folder are refused
    with pytest.raises(ValueError):
        run_experiments(cfg, tmp_path / "exp", methods, **{**kw, "eval_seeds": [1000, 1001, 1002]})


def test_unknown_method_is_rejected(tmp_path):
    with pytest.raises(KeyError):
        run_experiments(_tiny_config(), tmp_path, ["nope"], 1, 1, [1000], ["normal"], verbose=False)
