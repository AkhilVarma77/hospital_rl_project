"""PPO: GAE, masked acting, clipped loss, learning on a toy problem, checkpoints, training loop."""
import copy

import numpy as np
import pandas as pd
import pytest
import torch

from src.algorithms.ppo import ActorCritic, PPOConfig, PPOLearner, ppo_loss
from src.algorithms.rollout_buffer import RolloutBuffer
from src.environment.hospital_state import AGENTS
from src.evaluation.evaluate import evaluate_ma_policy
from src.training.train_ppo import PPOPolicySet, load_policy_set, save_checkpoint, train_ppo
from src.utils.config import load_config


def _buffer(rewards, values, dones, mask_row=None, n_actions=3):
    n = len(rewards)
    buf = RolloutBuffer(n, 2, n_actions)
    mask = np.array(mask_row if mask_row is not None else [True] * n_actions)
    for r, v, d in zip(rewards, values, dones):
        buf.add(np.zeros(2, np.float32), mask, 0, 0.0, v, r, bool(d))
    return buf


# ------------------------------------------------------------------------- GAE
def test_gae_matches_hand_calculation():
    gamma, lam = 0.9, 0.8
    rewards, values, dones = [1.0, 2.0, 3.0], [0.5, 1.0, 1.5], [0, 0, 1]
    buf = _buffer(rewards, values, dones)
    buf.compute_gae(last_value=99.0, gamma=gamma, lam=lam)     # last_value ignored: episode ended
    d2 = 3.0 - 1.5
    d1 = 2.0 + gamma * 1.5 - 1.0
    d0 = 1.0 + gamma * 1.0 - 0.5
    a2 = d2
    a1 = d1 + gamma * lam * a2
    a0 = d0 + gamma * lam * a1
    assert buf.advantages == pytest.approx([a0, a1, a2], abs=1e-5)
    assert buf.returns == pytest.approx(np.array([a0, a1, a2]) + values, abs=1e-5)


def test_gae_bootstraps_from_last_value_when_episode_continues():
    buf = _buffer([1.0], [0.0], [0])
    buf.compute_gae(last_value=10.0, gamma=0.5, lam=1.0)
    assert buf.advantages[0] == pytest.approx(1.0 + 0.5 * 10.0)


def test_gae_does_not_leak_across_episode_boundaries():
    buf = _buffer([1.0, 100.0], [0.0, 0.0], [1, 0])           # step 0 ends an episode
    buf.compute_gae(last_value=0.0, gamma=0.99, lam=0.95)
    assert buf.advantages[0] == pytest.approx(1.0)            # the 100 belongs to the next episode


def test_only_steps_with_a_real_choice_are_active():
    buf = RolloutBuffer(3, 2, 3)
    only_defer, choice = np.array([False, False, True]), np.array([True, False, True])
    for mask in (only_defer, choice, only_defer):
        buf.add(np.zeros(2, np.float32), mask, 0, 0.0, 0.0, 0.0, False)
    assert buf.active_indices().tolist() == [1]


# ------------------------------------------------------------------ masked acting
def test_masked_actions_are_never_sampled_and_deterministic_picks_best_allowed():
    torch.manual_seed(0)
    learner = PPOLearner(6, 5, PPOConfig(hidden_sizes=(16,)))
    rng = np.random.default_rng(0)
    for _ in range(200):
        obs = rng.normal(size=6).astype(np.float32)
        mask = rng.random(5) < 0.5
        mask[-1] = True
        a, logp, _ = learner.act(obs, mask)
        assert mask[a] and logp <= 0.0
        det, _, _ = learner.act(obs, mask, deterministic=True)
        probs = learner.action_probs(obs, mask)
        assert mask[det] and det == int(np.argmax(probs))
        assert probs[~mask].sum() < 1e-6 and probs.sum() == pytest.approx(1.0, abs=1e-5)


# --------------------------------------------------------------------- loss by hand
def test_clipped_loss_by_hand():
    eps = 0.2
    old = torch.zeros(4)
    ratios = torch.tensor([1.0, 1.5, 0.5, 1.5])
    adv = torch.tensor([2.0, 2.0, -2.0, -2.0])
    new = torch.log(ratios)
    values, returns = torch.tensor([1.0, 1.0, 1.0, 1.0]), torch.tensor([2.0, 2.0, 2.0, 2.0])
    ent = torch.tensor([0.5, 0.5, 0.5, 0.5])
    total, info = ppo_loss(new, old, adv, values, returns, ent, eps, vf_coef=0.5, ent_coef=0.1)
    # per-sample min(r*A, clip(r)*A): 2.0, min(3.0,2.4)=2.4, min(-1.0,-1.6)=-1.6, min(-3.0,-2.4)=-3.0
    policy = -np.mean([2.0, 2.4, -1.6, -3.0])
    assert info["policy_loss"] == pytest.approx(policy, abs=1e-5)
    assert info["value_loss"] == pytest.approx(0.5 * 1.0, abs=1e-6)
    assert total.item() == pytest.approx(policy + 0.5 * 0.5 - 0.1 * 0.5, abs=1e-5)
    assert info["clip_fraction"] == pytest.approx(0.75)         # 1.5, 0.5, 1.5 leave [0.8, 1.2]


def test_loss_has_zero_policy_gradient_once_the_ratio_is_clipped():
    new = torch.tensor([float(np.log(1.5))], requires_grad=True)
    total, _ = ppo_loss(new, torch.zeros(1), torch.tensor([1.0]), torch.zeros(1), torch.zeros(1),
                        torch.zeros(1), 0.2, 0.0, 0.0)
    total.backward()
    assert new.grad.item() == 0.0                                 # A>0 and r>1+eps: no incentive


# ------------------------------------------------------------- learning (toy problem)
def test_ppo_learns_a_contextual_bandit():
    """obs = one-hot context (3), reward 1 iff action == context. Proves the whole update works."""
    torch.manual_seed(0)
    hp = PPOConfig(hidden_sizes=(32,), lr=3e-3, rollout_steps=256, minibatch_size=64,
                   update_epochs=4, ent_coef=0.0, gamma=0.0, gae_lambda=0.0)
    learner = PPOLearner(3, 4, hp, seed=0)
    rng = np.random.default_rng(0)
    mask = np.ones(4, bool)
    for _ in range(40):
        buf = RolloutBuffer(hp.rollout_steps, 3, 4)
        for _ in range(hp.rollout_steps):
            ctx = int(rng.integers(3))
            obs = np.eye(3, dtype=np.float32)[ctx]
            a, logp, v = learner.act(obs, mask)
            buf.add(obs, mask, a, logp, v, 1.0 if a == ctx else 0.0, True)
        learner.update(buf, 0.0)
    correct = sum(learner.act(np.eye(3, dtype=np.float32)[c], mask, deterministic=True)[0] == c
                  for c in range(3))
    assert correct == 3


def test_update_changes_parameters_and_acting_does_not():
    hp = PPOConfig(hidden_sizes=(8,), rollout_steps=32, minibatch_size=16)
    learner = PPOLearner(2, 3, hp)
    before = [p.clone() for p in learner.model.parameters()]
    mask = np.ones(3, bool)
    rng = np.random.default_rng(1)
    buf = RolloutBuffer(32, 2, 3)
    for _ in range(32):
        obs = rng.normal(size=2).astype(np.float32)
        a, logp, v = learner.act(obs, mask)                       # acting only
        buf.add(obs, mask, a, logp, v, float(rng.normal()), False)
    assert all(torch.equal(b, p) for b, p in zip(before, learner.model.parameters()))
    learner.update(buf, 0.0)
    assert any(not torch.equal(b, p) for b, p in zip(before, learner.model.parameters()))


def test_update_skips_when_there_is_nothing_to_learn_from():
    learner = PPOLearner(2, 3, PPOConfig(hidden_sizes=(8,)))
    buf = _buffer([0.0, 0.0], [0.0, 0.0], [0, 0], mask_row=[False, False, True])
    stats = learner.update(buf, 0.0)
    assert stats["active_steps"] == 0.0


# ------------------------------------------------------------------- checkpoints
def test_checkpoint_roundtrip_gives_identical_policy(tmp_path):
    hp = PPOConfig(hidden_sizes=(16,))
    learners = {a: PPOLearner(7, 4, hp, seed=i) for i, a in enumerate(AGENTS)}
    save_checkpoint(tmp_path / "c.pt", learners, {"note": "test"})
    loaded = load_policy_set(tmp_path / "c.pt")
    rng = np.random.default_rng(0)
    mask = np.array([True, False, True, True])
    for a in AGENTS:
        obs = rng.normal(size=7).astype(np.float32)
        assert np.allclose(learners[a].action_probs(obs, mask), loaded.learners[a].action_probs(obs, mask))


# ------------------------------------------------------------------ training loop
def _short_config():
    cfg = copy.deepcopy(load_config())
    cfg["simulation"]["episode_days"] = 0.25          # 6 simulated hours -> several episodes per rollout
    return cfg


def test_training_smoke_run_writes_logs_and_checkpoints(tmp_path):
    policies = train_ppo(_short_config(), "normal", tmp_path, iterations=2, seed=0,
                         ppo_overrides={"rollout_steps": 128, "minibatch_size": 64, "hidden_sizes": [16]},
                         checkpoint_every=1, verbose=False)
    log = pd.read_csv(tmp_path / "train_log.csv")
    assert len(log) == 2 and np.isfinite(log.filter(like="_value_loss").to_numpy()).all()
    assert (tmp_path / "checkpoints" / "final.pt").exists() and (tmp_path / "checkpoints" / "iter_1.pt").exists()
    episodes = pd.read_csv(tmp_path / "episodes.csv")
    assert len(episodes) >= 1 and {"episode_return", "throughput", "env_seed"} <= set(episodes.columns)
    assert (episodes["env_seed"] >= 100_000).all()                # never overlaps evaluation seeds
    assert (tmp_path / "config_used.yaml").exists()
    assert isinstance(policies, PPOPolicySet)


def test_training_is_reproducible(tmp_path):
    kw = dict(iterations=1, seed=3, ppo_overrides={"rollout_steps": 96, "minibatch_size": 32,
                                                   "hidden_sizes": [8]}, verbose=False)
    a = train_ppo(_short_config(), "normal", tmp_path / "a", **kw)
    b = train_ppo(_short_config(), "normal", tmp_path / "b", **kw)
    for agent in AGENTS:
        for pa, pb in zip(a.learners[agent].model.parameters(), b.learners[agent].model.parameters()):
            assert torch.equal(pa, pb)


def test_evaluation_is_greedy_and_does_not_update_the_policy():
    cfg = _short_config()
    hp = PPOConfig(hidden_sizes=(8,))
    from src.environment.multi_agent_env import HospitalMAEnv
    ma = HospitalMAEnv(cfg, "normal", seed=1)
    learners = {a: PPOLearner(ma.obs_dims[a], ma.n_actions[a], hp, seed=i) for i, a in enumerate(AGENTS)}
    before = {a: [p.clone() for p in l.model.parameters()] for a, l in learners.items()}
    df = evaluate_ma_policy(cfg, "normal", PPOPolicySet(learners), [1000, 1001], "ppo_test")
    assert len(df) == 2 and {"episode_return", "throughput", "invalid_actions_total"} <= set(df.columns)
    for a in AGENTS:
        assert all(torch.equal(b, p) for b, p in zip(before[a], learners[a].model.parameters()))
    again = evaluate_ma_policy(cfg, "normal", PPOPolicySet(learners), [1000, 1001], "ppo_test")
    assert df.drop(columns="eval_seconds").equals(again.drop(columns="eval_seconds"))
