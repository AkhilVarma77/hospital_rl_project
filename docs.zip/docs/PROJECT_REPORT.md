# Predictive Attention-Based Multi-Agent Reinforcement Learning for Dynamic Hospital Resource Management

**Academic project report (simulation study).** All data in this project are **synthetic**: they are produced by a simulator with assumed parameters and are not real hospital records. Nothing here should be read as a statement about real hospitals.

**How to read this document.** Every claim is tagged by evidence level:

- **[Design]** a decision about how the system is built;
- **[Implemented]** code exists and is covered by automated tests (191 tests pass);
- **[Observed]** a result measured in our experiments, with its limits stated.

---

## 1. Summary and honest status

**Research question.** How effectively can cooperative multi-agent reinforcement learning coordinate interdependent hospital resources (beds, doctors, operating rooms) under dynamic patient demand, and how do PPO and DQN compare in waiting time, emergency response, resource utilization, throughput and scheduling conflicts?

**One-paragraph outcome.** A complete simulation framework was built and tested: a synthetic hospital with hard clinical constraints, three agents (bed, doctor/patient scheduling, operating room), two rule-based baselines, PPO, DQN, an attention-based communication module, an LSTM demand forecaster, and an automated multi-seed experiment suite. In our experiments (3 training seeds x 40 training iterations, 7 scenarios, 5 evaluation seeds) the learned PPO agents performed **about as well as** the rule-based baselines on waiting times and slightly better on emergency response delay, but **clearly worse on emergency surgery waiting**, and they produce scheduling conflicts the baselines avoid by construction. DQN was worse than PPO on waiting, throughput and untreated patients. **We found no evidence that attention-based communication or demand forecasting improves performance in this setup**; the attention variant was additionally unstable across training seeds. These are results of short, untuned training runs on one simulator and must not be generalised.

| Component | Designed | Implemented and tested | Evaluated experimentally |
|---|---|---|---|
| Synthetic data generator (7 scenarios) | yes | yes | yes |
| Hospital environment, hard constraints, metrics | yes | yes | yes |
| FCFS and severity-priority baselines | yes | yes | yes |
| Three agent interfaces (observation, masks, actions) | yes | yes | yes |
| Shared reward (separate module) | yes | yes | yes, **weights not tuned** |
| PPO (independent agents) | yes | yes | yes |
| DQN (independent agents) | yes | yes | yes |
| Attention communication (none / mean / attention) | yes | yes | yes |
| LSTM and moving-average forecaster | yes | yes | yes (held-out simulated data) |
| Forecast fed to the agents | yes | yes | yes |
| Multi-seed experiment suite, tables, plots | yes | yes | yes |
| Reward-coefficient sensitivity experiments | specified | **not done** | **not done** |
| Statistical significance tests | - | **not done** | **not done** |
| DQN with attention / forecasting | specified "where feasible" | **not done** | **not done** |
| HTML dashboard (optional): results explorer, replay of recorded simulator episodes, forecasting and architecture tabs | yes | yes (`docs/dashboard.html`) | - |
| Streamlit version of the dashboard | optional | **not done** | - |

---

## 2. System architecture [Design, Implemented]

![Architecture](figures/architecture.png)

**Principle.** The environment is the single source of truth and contains no learning code. Safety rules live in the environment, never in the reward. Everything else (forecasting, communication, algorithms, evaluation) can be switched on or replaced without touching the simulator.

| Module (path) | Responsibility | Must not |
|---|---|---|
| `src/data/synthetic_data_generator.py` | reproducible synthetic patients, beds, doctors, ORs, events | make decisions |
| `src/environment/` (`hospital_state.py`, `constraints.py`, `hospital_events.py`, `hospital_env.py`) | clock, queues, resources, hard constraints, joint action execution, outages | learn |
| `src/agents/` | observation vector, action mask, action decoding for bed / doctor / OR | change hospital state |
| `src/rewards/reward_calculator.py` | shared reward and per-agent diagnostics | enforce safety |
| `src/forecasting/` | predict next-step arrivals | allocate any resource |
| `src/communication/` | message encoders and attention | choose actions |
| `src/algorithms/` | PPO, DQN, rollout buffer, replay buffer, communicating PPO | bypass the constraints |
| `src/training/` | training loops, logging, checkpoints | |
| `src/baselines/` | FCFS, severity priority | |
| `src/evaluation/`, `src/visualization/` | metrics, multi-seed tables, plots | modify the simulation |

---

## 3. Workflow of one decision round [Design, Implemented]

![Workflow](figures/workflow.png)

One call to the multi-agent environment is a **decision round**. All three agents choose simultaneously from the same state. The clock advances (15 simulated minutes) only when every agent is done for this step: it has deferred voluntarily, or has no feasible action left. This lets the learning agents make as many decisions per clock step as the baselines (up to 3 actions per agent per step) and lets an agent act on a patient another agent has just admitted. Consequence: one learning step is one decision round, not one clock tick, and discounting is per round.

---

## 4. Synthetic data and assumptions [Design, Implemented]

**All numbers below are assumed by us.** They were chosen to make a hospital that is busy but not hopeless; they are not calibrated to any real hospital. They live in `config/default_config.yaml` and can be changed.

| Item | Assumption |
|---|---|
| Time | 1 step = 15 min; episode = 3 days = 288 steps |
| Arrivals | Poisson per step; 2.5 patients/hour base; 30% emergencies; daily pattern (elective arrivals only 08:00-17:59) |
| Severity (1-5) | emergency: 5/15/30/30/20 %; elective: 40/35/20/4/1 % |
| Urgency (1-4) | severity - 1, plus 1 if emergency, clipped (our convention, not a clinical standard) |
| ICU need | probability by severity: 0, 0, 5, 35, 80 % |
| Specializations | general medicine, cardiology, orthopedics, neurology (different mix for emergency and elective) |
| Surgery | only cardiology / orthopedics / neurology patients; probability 45% (emergency) or 35% (elective) |
| Treatment duration | lognormal; median 25/40/55/80/110 min by severity; 10-240 min |
| Surgery duration | lognormal; median 90 min; 30-360 min |
| Length of stay | lognormal; median 6 h (general) or 12 h (ICU); never shorter than care time |
| Observable estimates | true duration times lognormal noise (sigma 0.2); **agents only see estimates** |
| Resources (normal) | 24 general beds, 8 ICU beds; doctors 3 / 2 / 2 / 1 (general / cardio / ortho / neuro); 3 ORs |

**Scenarios.** normal; high_demand (x1.6 arrivals); emergency_surge (x3 emergency arrivals for 6 h on day 2); bed_shortage (14 + 4 beds); doctor_shortage (5 doctors); or_shortage (1 OR); mixed_demand (x1.3 arrivals, emergency surge and elective increase).

---

## 5. Hospital environment and hard constraints [Design, Implemented]

![Patient pathway](figures/patient_pathway.png)

A patient needs a **bed** from admission to discharge, a **doctor** of the right specialization for treatment, and, if surgery is needed, an **operating room and a doctor of the same specialization as surgeon**. The doctor pool is therefore shared between the doctor agent and the OR agent; this is where cooperation matters.

**Hard constraints** (enforced by the environment, rejected otherwise; never traded off in the reward):
- a bed, doctor or OR cannot be used by two patients at once;
- bed type, doctor specialization and surgery type must match;
- **emergency priority:** an elective patient may take a resource only if enough compatible resources remain for the emergency patients waiting for that pool;
- **ICU reserve:** one ICU bed is always kept for emergencies.

**Action outcomes** are kept distinct: *invalid* (violates a constraint; rejected, state unchanged, counted), *deferred* (the agent chose to wait; neutral) and *executed* (valid; may still earn a low reward).

**Joint execution.** All actions in one round are sorted by patient urgency (highest first), then agent order (bed, doctor, OR), and executed one at a time against the live state. When two actions compete, the more urgent patient wins and the other is rejected as invalid.

---

## 6. MDP formulation [Design]

| Element | Definition |
|---|---|
| Environment | the simulated hospital |
| Agents | bed agent, doctor/patient scheduling agent, OR scheduling agent |
| State s_t | complete hospital state: clock, all patients and their stages, bed / doctor / OR states, events |
| Observation o_t^i | agent i's local vector (Section 7), using only quantities available at decision time (estimates, never true durations) |
| Action a_t^i | integer in {0..K-1, K}: serve the patient in queue slot j, or defer (K = 8) |
| Transition | (s_t, a_t) -> (r_t, s_{t+1}): validated actions are executed in urgency order; when all agents are done, the clock advances 15 min and completions, discharges and arrivals are processed |
| Reward | shared cooperative reward (Section 8) |
| Policy | learned map from observation (and optionally others' messages) to a masked distribution over actions |
| Episode | one 3-day operating period (288 clock steps; several rounds per step) |
| Terminal condition | the end of the simulation horizon (treated as terminal, no bootstrapping) |

**Simplification to state in a viva:** because an episode has a fixed length, treating its end as terminal ignores that the time left is not part of the observation.

---

## 7. State and action spaces [Design, Implemented]

**Observation layout** (all values normalised; 5 common + pool + 2 queue + 8 slots):

| Agent | Common (5) | Own resource pool | Queue stats (2) | Slot features (x8) | Total size |
|---|---|---|---|---|---|
| Bed | sin / cos of time of day, 2 forecast features, fraction of action budget left | free ICU and general fractions, estimated time to next release (4) | queue length, emergencies | validity, emergency, urgency, severity, wait, needs ICU, expected stay, needs surgery (8 per slot) | **75** |
| Doctor | same | per specialization: free fraction, estimated time to free (8) | same | validity, emergency, urgency, severity, wait, estimated treatment, needs surgery, free doctors of its specialty, specialization one-hot (12 per slot) | **111** |
| OR | same | free OR fraction, estimated time to free (2) | same | validity, emergency, urgency, severity, wait for surgery, estimated surgery, free surgeons of its specialty, surgery-type one-hot (10 per slot) | **89** |

Observations are **local**: each agent sees only its own queue, its own resource pool and the availability flags that decide its own actions. Other agents' information reaches an agent only through the communication module. The two forecast features are zeros when forecasting is off. Sizes do not depend on how many beds, doctors or ORs a scenario has, so one network works in every scenario.

**Action space (identical for PPO and DQN):** `Discrete(9)` per agent. Slots hold the agent's 8 highest-priority waiting patients (emergency first, then urgency, severity, arrival). The concrete resource is bound deterministically (lowest-id free resource of the right type); this loses nothing because resources inside a pool are interchangeable in this model. A boolean **action mask** marks the slots whose action passes every hard constraint right now; defer is always allowed. Limitation: patients beyond the 8th in a queue are not selectable (the queue length is observed).

---

## 8. Reward [Design, Implemented]

Computed outside the environment, shared by all agents:

R = -w1 W - w2 E + w3 U + w4 T - w5 C

- **W** = (patients waiting for a bed, doctor or surgery) / 20, per clock step (summed over steps this equals total waiting time in step units);
- **E** = (emergency patients in those queues) / 3, per clock step;
- **U** = mean over beds, doctors and ORs of min(busy fraction, ceiling) / ceiling, ceilings 0.85 / 0.9 / 0.9 (utilization is rewarded only up to a ceiling so agents are not pushed to fill every bed and remove emergency capacity). It is raw busy time, not a judgement of appropriateness; compatibility is already guaranteed by the hard constraints;
- **T** = patients discharged in the step;
- **C** = invalid actions in the round (with masks, the only source is two agents competing for the same resource).

Initial coefficients: w1 = 1.0, w2 = 2.0, w3 = 0.5, w4 = 1.0, w5 = 1.0 (all in the config file). **These are documented starting values; they were not tuned, no sensitivity experiment was run, and nothing here shows they are good or optimal.** There is no separate sum of per-agent rewards, so nothing is double-counted; per-agent numbers are diagnostics only.

---

## 9. PPO and DQN [Design, Implemented]

| | PPO (primary) | DQN (comparison) |
|---|---|---|
| Type | on-policy actor-critic | off-policy value-based |
| Networks | actor and critic MLPs, 2 x 128 | Q-network and target network, 2 x 128 |
| Objective | clipped surrogate (clip 0.2) + 0.5 value loss - 0.01 entropy; GAE (gamma 0.99, lambda 0.95) | Bellman target r + gamma (1 - done) max Q_target(next) over **feasible** next actions; Huber loss |
| Data | fresh rollouts of 1024 rounds, 4 epochs, minibatch 256 | replay buffer 50,000, batch 128, one update per 4 rounds |
| Exploration | stochastic policy, entropy bonus | epsilon-greedy over feasible actions, 1.0 to 0.05 over 20,000 rounds |
| Other | lr 3e-4, grad clip 0.5 | lr 5e-4, target copy every 1,000 rounds |

Both use the same environment, observations, 9-action masked space, shared reward, scenario mixture, number of training rounds and evaluation seeds. Hyperparameters are standard defaults, **untuned for both**. Both are *independent learners*; DQN is known to suffer here because its replay buffer contains data from older policies of the other agents (non-stationarity).

---

## 10. Attention-based communication [Design, Implemented]

Each agent encodes its local observation into a message h_i (size 64). With N = 3 agents:

| Tensor | Shape | Definition |
|---|---|---|
| h | [B, 3, 64] | encoded observation of every agent |
| Q_i | [B, 3, 32] | query of receiver i (its own projection) |
| K_j | [B, 3, 32] | key of sender j (shared projection) |
| V_j | [B, 3, 32] | value of sender j (shared projection) |
| scores | [B, 3, 3] | Q_i . K_j / sqrt(32), diagonal masked (no self-attention) |
| weights | [B, 3, 3] | softmax over the two other agents; each row sums to 1 |
| context c_i | [B, 3, 32] | sum over j of weights_ij V_j |

Each agent's policy and value heads read [h_i, c_i]. The weights are **learned** (the projections are trained by the PPO loss); they are not hard-coded. Attention weights decide how much an agent listens to others; reward coefficients decide how much outcomes matter; the two are unrelated.

Three ablation modes share the same code and differ only in communication: `none` (independent), `mean` (average of the others' messages, communication without attention) and `attention`. Communication happens at decision time between the agents; nothing from the future is shared. A toy test confirms the mechanism carries information: when only one agent sees the answer, `mean` and `attention` solve the task and `none` stays at chance.

---

## 11. Demand forecasting [Design, Implemented, Observed]

**Target:** patients arriving (total and emergency) in the *next* 15-minute step. **Input:** counts of the previous 16 steps plus time of day. **No leakage:** at decision time t the history contains only patients with arrival_time < t; this is checked by tests (changing the current or future step does not change the history). Training, validation and test use disjoint simulated episodes (seeds 200000+, 300000+, 1000+), separate from the RL training seeds. Two models: a moving average (window chosen on validation data: 8 steps) and a PyTorch LSTM. The forecaster only predicts; it never allocates anything.

**Held-out results** (counts per 15-min step, 4 scenarios x 20 simulated episodes, measured on your machine):

| Model | Total MAE | Total RMSE | Emergency MAE | Emergency RMSE |
|---|---|---|---|---|
| Moving average (w = 8) | 0.695 | 1.027 | 0.372 | 0.519 |
| LSTM | 0.629 | 0.922 | 0.371 | 0.490 |
| Oracle (true generator rate) | 0.614 | 0.904 | 0.368 | 0.486 |

**[Observed]** The LSTM is better than the moving average for total arrivals and close to the oracle, which is the error floor caused by random arrivals. For emergency arrivals the MAE is equal and only the RMSE is better. **Limit:** all episodes share one daily pattern and the surge occurs at the same time of day, so this tests learning that pattern, not generalisation to a different one.

---

## 12. Baselines [Implemented]

Both baselines use the same simulator and hard constraints and commit one action at a time against the live state, so they never submit an invalid action. **FCFS** serves the earliest arrival first. **Severity priority** serves emergencies first, then higher urgency, then higher severity, then earliest arrival. They are a centralized, conflict-free reference; the learning agents act simultaneously on the same state and must learn to avoid conflicts. This asymmetry favours the baselines on conflicts and should be kept in mind.

---

## 13. Experimental protocol and metrics

**Protocol [Implemented].** `python scripts/run_all_experiments.py --profile default`:
- six learned methods: `ppo_independent` (separate networks), `comm_none`, `comm_mean`, `comm_attention`, `comm_attention_forecast`, `dqn`; plus the two baselines. `comm_none` is the proper control for communication (same architecture, communication off);
- each learned method: **3 independent training seeds** x 40 iterations x 1,024 decision rounds (about 41,000 rounds), trained on a **mixture of all 7 scenarios**;
- evaluation: every scenario, **5 evaluation seeds (1000-1004)** never used in training; greedy actions; identical code and seeds for every method.

**Statistics.** Learned methods: each training run is first averaged over its evaluation seeds, then mean and standard deviation (n-1) are taken across the 3 runs. Baselines: no training, so the standard deviation is across evaluation seeds. **The two kinds of spread are not directly comparable**, and with 3 runs the standard deviation is itself noisy. No significance tests were run.

**Metric definitions** (minutes of simulated time; completions are processed at step boundaries):
- *mean wait to treatment* = treatment start - arrival, averaged **only over patients whose treatment started**;
- *emergency response delay* = the same, for emergency patients;
- *emergency surgery wait* = surgery start - end of treatment, for emergency surgeries that started;
- *patients never treated* = patients whose treatment had not started by the end of the episode;
- *throughput* = patients discharged; *treatments / surgeries completed* = counts;
- *utilization* = resource-minutes held / (units x episode length); raw, not an appropriateness judgement;
- *invalid actions* = actions rejected by a hard constraint (here: conflicts between simultaneous agents);
- *shared episode reward* = sum of the shared reward (not defined for baselines);
- *training time* = wall-clock seconds on the machine that ran it.

---

## 14. Results [Observed]

Source: `results/experiments/default/results_summary.md` (copied to `docs/results_summary_default_run.md`). Values are mean ± standard deviation, simulated data.

### 14.1 Overall (average over the 7 scenarios)

| metric | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| Mean wait to treatment (min) | 256.86 ± 71.79 | 229.94 ± 54.83 | 225.00 ± 4.41 | 227.62 ± 4.46 | 229.12 ± 5.67 | 180.16 ± 54.41 | 223.97 ± 3.20 | 309.91 ± 13.56 |
| Emergency response delay (min) | 69.63 ± 26.78 | 61.69 ± 28.56 | 57.06 ± 2.50 | 58.28 ± 1.72 | 58.79 ± 0.24 | 69.26 ± 16.55 | 58.84 ± 2.00 | 72.07 ± 2.70 |
| Emergency surgery wait (min) | 15.55 ± 4.86 | 25.65 ± 3.59 | 42.93 ± 6.46 | 41.60 ± 0.53 | 46.34 ± 5.60 | 77.66 ± 35.77 | 41.61 ± 4.15 | 53.52 ± 8.50 |
| Patients never treated | 20.17 ± 5.93 | 21.17 ± 5.67 | 22.49 ± 0.39 | 22.02 ± 0.98 | 22.46 ± 1.16 | 54.55 ± 41.65 | 21.59 ± 0.50 | 41.20 ± 4.88 |
| Throughput (discharged) | 174.80 ± 10.46 | 173.31 ± 9.84 | 171.46 ± 0.47 | 172.09 ± 0.62 | 171.47 ± 0.73 | 139.50 ± 41.54 | 172.23 ± 0.44 | 151.79 ± 5.42 |
| Treatments completed | 191.89 ± 9.46 | 190.80 ± 8.47 | 189.78 ± 0.44 | 190.14 ± 0.93 | 189.63 ± 1.14 | 157.98 ± 41.08 | 190.60 ± 0.68 | 170.93 ± 4.73 |
| Surgeries completed | 40.91 ± 2.14 | 40.57 ± 2.35 | 39.82 ± 0.34 | 40.16 ± 0.11 | 39.65 ± 0.20 | 28.54 ± 14.61 | 39.79 ± 0.18 | 32.45 ± 3.07 |
| Bed utilization | 0.70 ± 0.05 | 0.70 ± 0.05 | 0.70 ± 0.00 | 0.70 ± 0.00 | 0.70 ± 0.00 | 0.72 ± 0.03 | 0.70 ± 0.00 | 0.71 ± 0.00 |
| Doctor utilization | 0.50 ± 0.02 | 0.50 ± 0.02 | 0.50 ± 0.00 | 0.50 ± 0.00 | 0.50 ± 0.00 | 0.41 ± 0.12 | 0.50 ± 0.00 | 0.45 ± 0.01 |
| OR utilization | 0.40 ± 0.02 | 0.40 ± 0.02 | 0.39 ± 0.00 | 0.40 ± 0.00 | 0.39 ± 0.00 | 0.29 ± 0.14 | 0.39 ± 0.00 | 0.32 ± 0.03 |
| Invalid actions (conflicts) per episode | 0.00 ± 0.00 | 0.00 ± 0.00 | 18.33 ± 0.71 | 17.90 ± 0.58 | 17.09 ± 0.47 | 11.81 ± 7.08 | 18.20 ± 0.41 | 10.88 ± 0.98 |
| Shared episode reward | n/a | n/a | -285.18 ± 3.26 | -283.23 ± 9.81 | -293.79 ± 12.53 | -1079.73 ± 1167.67 | -283.19 ± 8.89 | -508.91 ± 20.40 |

### 14.2 What the results show, and what they do not

**F1. Learned PPO variants and the baselines are similar on waiting time.** `ppo_independent`, `comm_none`, `comm_mean` and `comm_attention_forecast` have nearly identical results (mean wait 224-229 min) and are within the spread of FCFS (257 ± 72) and the severity baseline (230 ± 55). Against the severity baseline the learned PPO variants are within noise in every scenario. Where waiting looks lower than FCFS (for example `bed_shortage`, 268 vs 366 min), the learned agents also leave more patients untreated (about 40 vs 32) and discharge fewer (128 vs 136). Because the average only covers treated patients, **a lower average wait can partly reflect treating fewer patients**; read the waiting and "never treated" tables together.

**F2. Emergency response delay is slightly lower for the learned PPO variants.** About 57-59 min against 61.7 for the severity baseline and 69.6 for FCFS overall; in 6 of 7 scenarios `ppo_independent` is a few minutes below the severity baseline. The baseline spread is large (±28), so this is a small, uncertain difference. We do not claim it is significant.

**F3. Emergency surgery waiting is worse for every learned method, in every scenario.** Overall 41-47 min for the PPO variants against 15.6 (FCFS) and 25.7 (severity); in `doctor_shortage` FCFS has no wait at all and the learned agents about 30-45 min. This is the most consistent difference in the study and it goes against the learned agents. A plausible but **untested** explanation is competition for the same specialist doctors between treatment and surgery, which also appears with the severity baseline; the reward has no separate term for surgery waiting.

**F4. The attention variant (`comm_attention`) was unstable across training seeds.** Its mean wait looks best (180 ± 54), but it also has far more untreated patients (54.6 ± 41.7 vs about 22), lower throughput (139.5 ± 41.5), and a shared reward of -1080 ± 1168. With 3 runs, this pattern is most consistent with **at least one training run producing a policy that treats many fewer patients**, which also lowers the average wait of the patients it does treat. Its apparently good waiting time must **not** be read as an improvement. (The per-run values in `per_episode.csv` can confirm which run is responsible.) The same architecture with a forecast (`comm_attention_forecast`) did not show this instability in these 3 runs; we cannot tell whether that is due to the forecast or to chance.

**F5. Communication and forecasting show no benefit here.** `comm_none`, `comm_mean` and `comm_attention_forecast` are indistinguishable on every metric (differences far smaller than their spread). Invalid actions per episode are about 17-18 for all of them, so communication did not visibly reduce conflicts. The one variant with fewer conflicts (`comm_attention`, 11.8) also treats fewer patients, so fewer actions are attempted. Because `comm_attention_forecast` differs from `comm_none` in two ways (attention and forecast), and the clean comparison `comm_attention` vs `comm_attention_forecast` is confounded by F4, we cannot attribute any effect to either component. The simplest reading is that, with local observations and action masks, the extra information was not needed or was not exploited in 40 training iterations.

**F6. DQN was worse than the PPO variants on service, with fewer conflicts.** Mean wait 310 ± 14, 41 patients never treated, throughput 152 (PPO variants: about 225, 22, 171-172). It submits fewer invalid actions (10.9 vs about 18). The three DQN runs agree with each other (small spread), so this is not a single bad run. It is a statement about *untuned, independent DQN trained for about 41,000 rounds*, not about DQN in general.

**F7. Learned agents produce conflicts that the baselines avoid by construction** (about 17-18 invalid actions per 3-day episode against 0). This reflects that the baselines commit actions one by one while learned agents act simultaneously, plus the agents' imperfect coordination.

**F8. Utilization is almost identical for the baselines and the four stable PPO variants** (beds about 0.70, doctors about 0.50, ORs about 0.39-0.40 overall), so their outcome differences are not explained by raw resource use. DQN and the unstable attention variant show lower doctor and OR utilization (0.41-0.45 and 0.29-0.32), consistent with their treating fewer patients.

**F9. Training time is not comparable across methods in our data.** Identical architectures took 83 s (`comm_attention`) and 321 s (`comm_none`), which cannot be an algorithmic difference; it reflects load on the machine. Do not use it to rank methods.

### 14.3 Selected per-scenario tables

**Mean wait to treatment (min), lower is better**

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 365.54 ± 162.61 | 298.38 ± 90.28 | 268.45 ± 6.48 | 269.66 ± 1.80 | 272.06 ± 4.88 | 234.01 ± 59.44 | 272.55 ± 9.31 | 348.34 ± 33.56 |
| doctor_shortage | 223.87 ± 97.22 | 227.32 ± 105.04 | 231.94 ± 9.82 | 237.43 ± 9.81 | 238.15 ± 14.40 | 195.19 ± 64.34 | 224.86 ± 12.52 | 329.45 ± 18.70 |
| emergency_surge | 94.55 ± 25.63 | 99.66 ± 33.72 | 94.04 ± 3.76 | 95.51 ± 1.87 | 96.26 ± 1.91 | 93.59 ± 5.20 | 94.80 ± 2.33 | 225.01 ± 8.84 |
| high_demand | 456.90 ± 138.23 | 340.10 ± 74.02 | 343.11 ± 2.03 | 347.04 ± 8.08 | 353.75 ± 6.86 | 244.39 ± 100.85 | 345.77 ± 4.84 | 364.50 ± 51.61 |
| mixed_demand | 446.88 ± 124.44 | 420.76 ± 82.88 | 421.75 ± 8.27 | 426.03 ± 18.76 | 424.11 ± 12.59 | 287.29 ± 138.05 | 419.83 ± 12.61 | 437.84 ± 29.93 |
| normal | 99.41 ± 27.27 | 103.88 ± 30.15 | 94.65 ± 3.93 | 97.48 ± 1.32 | 97.91 ± 3.89 | 94.54 ± 3.52 | 93.46 ± 4.59 | 215.36 ± 16.67 |
| or_shortage | 110.88 ± 42.73 | 119.47 ± 54.65 | 121.09 ± 2.77 | 120.15 ± 3.87 | 121.63 ± 4.36 | 112.10 ± 18.20 | 116.55 ± 9.46 | 248.85 ± 15.74 |

**Emergency response delay (min), lower is better**

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 122.43 ± 95.58 | 114.53 ± 91.55 | 102.55 ± 8.51 | 101.15 ± 2.88 | 111.47 ± 1.58 | 106.89 ± 2.27 | 105.56 ± 6.73 | 127.86 ± 10.61 |
| doctor_shortage | 82.77 ± 25.48 | 72.72 ± 25.55 | 64.96 ± 4.47 | 68.40 ± 3.62 | 69.62 ± 0.72 | 75.25 ± 12.52 | 66.90 ± 6.37 | 78.02 ± 6.22 |
| emergency_surge | 38.77 ± 16.39 | 30.39 ± 9.28 | 29.51 ± 1.38 | 29.92 ± 1.70 | 28.57 ± 0.70 | 40.22 ± 15.09 | 30.39 ± 2.00 | 42.13 ± 2.86 |
| high_demand | 72.78 ± 17.56 | 66.41 ± 6.62 | 64.41 ± 3.95 | 65.83 ± 6.99 | 62.20 ± 1.04 | 89.01 ± 37.39 | 68.27 ± 6.01 | 76.87 ± 17.87 |
| mixed_demand | 75.46 ± 40.61 | 68.64 ± 47.33 | 61.96 ± 1.36 | 63.70 ± 3.82 | 61.09 ± 0.93 | 84.20 ± 29.54 | 65.26 ± 0.52 | 73.00 ± 5.36 |
| normal | 50.56 ± 22.68 | 46.50 ± 28.57 | 40.67 ± 4.44 | 44.09 ± 0.26 | 43.45 ± 1.24 | 44.31 ± 0.85 | 41.13 ± 5.58 | 55.09 ± 2.57 |
| or_shortage | 44.64 ± 19.66 | 32.63 ± 21.20 | 35.34 ± 3.03 | 34.82 ± 3.81 | 35.15 ± 2.63 | 44.92 ± 20.05 | 34.38 ± 1.66 | 51.49 ± 6.25 |

**Emergency surgery wait (min), lower is better**

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 2.21 ± 3.50 | 5.54 ± 7.13 | 11.20 ± 6.05 | 9.07 ± 4.11 | 15.21 ± 6.98 | 147.95 ± 169.59 | 11.74 ± 0.36 | 16.20 ± 5.66 |
| doctor_shortage | 0.00 ± 0.00 | 9.09 ± 8.82 | 44.95 ± 10.28 | 30.23 ± 1.45 | 41.91 ± 7.97 | 49.69 ± 22.52 | 37.88 ± 9.42 | 49.35 ± 22.48 |
| emergency_surge | 0.64 ± 1.15 | 7.86 ± 12.19 | 18.54 ± 5.76 | 19.19 ± 7.06 | 17.05 ± 0.56 | 32.51 ± 29.09 | 16.32 ± 1.25 | 28.69 ± 15.34 |
| high_demand | 2.14 ± 2.33 | 11.60 ± 8.75 | 19.86 ± 3.10 | 23.63 ± 5.64 | 37.70 ± 12.80 | 65.15 ± 59.89 | 25.59 ± 7.90 | 50.72 ± 14.19 |
| mixed_demand | 5.89 ± 5.34 | 15.44 ± 13.99 | 44.63 ± 4.19 | 50.12 ± 5.00 | 53.32 ± 15.41 | 64.64 ± 66.15 | 45.43 ± 4.05 | 55.14 ± 2.22 |
| normal | 1.06 ± 1.91 | 7.97 ± 8.89 | 24.19 ± 2.41 | 22.76 ± 3.13 | 24.32 ± 1.16 | 44.75 ± 42.03 | 24.38 ± 3.50 | 29.41 ± 6.21 |
| or_shortage | 96.93 ± 32.62 | 122.08 ± 23.65 | 137.13 ± 21.57 | 136.16 ± 5.88 | 134.88 ± 8.40 | 136.16 ± 8.64 | 129.96 ± 16.83 | 145.11 ± 22.56 |

**Patients never treated, lower is better**

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 32.00 ± 10.44 | 32.80 ± 10.69 | 42.20 ± 2.82 | 40.47 ± 1.68 | 39.87 ± 1.14 | 67.33 ± 33.06 | 39.87 ± 2.20 | 58.33 ± 6.33 |
| doctor_shortage | 17.20 ± 6.69 | 18.40 ± 7.86 | 19.93 ± 0.81 | 20.53 ± 2.72 | 20.80 ± 2.09 | 39.00 ± 33.43 | 17.73 ± 0.81 | 32.33 ± 5.15 |
| emergency_surge | 2.40 ± 4.83 | 2.00 ± 3.39 | 1.67 ± 0.46 | 1.87 ± 0.50 | 1.40 ± 0.40 | 20.60 ± 32.57 | 1.40 ± 0.20 | 10.53 ± 1.81 |
| high_demand | 55.20 ± 19.79 | 57.80 ± 18.14 | 57.13 ± 0.23 | 55.73 ± 2.14 | 58.20 ± 3.02 | 126.87 ± 79.36 | 56.60 ± 1.93 | 89.53 ± 10.55 |
| mixed_demand | 25.60 ± 10.64 | 27.60 ± 7.64 | 26.00 ± 1.00 | 25.93 ± 2.02 | 27.53 ± 2.58 | 94.93 ± 75.72 | 25.87 ± 2.02 | 61.27 ± 7.87 |
| normal | 3.00 ± 3.74 | 3.00 ± 3.94 | 2.93 ± 0.42 | 2.87 ± 0.31 | 2.80 ± 0.35 | 9.27 ± 11.20 | 2.73 ± 0.12 | 11.93 ± 4.24 |
| or_shortage | 5.80 ± 8.29 | 6.60 ± 8.53 | 7.53 ± 1.63 | 6.73 ± 0.12 | 6.60 ± 0.40 | 23.87 ± 31.47 | 6.93 ± 1.01 | 24.47 ± 7.14 |

**Throughput (discharged), higher is better**

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 135.80 ± 5.76 | 135.80 ± 5.85 | 127.93 ± 2.47 | 129.73 ± 1.55 | 129.73 ± 0.23 | 101.93 ± 33.51 | 129.87 ± 1.42 | 113.00 ± 5.10 |
| doctor_shortage | 153.60 ± 14.12 | 150.80 ± 13.07 | 148.33 ± 0.42 | 148.07 ± 1.97 | 147.20 ± 0.72 | 128.13 ± 35.11 | 150.07 ± 0.50 | 133.13 ± 2.69 |
| emergency_surge | 174.40 ± 13.46 | 174.60 ± 12.86 | 174.13 ± 0.50 | 174.20 ± 0.35 | 174.60 ± 0.20 | 155.33 ± 33.20 | 174.53 ± 0.23 | 160.93 ± 4.71 |
| high_demand | 215.20 ± 13.26 | 213.00 ± 9.38 | 212.47 ± 0.64 | 214.07 ± 1.40 | 211.87 ± 2.53 | 144.60 ± 77.43 | 213.00 ± 2.27 | 180.80 ± 11.19 |
| mixed_demand | 223.20 ± 11.17 | 220.60 ± 9.48 | 221.27 ± 1.30 | 220.93 ± 2.12 | 220.07 ± 2.16 | 153.33 ± 74.71 | 220.93 ± 2.39 | 188.33 ± 8.21 |
| normal | 164.80 ± 17.22 | 163.40 ± 17.13 | 163.07 ± 0.23 | 163.47 ± 0.31 | 163.00 ± 0.20 | 156.33 ± 11.55 | 163.47 ± 0.50 | 150.87 ± 5.95 |
| or_shortage | 156.60 ± 18.84 | 155.00 ± 18.14 | 153.00 ± 2.12 | 154.13 ± 0.23 | 153.80 ± 0.20 | 136.87 ± 30.20 | 153.73 ± 1.03 | 135.47 ± 7.50 |

**Invalid actions per episode, lower is better**

| scenario | fcfs | severity | ppo_independent | comm_none | comm_mean | comm_attention | comm_attention_forecast | dqn |
|---|---|---|---|---|---|---|---|---|
| bed_shortage | 0.00 ± 0.00 | 0.00 ± 0.00 | 7.07 ± 1.70 | 6.67 ± 0.83 | 7.80 ± 0.92 | 4.33 ± 3.20 | 6.67 ± 1.17 | 5.93 ± 1.29 |
| doctor_shortage | 0.00 ± 0.00 | 0.00 ± 0.00 | 25.67 ± 0.81 | 24.80 ± 1.80 | 22.53 ± 1.68 | 20.13 ± 11.59 | 27.53 ± 1.03 | 14.27 ± 2.84 |
| emergency_surge | 0.00 ± 0.00 | 0.00 ± 0.00 | 17.40 ± 1.40 | 16.47 ± 1.81 | 15.00 ± 0.72 | 13.13 ± 5.75 | 15.60 ± 0.80 | 8.27 ± 1.89 |
| high_demand | 0.00 ± 0.00 | 0.00 ± 0.00 | 24.87 ± 1.62 | 26.13 ± 0.92 | 24.20 ± 1.93 | 11.13 ± 11.82 | 25.67 ± 1.53 | 16.13 ± 0.81 |
| mixed_demand | 0.00 ± 0.00 | 0.00 ± 0.00 | 29.33 ± 1.67 | 27.20 ± 1.51 | 26.53 ± 1.30 | 13.13 ± 12.97 | 27.80 ± 0.40 | 15.13 ± 1.70 |
| normal | 0.00 ± 0.00 | 0.00 ± 0.00 | 17.20 ± 1.91 | 17.53 ± 1.01 | 17.13 ± 1.33 | 15.53 ± 4.62 | 17.13 ± 1.01 | 10.00 ± 0.92 |
| or_shortage | 0.00 ± 0.00 | 0.00 ± 0.00 | 6.80 ± 0.92 | 6.53 ± 1.21 | 6.40 ± 0.20 | 5.27 ± 2.32 | 7.00 ± 1.44 | 6.40 ± 0.20 |

The remaining tables (treatments and surgeries completed, utilization, shared reward, percent differences to FCFS, training time) are in `docs/results_summary_default_run.md`.

### 14.4 Figures

Generated by the experiment suite in `results/experiments/default/figures/`: `mean_wait_to_treatment.png`, `emergency_response_delay.png`, `throughput.png`, `unserved_patients.png`, `invalid_actions_total.png`, `bed_utilization.png`, `doctor_utilization.png`, `or_utilization.png`, `learning_curves.png` (training return with exploration on mixed scenarios; **not comparable to the evaluation tables**) and `attention_weights.png` (average attention each agent gives each other agent over training).

---

## 15. Limitations

1. **Synthetic data and assumed parameters.** No real hospital data were used; all rates, durations and probabilities are our assumptions.
2. **Simplified hospital.** One treatment visit per patient; surgeon and treating doctor come from one pool; no nurses, transfers, cancellations, shift patterns or scheduling of the future; resources in a pool are interchangeable.
3. **Short, untuned training.** 40 iterations (about 41,000 rounds), standard hyperparameters, no tuning for either PPO or DQN. Learning had clearly not converged for the weaker methods.
4. **Few seeds.** 3 training seeds and 5 evaluation seeds; spreads are noisy and no significance tests were run. Baseline and learned spreads measure different things.
5. **Reward coefficients were not tuned and no sensitivity analysis was done**, although the specification asks for it.
6. **Metric caveat.** Average waits are computed over treated patients only and can look better when fewer patients are treated.
7. **Decision-round formulation.** Learning steps are decision rounds, discounting is per round, and the episode end is treated as terminal.
8. **Limited queue view.** Agents can select only their 8 highest-priority patients.
9. **Baselines are centralized and conflict-free;** learned agents are not, which affects the conflict comparison.
10. **Independent DQN** suffers from non-stationarity; DQN with attention or forecasting was not tested.
11. **Forecasting:** one daily pattern, surge at a fixed time of day; no evidence the forecast helps decisions.
12. **Emergency surgery waiting** is worse for all learned agents; the cause was not diagnosed.
13. **Timing measurements are unreliable** (machine load).
14. The HTML dashboard replays **recorded** episodes and shows stored results; it does not run the simulator live, and no Streamlit version was built.

---

## 16. Future scope

- Tune hyperparameters and reward coefficients with a documented sensitivity study; add a reward term or constraint for emergency surgery waiting.
- Longer training and more seeds (at least 5-10) with paired comparisons per evaluation seed and confidence intervals.
- Investigate the unstable attention runs (learning rate, attention entropy regularisation, initialisation) and add a centralized critic (centralised training, decentralised execution).
- Reduce conflicts structurally (for example sequential decision order within a round).
- DQN variants (double, dueling) and DQN with communication / forecasting.
- Richer hospital model (nurses, shifts, transfers, uncertainty in length of stay) and, if access is possible, calibration to real aggregated data.
- Forecast ICU and surgery demand; test the forecaster on shifted demand patterns.
- A live dashboard (Streamlit or a small web server) that runs the simulator on demand with user-chosen scenarios and policies.

---

## 17. Reproducibility

```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python -m pytest -q                                           # 191 tests
python scripts/generate_data.py --scenario all                # synthetic data
python scripts/run_baseline.py --scenario all --num-seeds 5   # baselines only
python scripts/run_forecaster.py                              # forecaster
python scripts/run_all_experiments.py --profile smoke         # pipeline check
python scripts/run_all_experiments.py --profile default       # main experiment (about 2 h)
python scripts/make_diagrams.py                               # regenerate figures in docs/figures
python scripts/build_dashboard.py --models                    # docs/dashboard.html (open in a browser)
```
Seeds: training episodes use seeds from 100000 upward (per run seed), evaluation 1000-1004, forecaster training / validation 200000+ / 300000+. Every training run stores its configuration (`config_used.yaml`) and logs (`train_log.csv`, `episodes.csv`) in `results/experiments/default/runs/`. Runs are deterministic on one machine; across machines small floating-point differences can change off-policy (DQN) and sometimes PPO results.
