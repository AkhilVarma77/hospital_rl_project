"""Agent interfaces: fixed dimensions, queue ordering, masks, decoding, no information leakage."""
import numpy as np
import pytest

from src.agents.bed_agent import BedAgent
from src.agents.doctor_agent import DoctorAgent
from src.agents.or_agent import ORAgent
from src.environment import constraints as C
from src.environment.hospital_env import HospitalEnv
from src.environment.hospital_state import Action, Stage
from src.utils.config import load_config
from tests.helpers import make_config, make_env, patient

ALL = (BedAgent, DoctorAgent, ORAgent)


def _agents(env):
    return [A(env.cfg) for A in ALL]


def test_observation_shape_and_range_over_a_whole_episode():
    env = HospitalEnv(load_config(), "high_demand", seed=2)
    agents = _agents(env)
    from tests.helpers import greedy_policy
    while not env.done:
        for a in agents:
            obs = a.observe(env)
            assert obs.shape == (a.obs_dim,) and obs.dtype == np.float32
            assert np.isfinite(obs).all() and obs.min() >= -1.0 and obs.max() <= 3.0
            assert a.action_mask(env).shape == (a.n_actions,)
        env.step(greedy_policy(env))


def test_dimensions_do_not_depend_on_scenario_resources():
    dims = set()
    for scenario in ("normal", "bed_shortage", "doctor_shortage", "or_shortage"):
        env = HospitalEnv(load_config(), scenario, seed=1)
        dims.add(tuple(a.obs_dim for a in _agents(env)))
    assert len(dims) == 1


def test_queue_order_emergency_then_urgency_then_arrival():
    env = make_env([
        patient(0, is_emergency=False, urgency_level=3, severity=5),
        patient(1, urgency_level=2, severity=2),
        patient(2, urgency_level=4, severity=5),
        patient(3, urgency_level=4, severity=5, arrival_time=10),
    ], make_config(general_beds=4))
    env.step({})
    order = [p.patient_id for p in BedAgent(env.cfg).queue(env.state)]
    assert order == [2, 3, 1, 0]


def test_queue_is_truncated_to_k_slots_but_length_feature_is_not():
    cfg = make_config(general_beds=0, icu_beds=0)
    cfg["observation"]["max_queue"] = 2
    env = make_env([patient(i) for i in range(5)], cfg)
    agent = BedAgent(env.cfg)
    assert len(agent.queue(env.state)) == 2 and agent.n_actions == 3
    obs = agent.observe(env)
    queue_len_feature = obs[5 + agent.pool_dim]
    assert queue_len_feature == pytest.approx(5 / 20)


def test_mask_marks_only_feasible_slots():
    env = make_env([patient(0), patient(1, required_bed_type="icu"),
                    patient(2, is_emergency=False, required_bed_type="icu", urgency_level=1)],
                   make_config(general_beds=1, icu_beds=1, reserve=1))
    agent = BedAgent(env.cfg)
    order = [p.patient_id for p in agent.queue(env.state)]   # emergencies first: 0, 1, then 2
    mask = agent.action_mask(env)
    assert mask[agent.defer_index]
    assert mask[order.index(0)] and mask[order.index(1)]
    assert not mask[order.index(2)]                           # elective ICU blocked by reserve
    assert not mask[3:agent.defer_index].any()                # empty slots


def test_mask_has_no_feasible_slot_when_no_resource_is_free():
    env = make_env([patient(0), patient(1)], make_config(general_beds=1))
    env.step({"bed": [Action("bed", 0, 1)]})
    agent = BedAgent(env.cfg)
    assert agent.action_mask(env).tolist() == [False] * agent.K + [True]


def test_finished_agent_or_exhausted_budget_can_only_defer():
    env = make_env([patient(0)], make_config(max_actions=1))
    agent = BedAgent(env.cfg)
    assert agent.action_mask(env)[0]
    assert agent.action_mask(env, finished=True).tolist() == [False] * agent.K + [True]
    env.apply_action(Action("bed", 0, 1))
    assert env.actions_remaining("bed") == 0
    assert not agent.action_mask(env).any() or agent.action_mask(env).tolist() == [False] * agent.K + [True]


def test_mask_matches_environment_feasibility_throughout_an_episode():
    env = HospitalEnv(load_config(), "emergency_surge", seed=4)
    agents = _agents(env)
    from tests.helpers import greedy_policy
    while not env.done:
        for a in agents:
            feasible_patients = {act.patient_id for act in env.get_feasible_actions(a.name)}
            q = a.queue(env.state)
            mask = a.action_mask(env)
            masked_patients = {q[i].patient_id for i in range(len(q)) if mask[i]}
            assert masked_patients <= feasible_patients       # never allows an infeasible action
            if len(feasible_patients) and len(q) == len(env.state.stage_sets[a.stage]):
                assert masked_patients == feasible_patients   # and (if nothing is truncated) all
        env.step(greedy_policy(env))


def test_decode():
    env = make_env([patient(0), patient(1)], make_config(general_beds=2))
    a = BedAgent(env.cfg)
    assert a.decode(env, a.defer_index).is_defer
    act = a.decode(env, 0)
    assert (act.agent, act.patient_id, act.resource_id) == ("bed", 0, 1)   # lowest free general bed
    assert env.validate(act) is None
    empty = a.decode(env, 5)                                               # no patient in slot 5
    assert env.validate(empty) == C.UNKNOWN_PATIENT
    with pytest.raises(ValueError):
        a.decode(env, a.K + 1)


def test_decode_without_free_resource_is_an_invalid_attempt_not_a_crash():
    env = make_env([patient(0), patient(1)], make_config(general_beds=1))
    env.step({"bed": [Action("bed", 0, 1)]})
    a = BedAgent(env.cfg)
    act = a.decode(env, 0)                                    # patient 1, but no free bed
    assert act.resource_id is None and env.validate(act) == C.UNKNOWN_RESOURCE


def test_doctor_and_or_agents_decode_resources():
    pats = [patient(0, required_specialization="cardiology", requires_surgery=True,
                    surgery_type="cardiac", surgery_duration=60, est_surgery_duration=60)]
    env = make_env(pats)
    env.step({"bed": [Action("bed", 0, 1)]})
    doc = DoctorAgent(env.cfg)
    act = doc.decode(env, 0)
    assert (act.agent, act.patient_id, act.resource_id) == ("doctor", 0, 1)   # the cardiologist
    env.step({"doctor": [act]}); env.step({})
    assert env.state.patients[0].stage == Stage.WAITING_SURGERY
    orr = ORAgent(env.cfg)
    assert orr.action_mask(env)[0]
    assert orr.decode(env, 0).resource_id == 0


# ------------------------------------------------------------------ information rules
def test_observations_do_not_depend_on_true_durations():
    def build(true_treat, true_los):
        return make_env([patient(0, treatment_duration=true_treat, est_treatment_duration=40,
                                 length_of_stay=true_los, expected_length_of_stay=150)])
    a, b = build(40, 150), build(200, 900)
    for env in (a, b):
        env.step({"bed": [Action("bed", 0, 1)], "doctor": [Action("doctor", 0, 0)]})
    for cls in ALL:
        assert np.array_equal(cls(a.cfg).observe(a), cls(b.cfg).observe(b))


def test_bed_agent_observation_ignores_other_agents_domains():
    # Same bed state and bed queue; in env B the doctor additionally started treating patient 0.
    a = make_env([patient(0), patient(1)], make_config(general_beds=2))
    b = make_env([patient(0), patient(1)], make_config(general_beds=2))
    a.step({"bed": [Action("bed", 0, 1)]})
    b.step({"bed": [Action("bed", 0, 1)]})
    b.apply_action(Action("doctor", 0, 0))
    bed = BedAgent(a.cfg)
    assert np.array_equal(bed.observe(a), bed.observe(b))
    assert not np.array_equal(DoctorAgent(a.cfg).observe(a), DoctorAgent(b.cfg).observe(b))


def test_forecast_features_are_passed_through():
    env = make_env([patient(0)])
    agent = BedAgent(env.cfg)
    assert np.allclose(agent.observe(env)[2:4], 0.0)
    assert np.allclose(agent.observe(env, (0.5, 0.25))[2:4], [0.5, 0.25])
