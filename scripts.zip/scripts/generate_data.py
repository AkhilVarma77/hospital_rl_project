"""Generate synthetic hospital data and save it as CSV.

Examples (from the project root, venv active):
    python scripts/generate_data.py
    python scripts/generate_data.py --scenario emergency_surge --seed 7
    python scripts/generate_data.py --scenario all
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

from src.data.synthetic_data_generator import SyntheticDataGenerator  # noqa: E402
from src.utils.config import load_config  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=None, help="path to YAML config")
    parser.add_argument("--scenario", default="normal", help="scenario name or 'all'")
    parser.add_argument("--seed", type=int, default=None, help="override config seed")
    parser.add_argument("--out-dir", default="data/generated")
    args = parser.parse_args()

    config = load_config(args.config)
    names = list(config["scenarios"]) if args.scenario == "all" else [args.scenario]

    for name in names:
        gen = SyntheticDataGenerator(config, scenario=name, seed=args.seed)
        tables = gen.generate_all()
        folder = gen.save_all(args.out_dir)
        p = tables["patients"]
        print(f"[{name}] seed={gen.seed} patients={len(p)} "
              f"emergency={int(p['is_emergency'].sum())} "
              f"icu={int((p['required_bed_type'] == 'icu').sum())} "
              f"surgeries={int(p['requires_surgery'].sum())} "
              f"beds={len(tables['beds'])} doctors={len(tables['doctors'])} "
              f"ORs={len(tables['operating_rooms'])} -> {folder}")


if __name__ == "__main__":
    main()
