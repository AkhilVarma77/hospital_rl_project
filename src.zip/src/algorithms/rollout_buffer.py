"""Rollout storage with Generalized Advantage Estimation (GAE) for one agent.

Time index t holds: observation o_t, action mask, action a_t, log pi(a_t|o_t), value V(o_t),
the reward r_t received after acting, and `done_t` (the episode ended after this step).

A step is "active" if at least one non-defer action was feasible. Steps where the agent could
only defer carry no decision, so they are excluded from the gradient (but they stay in the
sequence, so advantages of the surrounding steps are still computed correctly).
"""
from __future__ import annotations

from typing import Iterator

import numpy as np


class RolloutBuffer:
    def __init__(self, size: int, obs_dim: int, n_actions: int) -> None:
        self.size, self.ptr = size, 0
        self.obs = np.zeros((size, obs_dim), np.float32)
        self.masks = np.zeros((size, n_actions), bool)
        self.actions = np.zeros(size, np.int64)
        self.logps = np.zeros(size, np.float32)
        self.values = np.zeros(size, np.float32)
        self.rewards = np.zeros(size, np.float32)
        self.dones = np.zeros(size, np.float32)
        self.active = np.zeros(size, bool)
        self.advantages = np.zeros(size, np.float32)
        self.returns = np.zeros(size, np.float32)

    @property
    def full(self) -> bool:
        return self.ptr == self.size

    def add(self, obs, mask, action: int, logp: float, value: float, reward: float,
            done: bool) -> None:
        assert self.ptr < self.size, "buffer is full"
        i = self.ptr
        self.obs[i], self.masks[i], self.actions[i] = obs, mask, action
        self.logps[i], self.values[i], self.rewards[i] = logp, value, reward
        self.dones[i] = float(done)
        self.active[i] = bool(np.asarray(mask)[:-1].any())     # last action = defer
        self.ptr += 1

    def compute_gae(self, last_value: float, gamma: float, lam: float) -> None:
        """delta_t = r_t + gamma*V_{t+1}*(1-done_t) - V_t ;  A_t = delta_t + gamma*lam*(1-done_t)*A_{t+1}.
        `last_value` bootstraps V after the final stored step (ignored if that step ended an episode)."""
        assert self.full, "compute_gae needs a full buffer"
        gae = 0.0
        for t in reversed(range(self.size)):
            next_value = last_value if t == self.size - 1 else self.values[t + 1]
            nonterminal = 1.0 - self.dones[t]
            delta = self.rewards[t] + gamma * next_value * nonterminal - self.values[t]
            gae = delta + gamma * lam * nonterminal * gae
            self.advantages[t] = gae
        self.returns = self.advantages + self.values

    def active_indices(self) -> np.ndarray:
        return np.flatnonzero(self.active)

    def minibatches(self, batch_size: int, rng: np.random.Generator) -> Iterator[np.ndarray]:
        """Shuffled index batches over the ACTIVE steps."""
        idx = self.active_indices()
        rng.shuffle(idx)
        for start in range(0, len(idx), batch_size):
            yield idx[start:start + batch_size]
