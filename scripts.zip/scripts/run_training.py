"""Train PPO / DQN / communicating-PPO agents and evaluate the final policies.

Examples (project root, venv active):
    python scripts/run_training.py --algo ppo --scenario normal --iterations 40
    python scripts/run_training.py --algo dqn --scenario normal --iterations 40
    python scripts/run_training.py --algo comm_ppo --comm-mode attention --scenario normal --iterations 40
    (comm modes: none = independent, mean = communication without attention, attention)

One iteration = 1024 decision rounds for both algorithms (same interaction budget).
Outputs go to results/logs/<run-name>/ :
    train_log.csv  episodes.csv  config_used.yaml  checkpoints/  eval_final.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make `src` importable

import pandas as pd  # noqa: E402

from src.evaluation.evaluate import KEY_METRICS, evaluate_ma_policy  # noqa: E402
from src.training.train_comm_ppo import train_comm_ppo  # noqa: E402
from src.training.train_dqn import train_dqn  # noqa: E402
from src.training.train_ppo import train_ppo  # noqa: E402
from src.utils.config import load_config  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default=None)
    parser.add_argument("--algo", choices=["ppo", "dqn", "comm_ppo"], default="ppo")
    parser.add_argument("--comm-mode", choices=["none", "mean", "attention"], default="attention",
                        help="only for --algo comm_ppo")
    parser.add_argument("--scenario", default="normal")
    parser.add_argument("--iterations", type=int, default=30)
    parser.add_argument("--rollout-steps", type=int, default=None,
                        help="rounds per iteration (ppo.rollout_steps / dqn.steps_per_iteration)")
    parser.add_argument("--forecast-model", default=None,
                        help="path to a trained forecaster (.pt LSTM or .json moving average); omit = no forecast")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--run-name", default=None)
    parser.add_argument("--out-root", default="results/logs")
    parser.add_argument("--num-eval-seeds", type=int, default=5)
    parser.add_argument("--eval-seed-start", type=int, default=1000)
    args = parser.parse_args()

    config = load_config(args.config)
    label = f"comm_{args.comm_mode}" if args.algo == "comm_ppo" else args.algo
    fc_tag = "" if not args.forecast_model else ("_fc_" + Path(args.forecast_model).stem)
    run_name = args.run_name or f"{label}{fc_tag}_{args.scenario}_seed{args.seed}"
    forecast_spec = {"path": args.forecast_model} if args.forecast_model else None
    out_dir = Path(args.out_root) / run_name

    if args.algo == "ppo":
        overrides = {"rollout_steps": args.rollout_steps} if args.rollout_steps else None
        policies = train_ppo(config, args.scenario, out_dir, args.iterations, seed=args.seed,
                             ppo_overrides=overrides, forecast_spec=forecast_spec)
    elif args.algo == "comm_ppo":
        overrides = {"rollout_steps": args.rollout_steps} if args.rollout_steps else None
        policies = train_comm_ppo(config, args.scenario, out_dir, args.iterations, seed=args.seed,
                                  mode=args.comm_mode, ppo_overrides=overrides,
                                  forecast_spec=forecast_spec)
    else:
        overrides = {"steps_per_iteration": args.rollout_steps} if args.rollout_steps else None
        policies = train_dqn(config, args.scenario, out_dir, args.iterations, seed=args.seed,
                             dqn_overrides=overrides, forecast_spec=forecast_spec)

    seeds = list(range(args.eval_seed_start, args.eval_seed_start + args.num_eval_seeds))
    df = evaluate_ma_policy(config, args.scenario, policies, seeds, label if args.algo == "comm_ppo" else f"{args.algo}_independent")
    df.to_csv(out_dir / "eval_final.csv", index=False)
    pd.set_option("display.width", 250)
    print("\nFinal policy, greedy actions, evaluation seeds", seeds[0], "..", seeds[-1])
    print(df[KEY_METRICS + ["episode_return"]].mean().round(2).to_string())
    print(f"\nSaved to {out_dir}")


if __name__ == "__main__":
    main()