"""Rule-based baselines: correct ordering, safety, determinism and evaluation plumbing."""
import pytest

from src.baselines.fcfs import FCFSPolicy
from src.baselines.registry import BASELINES, make_baseline
from src.baselines.severity_priority import SeverityPriorityPolicy
from src.environment.hospital_env import HospitalEnv
from src.environment.hospital_state import Stage
from src.evaluation.evaluate import KEY_METRICS, evaluate_policy, run_policy_episode
from src.utils.config import load_config
from tests.helpers import make_config, make_env, patient


def _two_patient_env():
    # One general bed. Patient 0 arrives first but is less urgent than patient 1.
    env = make_env([patient(0, arrival_time=0, urgency_level=2, severity=2),
                    patient(1, arrival_time=5, urgency_level=4, severity=5)],
                   make_config(general_beds=1))
    env.step({})                       # t=15: both patients are now waiting
    assert set(env.state.patients) == {0, 1}
    return env


def test_fcfs_serves_earliest_arrival_first():
    env = _two_patient_env()
    FCFSPolicy().run_step(env)
    assert env.state.patients[0].stage != Stage.WAITING_BED
    assert env.state.patients[1].stage == Stage.WAITING_BED


def test_severity_policy_serves_most_urgent_first():
    env = _two_patient_env()
    SeverityPriorityPolicy().run_step(env)
    assert env.state.patients[1].stage != Stage.WAITING_BED
    assert env.state.patients[0].stage == Stage.WAITING_BED


def test_severity_policy_puts_emergencies_before_electives():
    env = make_env([patient(0, is_emergency=False, urgency_level=3, severity=5),
                    patient(1, is_emergency=True, urgency_level=1, severity=1,
                            arrival_time=5)], make_config(general_beds=2))
    env.step({})
    key = SeverityPriorityPolicy().priority_key
    assert key(env.state.patients[1]) < key(env.state.patients[0])


def test_policy_treats_admitted_patient_in_same_step():
    env = make_env([patient(0)])
    result = FCFSPolicy().run_step(env)
    assert result.stats["executed"]["bed"] == 1 and result.stats["executed"]["doctor"] == 1
    assert env.state.patients[0].stage == Stage.IN_TREATMENT


def test_policies_respect_action_limit():
    pats = [patient(i) for i in range(5)]
    env = make_env(pats, make_config(general_beds=5, max_actions=2))
    result = FCFSPolicy().run_step(env)
    assert result.stats["executed"]["bed"] == 2          # not 5
    assert result.stats["invalid"]["bed"] == 0


def test_registry():
    assert set(BASELINES) == {"fcfs", "severity"}
    assert isinstance(make_baseline("fcfs"), FCFSPolicy)
    with pytest.raises(KeyError):
        make_baseline("nope")


@pytest.mark.parametrize("name", ["fcfs", "severity"])
@pytest.mark.parametrize("scenario", ["normal", "high_demand", "emergency_surge", "bed_shortage",
                                      "doctor_shortage", "or_shortage", "mixed_demand"])
def test_baselines_never_submit_invalid_actions(name, scenario):
    env = HospitalEnv(load_config(), scenario, seed=5)
    policy = make_baseline(name)
    while not env.done:
        policy.run_step(env)
        assert env.state.validate_consistency() == []
    s = env.get_episode_summary()
    assert s["invalid_actions_total"] == 0
    assert s["throughput"] > 0


def test_baseline_is_deterministic():
    def run():
        return run_policy_episode(HospitalEnv(load_config(), "mixed_demand", seed=9),
                                  make_baseline("severity"))
    assert run() == run()


def test_evaluate_policy_returns_one_row_per_seed():
    df = evaluate_policy(load_config(), "normal", lambda: make_baseline("fcfs"),
                         seeds=[1000, 1001], policy_name="fcfs")
    assert len(df) == 2 and list(df["seed"]) == [1000, 1001]
    assert set(df["policy"]) == {"fcfs"} and set(df["scenario"]) == {"normal"}
    assert set(KEY_METRICS) <= set(df.columns)
    assert "invalid_actions_bed" in df.columns and "invalid_reasons" not in df.columns
    assert (df["eval_seconds"] > 0).all()
